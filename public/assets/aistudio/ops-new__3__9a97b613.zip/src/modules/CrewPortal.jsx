/* ═══════════════════════════════════════════════════════════
 * CREW PORTAL — Theme-aware + Calendar + My Aircraft Status
 * v4.7 — Added My Aircraft Status (MELs + CAMO)
 * ═══════════════════════════════════════════════════════════ */
import React, { useState, useMemo, useEffect } from "react";
import {
  X,
  Menu,
  Calendar,
  Award,
  Clock,
  BookOpen,
  BarChart3,
  FileText,
  ExternalLink,
  ShieldAlert,
  Download,
  LogOut,
  User,
  Home,
  TrendingUp,
  Activity,
  Plane,
  Timer,
  Target,
  Eye,
  AlertTriangle,
} from "lucide-react";
import { useT, useAuth } from "../contexts";
import { can as checkPerm } from "../config/permissions";
import { camoAPI, melAPI } from "../api";
import { FTLModule } from "./FTLModule";
import { ManualsModule } from "./ManualsModule";
import { CalendarView } from "./CalendarView";
import {
  docStatus,
  daysUntil,
  formatFileSize,
  getStatusColor,
} from "../utils/helpers";
import { getPortalTheme, DEFAULT_PORTAL_THEME } from "../config/constants";

/* ⭐ خريطة اختصارات الوظائف */
const POS_SHORT_MAP = {
  captain: "CPT",
  firstOfficer: "FO",
  observer: "OBS",
  tri: "TRI",
  fa1: "FA1",
  fa2: "FA2",
  flightAttendant: "FA",
  engineer: "ENG1",
  security: "SEC",
  loadmaster: "LMC",
  flightDispatcher: "FD",
};

const POS_ORDER = [
  "CPT",
  "FO",
  "OBS",
  "TRI",
  "FA1",
  "FA2",
  "FA",
  "ENG1",
  "SEC",
  "LMC",
  "FD",
];

function getDocs(c) {
  let att = c?.attachments;
  if (!att) return [];
  if (Array.isArray(att)) return att;
  if (typeof att === "string") {
    const trimmed = att.trim();
    if (!trimmed || trimmed === "null" || trimmed === "undefined") return [];
    try {
      const parsed = JSON.parse(trimmed);
      if (Array.isArray(parsed)) return parsed;
    } catch (e) {
      try {
        const fixed = trimmed.replace(/,\s*$/, "") + "]";
        const parsed = JSON.parse(fixed);
        if (Array.isArray(parsed)) return parsed;
      } catch (e2) {}
    }
  }
  return [];
}

function normalizeDoc(doc, idx) {
  if (!doc) return null;
  if (typeof doc === "string") {
    return {
      name: doc.split("/").pop() || `File ${idx + 1}`,
      url: doc,
      type: "",
      size: 0,
      expiry: "",
    };
  }
  const url = doc.url || doc.fileUrl || doc.path || doc.data || doc.href || "";
  if (!url) return null;
  return {
    name: doc.name || doc.fileName || doc.title || `Document ${idx + 1}`,
    url,
    type: doc.type || doc.mimeType || doc.mime || "",
    size: doc.size || 0,
    expiry: doc.expiry || "",
  };
}

/* ⭐ Helpers موحدة للتواريخ */
const fmtHM = (iso) => {
  if (!iso) return "—";
  const d = new Date(iso);
  if (isNaN(d.getTime())) return "—";
  return `${String(d.getUTCHours()).padStart(2, "0")}:${String(
    d.getUTCMinutes()
  ).padStart(2, "0")}`;
};

const fmtDate = (iso) => {
  if (!iso) return "";
  const d = new Date(iso);
  if (isNaN(d.getTime())) return "";
  const days = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
  const months = [
    "Jan",
    "Feb",
    "Mar",
    "Apr",
    "May",
    "Jun",
    "Jul",
    "Aug",
    "Sep",
    "Oct",
    "Nov",
    "Dec",
  ];
  return `${days[d.getUTCDay()]} ${d.getUTCDate()} ${months[d.getUTCMonth()]}`;
};

const calcDuration = (std, sta) => {
  if (!std || !sta) return "—";
  const t1 = new Date(std).getTime();
  const t2 = new Date(sta).getTime();
  if (isNaN(t1) || isNaN(t2) || t2 <= t1) return "—";
  const mins = Math.round((t2 - t1) / 60000);
  const h = Math.floor(mins / 60);
  const m = mins % 60;
  return m > 0 ? `${h}h ${m}m` : `${h}h`;
};

const getStatusColorHex = (status) => {
  const s = (status || "").toUpperCase();
  if (s === "CANCELLED") return "#ef4444";
  if (s === "ARRIVED") return "#22c55e";
  if (s === "DEPARTED" || s === "IN_FLIGHT") return "#3b82f6";
  if (s === "DELAYED") return "#f59e0b";
  return null;
};

export function CrewPortal({
  crew,
  flights,
  settings,
  previewCrewPortal = false,
  currentUser,
}) {
  const t = useT();
  const { user, logout } = useAuth();
  const [activeView, setActiveView] = useState(null);
  const [drawerOpen, setDrawerOpen] = useState(false);

  /* Calendar state */
  const [selectedDateForCalendar, setSelectedDateForCalendar] = useState(
    new Date().toISOString().slice(0, 10)
  );
  const [selectedFlight, setSelectedFlight] = useState(null);

  /* File preview */
  const [previewDoc, setPreviewDoc] = useState(null);

  /* ⭐ My Aircraft Status state */
  const [camoData, setCamoData] = useState([]);
  const [melData, setMelData] = useState([]);
  const [camoLoading, setCamoLoading] = useState(false);

  /* Theme */
  const themeId = settings?.portalTheme || DEFAULT_PORTAL_THEME;
  const themeData = getPortalTheme(themeId);
  const v = themeData.vars;

  const THEME = {
    bg: v["--bg-app"],
    header: v["--bg-header"],
    card: v["--bg-card"],
    cardHover: v["--brand-primary-hover"],
    border: v["--brand-primary"],
    borderLight: v["--border-default"],
    text: v["--text-primary"],
    textMuted: v["--text-muted"],
    accent: v["--brand-primary"],
    accentHover: v["--brand-primary-hover"],
    danger: "#ef4444",
    success: "#22c55e",
    warning: "#f59e0b",
    info: v["--brand-accent"],
    gradient: v["--brand-gradient"],
  };

  /* My Hours filter */
  const [hoursFromDate, setHoursFromDate] = useState(() => {
    const d = new Date();
    d.setDate(1);
    return d.toISOString().slice(0, 10);
  });
  const [hoursToDate, setHoursToDate] = useState(() =>
    new Date().toISOString().slice(0, 10)
  );

  useEffect(() => {
    if (!drawerOpen) return;
    const onKey = (e) => {
      if (e.key === "Escape") setDrawerOpen(false);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [drawerOpen]);

  useEffect(() => {
    if (!selectedFlight) return;
    const onKey = (e) => {
      if (e.key === "Escape") setSelectedFlight(null);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [selectedFlight]);

  useEffect(() => {
    if (!previewDoc) return;
    const onKey = (e) => {
      if (e.key === "Escape") setPreviewDoc(null);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [previewDoc]);

  /* ⭐⭐⭐ currentUser أولاً ثم user ⭐⭐⭐ */
  const targetUser = currentUser || user;
  const foundCrew = crew.find(
    (c) => String(c.id) === String(targetUser?.crewId)
  );

  const myCrewData = previewCrewPortal
    ? crew[0] || { fullName: "Preview Mode" }
    : foundCrew || {
        fullName: targetUser?.fullName || "User",
        role: targetUser?.role || "Crew Member",
      };

  const canSeeFTL = true;
  const canSeeManuals = true;
  const canSeeSchedule = true;
  const canSeeCerts = true;
  const canSeeHours = true;
  const canSeeAircraft = true;

  const hasCrewLink = !!(targetUser?.crewId || user?.crewId);

  const canSeeFiles =
    previewCrewPortal ||
    hasCrewLink ||
    checkPerm(user, "crew.docs") ||
    checkPerm(user, "crew.docs_download");

  const canDownloadDocs =
    previewCrewPortal || hasCrewLink || checkPerm(user, "crew.docs_download");

  const myFlights = flights.filter((f) =>
    (f.crewSlots || []).some((slot) => slot.crewId === myCrewData.id)
  );

  /* ⭐⭐⭐ My Aircraft Status — تحميل CAMO + MEL ⭐⭐⭐ */
  useEffect(() => {
    if (!myCrewData?.id) return;
    setCamoLoading(true);
    (async () => {
      try {
        const [camo, mel] = await Promise.all([
          camoAPI.list().catch(() => []),
          melAPI.list().catch(() => []),
        ]);
        setCamoData(camo);
        setMelData(mel);
      } catch (e) {
        console.warn("CAMO/MEL load failed:", e);
      } finally {
        setCamoLoading(false);
      }
    })();
  }, [myCrewData?.id]);

  /* ⭐ حالة الطائرات المرتبطة بالطيار */
  const myAircraftStatus = useMemo(() => {
    const assigned = myCrewData?.assignedAircraft || [];
    let list = Array.isArray(assigned)
      ? assigned.map(String)
      : typeof assigned === "string"
      ? assigned.split(",").map((s) => s.trim())
      : [];

    /* إذا لم يكن معيّن → عرض كل الطائرات (للطيار) */
    const aircraft = camoData.filter((a) =>
      list.length > 0 ? list.includes(a.reg) : true
    );

    return aircraft.map((a) => {
      const mels = melData.filter(
        (m) => m.reg === a.reg && m.status === "OPEN"
      );
      const days = a.nextCheckDate ? daysUntil(a.nextCheckDate) : null;
      let status = "OPERATIONAL";
      if (a.status === "GROUNDED") status = "NOT_OPERATIONAL";
      else if (days !== null && days < 0) status = "NOT_OPERATIONAL";
      else if (mels.some((m) => m.category === "A")) status = "NOT_OPERATIONAL";
      else if (mels.length > 0 || (days !== null && days <= 30))
        status = "WITH_RESTRICTIONS";
      return { ...a, mels, days, opStatus: status };
    });
  }, [myCrewData, camoData, melData]);

  const notOperationalCount = myAircraftStatus.filter(
    (a) => a.opStatus === "NOT_OPERATIONAL"
  ).length;

  /* ═══ Compute Hours ═══ */
  const totalHours = useMemo(() => {
    const fmtHM2 = (min) => {
      if (!min || min < 0) return "0h 00m";
      const h = Math.floor(min / 60);
      const m = min % 60;
      return `${h}h ${String(m).padStart(2, "0")}m`;
    };

    const computeFor = (flightsList) => {
      let blockMin = 0;
      let flightMin = 0;
      let sectors = 0;
      const byPosition = {};

      flightsList.forEach((f) => {
        const a = f.actual || {};
        const baseStd = a.std || f.std;
        const baseSta = a.sta || f.sta;

        let bMin = 0;
        if (baseStd && baseSta) {
          const t1 = new Date(baseStd).getTime();
          const t2 = new Date(baseSta).getTime();
          if (!isNaN(t1) && !isNaN(t2) && t2 > t1) {
            bMin = Math.round((t2 - t1) / 60000);
          }
        }

        let fMin = 0;
        if (a.takeoff && a.landing) {
          const t1 = new Date(a.takeoff).getTime();
          const t2 = new Date(a.landing).getTime();
          if (!isNaN(t1) && !isNaN(t2) && t2 > t1) {
            fMin = Math.round((t2 - t1) / 60000);
          }
        }

        blockMin += bMin;
        flightMin += fMin;
        sectors += 1;

        const slots = Array.isArray(f.crewSlots)
          ? f.crewSlots
          : JSON.parse(f.crewSlots || "[]");
        slots
          .filter((s) => s.crewId === myCrewData.id)
          .forEach((slot) => {
            const pos =
              POS_SHORT_MAP[slot.position] ||
              slot.position?.toUpperCase() ||
              "—";
            if (!byPosition[pos]) byPosition[pos] = { blockMin: 0, sectors: 0 };
            byPosition[pos].blockMin += bMin;
            byPosition[pos].sectors += 1;
          });
      });

      return {
        blockMin,
        flightMin,
        sectors,
        byPosition,
        blockHM: fmtHM2(blockMin),
        flightHM: fmtHM2(flightMin),
      };
    };

    const all = computeFor(myFlights);
    const fromTs = hoursFromDate
      ? new Date(hoursFromDate + "T00:00:00Z").getTime()
      : null;
    const toTs = hoursToDate
      ? new Date(hoursToDate + "T23:59:59Z").getTime()
      : null;

    const filteredFlights = myFlights.filter((f) => {
      const a = f.actual || {};
      const baseStd = a.std || f.std;
      if (!baseStd) return false;
      const tt = new Date(baseStd).getTime();
      if (isNaN(tt)) return false;
      if (fromTs !== null && tt < fromTs) return false;
      if (toTs !== null && tt > toTs) return false;
      return true;
    });

    const filtered = computeFor(filteredFlights);
    const isFiltered =
      (hoursFromDate || hoursToDate) &&
      (filteredFlights.length !== myFlights.length ||
        hoursFromDate ||
        hoursToDate);

    return {
      all,
      filtered,
      filteredCount: filteredFlights.length,
      isFiltered,
      totalBlockMin: all.blockMin,
      totalFlightMin: all.flightMin,
      sectors: all.sectors,
      byPosition: all.byPosition,
      blockHM: all.blockHM,
      flightHM: all.flightHM,
    };
  }, [myFlights, myCrewData.id, hoursFromDate, hoursToDate]);

  const myAttachments = useMemo(() => {
    const raw = getDocs(myCrewData);
    return raw.map((d, i) => normalizeDoc(d, i)).filter(Boolean);
  }, [myCrewData]);

  const setRange = (range) => {
    const today = new Date();
    const to = today.toISOString().slice(0, 10);
    if (range === "thisMonth") {
      const d = new Date(today.getFullYear(), today.getMonth(), 1);
      setHoursFromDate(d.toISOString().slice(0, 10));
      setHoursToDate(to);
    } else if (range === "last30") {
      const d = new Date(today);
      d.setDate(d.getDate() - 30);
      setHoursFromDate(d.toISOString().slice(0, 10));
      setHoursToDate(to);
    } else if (range === "thisYear") {
      const d = new Date(today.getFullYear(), 0, 1);
      setHoursFromDate(d.toISOString().slice(0, 10));
      setHoursToDate(to);
    } else if (range === "all") {
      setHoursFromDate("");
      setHoursToDate("");
    }
  };

  const handleLogout = () => {
    if (!confirm("هل تريد تسجيل الخروج؟")) return;
    setDrawerOpen(false);
    if (typeof logout === "function") logout();
    else {
      localStorage.clear();
      window.location.reload();
    }
  };

  const getMyPosition = (flight) => {
    const slot = (flight.crewSlots || []).find(
      (s) => s.crewId === myCrewData.id
    );
    return POS_SHORT_MAP[slot?.position] || slot?.position || "—";
  };

  const navItems = [
    { id: "home", icon: Home, label: "Home" },
    {
      id: "schedule",
      icon: Calendar,
      label: "My Schedule",
      show: canSeeSchedule,
    },
    {
      id: "aircraft-status",
      icon: Plane,
      label: "My Aircraft",
      show: canSeeAircraft,
    },
    {
      id: "certificates",
      icon: Award,
      label: "Certificates",
      show: canSeeCerts,
    },
    { id: "ftl", icon: Clock, label: "FTL", show: canSeeFTL },
    { id: "manuals", icon: BookOpen, label: "Manuals", show: canSeeManuals },
    { id: "hours", icon: TrendingUp, label: "My Hours", show: canSeeHours },
  ];

  return (
    <div
      className="min-h-screen font-sans theme-transition"
      style={{ backgroundColor: THEME.bg, color: THEME.text }}
      dir="ltr"
    >
      {previewCrewPortal && (
        <div className="bg-amber-500 text-white text-xs font-bold py-1.5 px-3 text-center">
          👁️ وضع المعاينة (Admin Preview)
        </div>
      )}

      {/* ═══ Header ═══ */}
      <header
        className="sticky top-0 z-30 shadow-md"
        style={{
          backgroundColor: THEME.header,
          backdropFilter: "blur(12px)",
          borderBottom: `1px solid ${THEME.borderLight}`,
        }}
      >
        <div className="max-w-6xl mx-auto flex items-center gap-3 px-4 py-3">
          <button
            onClick={() => setDrawerOpen(true)}
            className="p-1.5 rounded-lg hover:bg-white/10 transition"
            aria-label="Open menu"
          >
            <Menu className="w-6 h-6" style={{ color: THEME.text }} />
          </button>
          <h1
            className="text-xl font-bold flex-1"
            style={{ color: THEME.text }}
          >
            Dashboard
          </h1>
          <div
            className="hidden sm:flex items-center gap-2 text-xs"
            style={{ color: THEME.textMuted }}
          >
            <User className="w-4 h-4" />
            <span className="font-bold" style={{ color: THEME.text }}>
              {myCrewData.fullName || "User"}
            </span>
          </div>
          <button
            onClick={handleLogout}
            className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-rose-600/80 hover:bg-rose-600 text-white text-xs font-bold"
            title="تسجيل الخروج"
          >
            <LogOut className="w-4 h-4" />
            <span>Exit</span>
          </button>
        </div>
      </header>

      {/* ═══ Drawer ═══ */}
      {drawerOpen && (
        <>
          <div
            className="fixed inset-0 z-40 bg-black/60 backdrop-blur-sm"
            onClick={() => setDrawerOpen(false)}
          />
          <aside
            className="fixed top-0 left-0 bottom-0 z-50 w-72 max-w-[85vw] shadow-2xl flex flex-col"
            style={{
              backgroundColor: THEME.header,
              borderRight: `1px solid ${THEME.borderLight}`,
            }}
          >
            <div
              className="p-4 flex items-center justify-between"
              style={{ borderBottom: `1px solid ${THEME.borderLight}` }}
            >
              <div className="flex items-center gap-3">
                <div
                  className="w-10 h-10 rounded-full flex items-center justify-center font-bold text-white shadow-md"
                  style={{ background: THEME.gradient }}
                >
                  {(myCrewData.fullName || "U")
                    .split(" ")
                    .map((x) => x[0])
                    .join("")
                    .slice(0, 2)
                    .toUpperCase()}
                </div>
                <div className="min-w-0">
                  <div
                    className="font-bold text-sm truncate"
                    style={{ color: THEME.text }}
                  >
                    {myCrewData.fullName || "User"}
                  </div>
                  <div
                    className="text-[10px] truncate"
                    style={{ color: THEME.textMuted }}
                  >
                    {myCrewData.role || user?.role || "Crew Member"}
                  </div>
                </div>
              </div>
              <button
                onClick={() => setDrawerOpen(false)}
                className="p-1.5 rounded-lg hover:bg-white/10"
                aria-label="Close"
              >
                <X className="w-5 h-5" style={{ color: THEME.text }} />
              </button>
            </div>

            <nav className="flex-1 overflow-y-auto p-2">
              {navItems
                .filter((n) => n.show !== false)
                .map((item) => {
                  const Icon = item.icon;
                  const active =
                    activeView === item.id ||
                    (item.id === "home" && !activeView);
                  return (
                    <button
                      key={item.id}
                      onClick={() => {
                        setActiveView(item.id === "home" ? null : item.id);
                        setDrawerOpen(false);
                      }}
                      className="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm transition mb-1 font-semibold"
                      style={
                        active
                          ? { background: THEME.gradient, color: "white" }
                          : { color: THEME.textMuted }
                      }
                      onMouseEnter={(e) => {
                        if (!active)
                          e.currentTarget.style.backgroundColor =
                            "rgba(255,255,255,0.08)";
                      }}
                      onMouseLeave={(e) => {
                        if (!active) e.currentTarget.style.backgroundColor = "";
                      }}
                    >
                      <Icon className="w-4 h-4" />
                      <span>{item.label}</span>
                    </button>
                  );
                })}
            </nav>

            <div
              className="p-3"
              style={{ borderTop: `1px solid ${THEME.borderLight}` }}
            >
              <button
                onClick={handleLogout}
                className="w-full flex items-center justify-center gap-2 px-3 py-2.5 rounded-lg bg-rose-600 hover:bg-rose-700 text-white text-sm font-bold"
              >
                <LogOut className="w-4 h-4" />
                تسجيل الخروج
              </button>
            </div>
          </aside>
        </>
      )}

      {/* ═══ Main content ═══ */}
      <main className="max-w-6xl mx-auto">
        <div className="px-4 py-3 text-sm" style={{ color: THEME.textMuted }}>
          Welcome,{" "}
          <span className="font-bold" style={{ color: THEME.text }}>
            {myCrewData.fullName || "User"}
          </span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3 p-4 pb-20">
          {canSeeSchedule && (
            <PortalCard
              icon={Calendar}
              label="My Schedule"
              onClick={() => setActiveView("schedule")}
              THEME={THEME}
            />
          )}

          {canSeeAircraft && (
            <button
              onClick={() => setActiveView("aircraft-status")}
              className="relative aspect-square rounded-xl flex flex-col items-center justify-center p-3 transition shadow-lg border-2 active:scale-[0.98] overflow-hidden group"
              style={{
                background: "linear-gradient(135deg, #3b82f6, #8b5cf6)",
                borderColor: THEME.info,
                boxShadow: "var(--shadow-lg)",
              }}
            >
              <Plane
                className="w-12 h-12 sm:w-14 sm:h-14 text-white mb-2 sm:mb-3 drop-shadow-lg group-hover:scale-110 transition-transform"
                strokeWidth={2}
              />
              <span className="text-[11px] sm:text-xs font-bold text-center uppercase tracking-wider text-white relative z-10">
                My Aircraft
                <br />
                Status
              </span>
              {notOperationalCount > 0 && (
                <span className="absolute top-2 end-2 px-2 py-0.5 rounded-full bg-rose-500 text-white text-[10px] font-bold shadow-lg">
                  {notOperationalCount} 🔴
                </span>
              )}
              {notOperationalCount === 0 && myAircraftStatus.length > 0 && (
                <span className="absolute top-2 end-2 px-2 py-0.5 rounded-full bg-emerald-500 text-white text-[10px] font-bold shadow-lg">
                  {myAircraftStatus.length} ✅
                </span>
              )}
            </button>
          )}

          {canSeeCerts && (
            <PortalCard
              icon={Award}
              label="Certificates"
              onClick={() => setActiveView("certificates")}
              badge={
                canSeeFiles && myAttachments.length > 0
                  ? myAttachments.length
                  : null
              }
              badgeColor="emerald"
              THEME={THEME}
            />
          )}

          {canSeeFTL && (
            <PortalCard
              icon={Clock}
              label="FTL"
              onClick={() => setActiveView("ftl")}
              THEME={THEME}
            />
          )}
          {canSeeManuals && (
            <PortalCard
              icon={BookOpen}
              label="Manuals"
              onClick={() => setActiveView("manuals")}
              THEME={THEME}
            />
          )}

          {canSeeHours && (
            <button
              onClick={() => setActiveView("hours")}
              className="relative aspect-square rounded-xl flex flex-col items-center justify-center p-3 transition shadow-lg border-2 active:scale-[0.98] overflow-hidden group"
              style={{
                background: THEME.gradient,
                borderColor: THEME.info,
                boxShadow: "var(--shadow-lg)",
              }}
            >
              <TrendingUp
                className="w-12 h-12 sm:w-14 sm:h-14 text-white mb-2 sm:mb-3 drop-shadow-lg group-hover:scale-110 transition-transform"
                strokeWidth={2}
              />
              <span className="text-[11px] sm:text-xs font-bold text-center uppercase tracking-wider text-white relative z-10">
                My Hours
              </span>
              {totalHours.totalBlockMin > 0 && (
                <span className="absolute top-2 end-2 px-2 py-0.5 rounded-full bg-white/20 backdrop-blur-sm text-white text-[9px] font-mono font-bold border border-white/30">
                  {Math.floor(totalHours.totalBlockMin / 60)}h
                </span>
              )}
            </button>
          )}
        </div>
      </main>

      {/* ═══ Overlay Views ═══ */}
      {activeView && (
        <div
          className="fixed inset-0 z-50 overflow-y-auto"
          style={{ backgroundColor: THEME.bg }}
        >
          <div
            className="sticky top-0 z-10 shadow-md"
            style={{
              backgroundColor: THEME.header,
              backdropFilter: "blur(12px)",
              borderBottom: `1px solid ${THEME.borderLight}`,
            }}
          >
            <div className="max-w-6xl mx-auto p-3 flex justify-between items-center">
              <h2
                className="font-bold text-lg capitalize"
                style={{ color: THEME.text }}
              >
                {activeView === "schedule"
                  ? "My Schedule"
                  : activeView === "aircraft-status"
                  ? "My Aircraft Status"
                  : activeView}
              </h2>
              <button
                onClick={() => setActiveView(null)}
                className="p-2 rounded-full transition"
                style={{
                  backgroundColor: THEME.card,
                  border: `1px solid ${THEME.borderLight}`,
                }}
              >
                <X className="w-5 h-5" style={{ color: THEME.text }} />
              </button>
            </div>
          </div>

          <div className="max-w-6xl mx-auto p-4">
            {/* ═══════════ SCHEDULE ═══════════ */}
            {activeView === "schedule" && (
              <CalendarView
                flights={myFlights}
                selectedDate={selectedDateForCalendar}
                setSelectedDate={setSelectedDateForCalendar}
                timeMode="UTC"
                isPast={(f) => {
                  if (!f.std) return false;
                  const a = f.actual || {};
                  const isCompleted = a.std && a.sta;
                  if (isCompleted) return false;
                  return (
                    new Date(f.std).getTime() < Date.now() - 30 * 60 * 1000
                  );
                }}
                crew={crew}
                onSelectFlight={(flight) => setSelectedFlight(flight)}
              />
            )}

            {/* ═══════════ MY AIRCRAFT STATUS ═══════════ */}
            {activeView === "aircraft-status" && (
              <div className="space-y-3">
                {camoLoading ? (
                  <div
                    className="text-center py-12"
                    style={{ color: THEME.textMuted }}
                  >
                    Loading aircraft data...
                  </div>
                ) : myAircraftStatus.length === 0 ? (
                  <div
                    className="text-center py-12 rounded-xl"
                    style={{
                      backgroundColor: THEME.card,
                      border: `1px solid ${THEME.borderLight}`,
                    }}
                  >
                    <Plane
                      className="w-12 h-12 mx-auto mb-2 opacity-30"
                      style={{ color: THEME.textMuted }}
                    />
                    <div style={{ color: THEME.textMuted }}>
                      No aircraft assigned
                    </div>
                  </div>
                ) : (
                  myAircraftStatus.map((a) => {
                    const statusColor =
                      a.opStatus === "OPERATIONAL"
                        ? {
                            bg: "bg-emerald-500/15",
                            text: "text-emerald-500",
                            icon: "✅",
                          }
                        : a.opStatus === "WITH_RESTRICTIONS"
                        ? {
                            bg: "bg-amber-500/15",
                            text: "text-amber-500",
                            icon: "⚠️",
                          }
                        : {
                            bg: "bg-rose-500/15",
                            text: "text-rose-500",
                            icon: "🔴",
                          };
                    return (
                      <div
                        key={a.id}
                        className="rounded-xl p-4 space-y-2"
                        style={{
                          backgroundColor: THEME.card,
                          border: `1px solid ${THEME.borderLight}`,
                        }}
                      >
                        <div className="flex justify-between items-start">
                          <div>
                            <div
                              className="font-bold font-mono text-lg"
                              style={{ color: THEME.text }}
                            >
                              {a.reg}
                            </div>
                            <div
                              className="text-xs"
                              style={{ color: THEME.textMuted }}
                            >
                              {a.type}
                            </div>
                          </div>
                          <span
                            className={`px-2 py-1 rounded text-xs font-bold ${statusColor.bg} ${statusColor.text}`}
                          >
                            {statusColor.icon} {a.opStatus.replace("_", " ")}
                          </span>
                        </div>

                        <div className="grid grid-cols-2 gap-2 text-xs">
                          <div
                            className="p-2 rounded"
                            style={{
                              backgroundColor: "rgba(255,255,255,0.05)",
                            }}
                          >
                            <div style={{ color: THEME.textMuted }}>
                              Next Check
                            </div>
                            <div
                              className="font-bold"
                              style={{ color: THEME.text }}
                            >
                              {a.nextCheckDate
                                ? String(a.nextCheckDate).slice(0, 10)
                                : "—"}{" "}
                              {a.days !== null && (
                                <span
                                  className={
                                    a.days < 0
                                      ? "text-rose-500"
                                      : a.days <= 30
                                      ? "text-amber-500"
                                      : ""
                                  }
                                >
                                  (
                                  {a.days < 0
                                    ? `${Math.abs(a.days)}d overdue`
                                    : `${a.days}d`}
                                  )
                                </span>
                              )}
                            </div>
                          </div>
                          <div
                            className="p-2 rounded"
                            style={{
                              backgroundColor: "rgba(255,255,255,0.05)",
                            }}
                          >
                            <div style={{ color: THEME.textMuted }}>
                              TAH / TAC
                            </div>
                            <div
                              className="font-bold font-mono"
                              style={{ color: THEME.text }}
                            >
                              {a.tah?.toLocaleString() || 0} /{" "}
                              {a.tac?.toLocaleString() || 0}
                            </div>
                          </div>
                        </div>

                        {a.mels.length > 0 && (
                          <div className="p-2 rounded bg-amber-500/15 border border-amber-500/30 text-xs">
                            <div className="font-bold text-amber-500 mb-1">
                              <AlertTriangle className="w-3.5 h-3.5 inline" />{" "}
                              {a.mels.length} MEL open
                            </div>
                            {a.mels.slice(0, 3).map((m) => (
                              <div key={m.id} className="text-[10px]">
                                • {m.item} ({m.category}) -{" "}
                                {m.restrictions || "No restrictions"}
                              </div>
                            ))}
                            {a.mels.length > 3 && (
                              <div className="text-[10px] opacity-70 mt-1">
                                +{a.mels.length - 3} more...
                              </div>
                            )}
                          </div>
                        )}
                      </div>
                    );
                  })
                )}
              </div>
            )}

            {/* ═══════════ CERTIFICATES ═══════════ */}
            {activeView === "certificates" && (
              <div className="space-y-6">
                <div>
                  <h3
                    className="font-bold mb-3 flex items-center gap-2"
                    style={{ color: THEME.textMuted }}
                  >
                    <Award className="w-5 h-5" /> Certificates Info
                  </h3>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                    {[
                      {
                        label: "License No",
                        value: myCrewData.licenseNo,
                        exp: myCrewData.licenseExpiry,
                      },
                      {
                        label: "Medical",
                        value: myCrewData.medicalExpiry ? "Valid" : "N/A",
                        exp: myCrewData.medicalExpiry,
                      },
                      {
                        label: "Passport No",
                        value: myCrewData.passportNo,
                        exp: myCrewData.passportExpiry,
                      },
                    ].map((doc, idx) => (
                      <div
                        key={idx}
                        className="p-3 rounded-lg border"
                        style={{
                          backgroundColor: THEME.card,
                          borderColor: THEME.borderLight,
                        }}
                      >
                        <div
                          className="font-bold"
                          style={{ color: THEME.text }}
                        >
                          {doc.label}
                        </div>
                        <div
                          className="text-sm"
                          style={{ color: THEME.textMuted }}
                        >
                          {doc.value || "—"}
                        </div>
                        {doc.exp && (
                          <div className="text-xs text-yellow-500">
                            Expiry: {doc.exp}
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </div>

                {canSeeFiles && (
                  <div>
                    <h3
                      className="font-bold mb-3 flex items-center gap-2"
                      style={{ color: THEME.textMuted }}
                    >
                      <FileText className="w-5 h-5" /> Attached Files (
                      {myAttachments.length})
                    </h3>

                    {(() => {
                      const expired = myAttachments.filter(
                        (d) => docStatus(d.expiry) === "expired"
                      ).length;
                      const critical = myAttachments.filter(
                        (d) => docStatus(d.expiry) === "critical"
                      ).length;
                      if (expired === 0 && critical === 0) return null;
                      return (
                        <div className="mb-3 space-y-2">
                          {expired > 0 && (
                            <div className="p-2.5 bg-rose-500/20 border border-rose-400 rounded-lg text-rose-300 text-xs flex items-center gap-2 font-bold">
                              <ShieldAlert className="w-4 h-4" />
                              ⚠️ {expired} مستند منتهي الصلاحية — يرجى التجديد
                            </div>
                          )}
                          {critical > 0 && (
                            <div className="p-2.5 bg-orange-500/20 border border-orange-400 rounded-lg text-orange-300 text-xs flex items-center gap-2 font-bold">
                              <ShieldAlert className="w-4 h-4" />⏰ {critical}{" "}
                              مستند ينتهي خلال 15 يوم
                            </div>
                          )}
                        </div>
                      );
                    })()}

                    {myAttachments.length === 0 ? (
                      <div
                        className="text-center py-8 rounded-xl border"
                        style={{
                          backgroundColor: THEME.card,
                          borderColor: THEME.borderLight,
                        }}
                      >
                        <FileText
                          className="w-10 h-10 mx-auto mb-2 opacity-50"
                          style={{ color: THEME.textMuted }}
                        />
                        <p
                          className="text-sm"
                          style={{ color: THEME.textMuted }}
                        >
                          لا توجد ملفات مرفقة
                        </p>
                      </div>
                    ) : (
                      <div className="space-y-2">
                        {myAttachments.map((doc, idx) => {
                          const st = docStatus(doc.expiry);
                          const days = daysUntil(doc.expiry);
                          const colorCls = getStatusColor(st);
                          const cardBorder =
                            st === "expired"
                              ? {
                                  borderColor: "#f43f5e",
                                  backgroundColor: "rgba(244,63,94,0.12)",
                                }
                              : st === "critical"
                              ? {
                                  borderColor: "#fb923c",
                                  backgroundColor: "rgba(251,146,60,0.12)",
                                }
                              : st === "expiring"
                              ? {
                                  borderColor: "#f59e0b",
                                  backgroundColor: "rgba(245,158,11,0.1)",
                                }
                              : {
                                  borderColor: THEME.borderLight,
                                  backgroundColor: THEME.card,
                                };

                          return (
                            <div
                              key={idx}
                              className="p-3 rounded-xl border flex items-center justify-between gap-3 transition hover:shadow-md"
                              style={cardBorder}
                            >
                              <div className="flex items-center gap-3 min-w-0 flex-1">
                                <div
                                  className="w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0"
                                  style={{
                                    backgroundColor:
                                      st === "expired"
                                        ? "rgba(244,63,94,0.2)"
                                        : st === "critical"
                                        ? "rgba(251,146,60,0.2)"
                                        : st === "expiring"
                                        ? "rgba(245,158,11,0.2)"
                                        : "rgba(255,255,255,0.1)",
                                  }}
                                >
                                  <FileText
                                    className="w-5 h-5"
                                    style={{
                                      color:
                                        st === "expired"
                                          ? "#f43f5e"
                                          : st === "critical"
                                          ? "#fb923c"
                                          : st === "expiring"
                                          ? "#f59e0b"
                                          : THEME.text,
                                    }}
                                  />
                                </div>

                                <div className="min-w-0 flex-1">
                                  <div
                                    className="font-bold text-sm truncate"
                                    style={{ color: THEME.text }}
                                    title={doc.name}
                                  >
                                    {doc.name.replace(/\.[^/.]+$/, "")}
                                  </div>
                                  {doc.expiry && days !== null && (
                                    <div className="flex items-center gap-2 flex-wrap mt-1">
                                      <span
                                        className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[10px] font-mono"
                                        style={{
                                          backgroundColor:
                                            "rgba(255,255,255,0.08)",
                                          color: THEME.textMuted,
                                        }}
                                      >
                                        📅 {String(doc.expiry).slice(0, 10)}
                                      </span>
                                      <span
                                        className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[10px] font-bold border ${colorCls}`}
                                      >
                                        {days < 0
                                          ? `منتهي منذ ${Math.abs(days)} يوم`
                                          : days === 0
                                          ? "ينتهي اليوم"
                                          : `${days} يوم متبقٍ`}
                                      </span>
                                    </div>
                                  )}
                                </div>
                              </div>

                              {doc.url ? (
                                <div className="flex items-center gap-1">
                                  <button
                                    onClick={() => setPreviewDoc(doc)}
                                    className="w-9 h-9 rounded-lg flex items-center justify-center flex-shrink-0 transition hover:bg-white/20"
                                    style={{
                                      backgroundColor: "rgba(255,255,255,0.1)",
                                      color: THEME.text,
                                    }}
                                    title="عرض"
                                  >
                                    <Eye className="w-4 h-4" />
                                  </button>
                                  <a
                                    href={doc.url}
                                    target="_blank"
                                    rel="noopener noreferrer"
                                    download={
                                      canDownloadDocs ? doc.name : undefined
                                    }
                                    className="w-9 h-9 rounded-lg flex items-center justify-center flex-shrink-0 transition hover:bg-white/20"
                                    style={{
                                      backgroundColor: "rgba(255,255,255,0.1)",
                                      color: THEME.text,
                                    }}
                                    title="تحميل"
                                  >
                                    <Download className="w-4 h-4" />
                                  </a>
                                </div>
                              ) : (
                                <span className="text-[10px] text-red-300 italic">
                                  رابط غير متاح
                                </span>
                              )}
                            </div>
                          );
                        })}
                      </div>
                    )}
                  </div>
                )}

                {!canSeeFiles && (
                  <div className="p-3 bg-amber-900/30 border border-amber-700 rounded-lg text-amber-200 text-xs flex items-center gap-2">
                    <ShieldAlert className="w-4 h-4" /> ليس لديك صلاحية عرض
                    الملفات المرفقة
                  </div>
                )}
              </div>
            )}

            {/* ═══════════ FTL ═══════════ */}
            {activeView === "ftl" && (
              <div className="bg-white rounded-lg p-2 text-black">
                <FTLModule crew={[myCrewData]} flights={myFlights} />
              </div>
            )}

            {/* ═══════════ MANUALS ═══════════ */}
            {activeView === "manuals" && (
              <div className="bg-white rounded-lg p-2 text-black">
                <ManualsModule
                  settings={settings}
                  companyName={settings?.companyName}
                />
              </div>
            )}

            {/* ═══════════ HOURS ═══════════ */}
            {activeView === "hours" && (
              <div className="space-y-4">
                {/* All Time */}
                <div>
                  <h3
                    className="font-bold mb-2 text-sm uppercase tracking-wider flex items-center gap-2"
                    style={{ color: THEME.textMuted }}
                  >
                    <Activity
                      className="w-4 h-4"
                      style={{ color: THEME.success }}
                    />
                    All Time Totals
                  </h3>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    <div className="relative bg-gradient-to-br from-sky-600 to-sky-800 p-5 rounded-2xl shadow-xl border border-sky-400/40 overflow-hidden">
                      <div className="text-sky-100 text-xs font-bold uppercase tracking-wider flex items-center gap-1 mb-2">
                        <Timer className="w-3.5 h-3.5" /> Total Block
                      </div>
                      <div className="text-4xl font-black font-mono text-white drop-shadow-lg">
                        {totalHours.all.blockHM}
                      </div>
                      <div className="mt-1 text-sky-200 text-[10px] font-mono">
                        All flights
                      </div>
                    </div>

                    <div className="relative bg-gradient-to-br from-amber-600 to-orange-700 p-5 rounded-2xl shadow-xl border border-amber-400/40 overflow-hidden">
                      <div className="text-amber-100 text-xs font-bold uppercase tracking-wider flex items-center gap-1 mb-2">
                        <Activity className="w-3.5 h-3.5" /> Total Sectors
                      </div>
                      <div className="text-4xl font-black font-mono text-white drop-shadow-lg">
                        {totalHours.all.sectors}
                      </div>
                      <div className="mt-1 text-amber-200 text-[10px] font-mono">
                        All flights
                      </div>
                    </div>
                  </div>
                </div>

                {/* Filter */}
                <div
                  className="p-4 rounded-2xl border shadow-xl"
                  style={{
                    backgroundColor: THEME.card,
                    borderColor: THEME.borderLight,
                  }}
                >
                  <div className="flex items-center justify-between mb-3 flex-wrap gap-2">
                    <h3
                      className="font-bold text-sm flex items-center gap-2 uppercase tracking-wider"
                      style={{ color: THEME.text }}
                    >
                      <Calendar
                        className="w-4 h-4"
                        style={{ color: THEME.accent }}
                      />
                      Filter by Period
                    </h3>
                    <div
                      className="text-[10px] font-mono"
                      style={{ color: THEME.textMuted }}
                    >
                      {totalHours.filteredCount}{" "}
                      {totalHours.filteredCount === 1 ? "flight" : "flights"} in
                      range
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-2 mb-3">
                    <div>
                      <label
                        className="text-[10px] font-bold uppercase block mb-1"
                        style={{ color: THEME.textMuted }}
                      >
                        📅 From
                      </label>
                      <input
                        type="date"
                        value={hoursFromDate}
                        onChange={(e) => setHoursFromDate(e.target.value)}
                        className="w-full px-3 py-2 rounded-lg text-sm font-mono focus:outline-none"
                        style={{
                          backgroundColor: "rgba(255,255,255,0.1)",
                          border: `1px solid ${THEME.borderLight}`,
                          color: THEME.text,
                        }}
                      />
                    </div>
                    <div>
                      <label
                        className="text-[10px] font-bold uppercase block mb-1"
                        style={{ color: THEME.textMuted }}
                      >
                        📅 To
                      </label>
                      <input
                        type="date"
                        value={hoursToDate}
                        onChange={(e) => setHoursToDate(e.target.value)}
                        className="w-full px-3 py-2 rounded-lg text-sm font-mono focus:outline-none"
                        style={{
                          backgroundColor: "rgba(255,255,255,0.1)",
                          border: `1px solid ${THEME.borderLight}`,
                          color: THEME.text,
                        }}
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5">
                    {[
                      { r: "thisMonth", l: "📅 This Month" },
                      { r: "last30", l: "⏱️ Last 30 Days" },
                      { r: "thisYear", l: "🗓️ This Year" },
                      { r: "all", l: "♾️ All Time" },
                    ].map((btn) => (
                      <button
                        key={btn.r}
                        onClick={() => setRange(btn.r)}
                        className="px-2 py-1.5 rounded-lg text-[10px] font-bold transition border"
                        style={{
                          backgroundColor: "rgba(255,255,255,0.08)",
                          color: THEME.text,
                          borderColor: THEME.borderLight,
                        }}
                      >
                        {btn.l}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Filtered */}
                <div>
                  <h3
                    className="font-bold mb-2 text-sm uppercase tracking-wider flex items-center gap-2"
                    style={{ color: THEME.textMuted }}
                  >
                    <Calendar
                      className="w-4 h-4"
                      style={{ color: THEME.info }}
                    />
                    Filtered Totals
                    {totalHours.isFiltered && (
                      <span
                        className="px-2 py-0.5 rounded-full text-[10px] font-mono normal-case"
                        style={{
                          backgroundColor: `${THEME.accent}30`,
                          color: THEME.accent,
                        }}
                      >
                        {hoursFromDate || "—"} → {hoursToDate || "—"}
                      </span>
                    )}
                  </h3>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    <div className="relative bg-gradient-to-br from-emerald-700 to-emerald-900 p-5 rounded-2xl shadow-xl border border-emerald-500/40">
                      <div className="text-emerald-100 text-xs font-bold uppercase tracking-wider flex items-center gap-1 mb-2">
                        <Plane className="w-3.5 h-3.5" /> Flight (Filtered)
                      </div>
                      <div className="text-4xl font-black font-mono text-white drop-shadow-lg">
                        {totalHours.filtered.flightHM}
                      </div>
                      <div className="mt-1 text-emerald-200 text-[10px] font-mono">
                        {totalHours.filteredCount} flights
                      </div>
                    </div>

                    <div className="relative bg-gradient-to-br from-sky-700 to-sky-900 p-5 rounded-2xl shadow-xl border border-sky-500/40">
                      <div className="text-sky-100 text-xs font-bold uppercase tracking-wider flex items-center gap-1 mb-2">
                        <Timer className="w-3.5 h-3.5" /> Block (Filtered)
                      </div>
                      <div className="text-4xl font-black font-mono text-white drop-shadow-lg">
                        {totalHours.filtered.blockHM}
                      </div>
                      <div className="mt-1 text-sky-200 text-[10px] font-mono">
                        {totalHours.filteredCount} flights
                      </div>
                    </div>

                    <div className="relative bg-gradient-to-br from-amber-700 to-orange-800 p-5 rounded-2xl shadow-xl border border-amber-500/40">
                      <div className="text-amber-100 text-xs font-bold uppercase tracking-wider flex items-center gap-1 mb-2">
                        <Activity className="w-3.5 h-3.5" /> Sectors (Filtered)
                      </div>
                      <div className="text-4xl font-black font-mono text-white drop-shadow-lg">
                        {totalHours.filtered.sectors}
                      </div>
                      <div className="mt-1 text-amber-200 text-[10px] font-mono">
                        in range
                      </div>
                    </div>
                  </div>
                </div>

                {/* All Time by Position */}
                {Object.keys(totalHours.all.byPosition).length > 0 && (
                  <div
                    className="p-4 rounded-2xl border shadow-xl"
                    style={{
                      backgroundColor: THEME.card,
                      borderColor: THEME.borderLight,
                    }}
                  >
                    <h3
                      className="font-bold mb-3 flex items-center gap-2 text-sm uppercase tracking-wider"
                      style={{ color: THEME.text }}
                    >
                      <Target
                        className="w-4 h-4"
                        style={{ color: THEME.info }}
                      />
                      All Time — By Position
                    </h3>
                    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2">
                      {Object.entries(totalHours.all.byPosition)
                        .sort(
                          ([a], [b]) =>
                            POS_ORDER.indexOf(a) - POS_ORDER.indexOf(b)
                        )
                        .map(([pos, data]) => (
                          <div
                            key={pos}
                            className="rounded-xl p-3 border"
                            style={{
                              backgroundColor: "rgba(255,255,255,0.08)",
                              borderColor: THEME.borderLight,
                            }}
                          >
                            <div className="flex items-center justify-between mb-1">
                              <span
                                className="font-bold font-mono text-sm"
                                style={{ color: THEME.text }}
                              >
                                {pos}
                              </span>
                              <span
                                className="text-[9px] font-mono"
                                style={{ color: THEME.textMuted }}
                              >
                                {data.sectors} sec
                              </span>
                            </div>
                            <div
                              className="text-xl font-black font-mono"
                              style={{ color: THEME.text }}
                            >
                              {(() => {
                                const h = Math.floor(data.blockMin / 60);
                                const m = data.blockMin % 60;
                                return `${h}h ${String(m).padStart(2, "0")}m`;
                              })()}
                            </div>
                          </div>
                        ))}
                    </div>
                  </div>
                )}

                {/* Filtered by Position */}
                {totalHours.isFiltered &&
                  Object.keys(totalHours.filtered.byPosition).length > 0 && (
                    <div
                      className="p-4 rounded-2xl border shadow-xl"
                      style={{
                        backgroundColor: THEME.card,
                        borderColor: THEME.borderLight,
                      }}
                    >
                      <h3
                        className="font-bold mb-3 flex items-center gap-2 text-sm uppercase tracking-wider"
                        style={{ color: THEME.text }}
                      >
                        <Calendar
                          className="w-4 h-4"
                          style={{ color: THEME.info }}
                        />
                        Filtered — By Position
                      </h3>
                      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2">
                        {Object.entries(totalHours.filtered.byPosition)
                          .sort(
                            ([a], [b]) =>
                              POS_ORDER.indexOf(a) - POS_ORDER.indexOf(b)
                          )
                          .map(([pos, data]) => (
                            <div
                              key={pos}
                              className="rounded-xl p-3 border"
                              style={{
                                backgroundColor: "rgba(255,255,255,0.08)",
                                borderColor: THEME.borderLight,
                              }}
                            >
                              <div className="flex items-center justify-between mb-1">
                                <span
                                  className="font-bold font-mono text-sm"
                                  style={{ color: THEME.text }}
                                >
                                  {pos}
                                </span>
                                <span
                                  className="text-[9px] font-mono"
                                  style={{ color: THEME.textMuted }}
                                >
                                  {data.sectors} sec
                                </span>
                              </div>
                              <div
                                className="text-xl font-black font-mono"
                                style={{ color: THEME.text }}
                              >
                                {(() => {
                                  const h = Math.floor(data.blockMin / 60);
                                  const m = data.blockMin % 60;
                                  return `${h}h ${String(m).padStart(2, "0")}m`;
                                })()}
                              </div>
                            </div>
                          ))}
                      </div>
                    </div>
                  )}

                <div
                  className="p-3 rounded-xl border text-[10px] italic flex items-start gap-2"
                  style={{
                    backgroundColor: "rgba(255,255,255,0.05)",
                    borderColor: THEME.borderLight,
                    color: THEME.textMuted,
                  }}
                >
                  <ShieldAlert className="w-3.5 h-3.5 flex-shrink-0 mt-0.5" />
                  <span>
                    All Time shows every completed flight. Filtered shows only
                    the selected range. Block is unique per flight (not
                    duplicated if assigned to multiple positions on same
                    flight).
                  </span>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* ═══ Flight Details Modal ═══ */}
      {selectedFlight && (
        <div
          className="fixed inset-0 z-[60] flex items-center justify-center p-4"
          style={{
            backgroundColor: "rgba(0,0,0,0.7)",
            backdropFilter: "blur(4px)",
          }}
          onClick={() => setSelectedFlight(null)}
        >
          <div
            className="rounded-2xl shadow-2xl max-w-lg w-full overflow-hidden max-h-[90vh] overflow-y-auto"
            style={{
              backgroundColor: THEME.card,
              border: `2px solid ${THEME.border}`,
            }}
            onClick={(e) => e.stopPropagation()}
          >
            <div
              className="p-4 flex items-center justify-between sticky top-0"
              style={{ background: THEME.gradient, color: "white" }}
            >
              <div className="flex items-center gap-2">
                <Plane className="w-5 h-5" />
                <span className="font-black font-mono text-lg">
                  {selectedFlight.flightNo}
                </span>
              </div>
              <button
                onClick={() => setSelectedFlight(null)}
                className="p-1.5 rounded-lg hover:bg-white/20 transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-4 space-y-3">
              <div className="flex items-center justify-between text-center">
                <div className="flex-1">
                  <div
                    className="text-3xl font-black font-mono"
                    style={{ color: THEME.text }}
                  >
                    {selectedFlight.dep || "—"}
                  </div>
                  <div
                    className="text-[10px] uppercase font-bold mt-0.5"
                    style={{ color: THEME.textMuted }}
                  >
                    Departure
                  </div>
                  <div
                    className="text-lg font-bold font-mono mt-1"
                    style={{ color: THEME.accent }}
                  >
                    {fmtHM(selectedFlight.std)}
                  </div>
                  <div
                    className="text-[9px]"
                    style={{ color: THEME.textMuted }}
                  >
                    {fmtDate(selectedFlight.std)}
                  </div>
                </div>

                <div className="flex flex-col items-center px-3">
                  <Plane
                    className="w-5 h-5"
                    style={{ color: THEME.accent, transform: "rotate(90deg)" }}
                  />
                  <div
                    className="text-[10px] font-mono mt-1"
                    style={{ color: THEME.textMuted }}
                  >
                    {calcDuration(selectedFlight.std, selectedFlight.sta)}
                  </div>
                </div>

                <div className="flex-1">
                  <div
                    className="text-3xl font-black font-mono"
                    style={{
                      color:
                        selectedFlight.arr === "HLWF" ? "#fca5a5" : THEME.text,
                    }}
                  >
                    {selectedFlight.arr || "—"}
                  </div>
                  <div
                    className="text-[10px] uppercase font-bold mt-0.5"
                    style={{ color: THEME.textMuted }}
                  >
                    Arrival
                  </div>
                  <div
                    className="text-lg font-bold font-mono mt-1"
                    style={{ color: THEME.accent }}
                  >
                    {fmtHM(selectedFlight.sta)}
                  </div>
                  <div
                    className="text-[9px]"
                    style={{ color: THEME.textMuted }}
                  >
                    {fmtDate(selectedFlight.sta)}
                  </div>
                </div>
              </div>

              <div
                className="border-t border-dashed"
                style={{ borderColor: THEME.borderLight }}
              />

              <div className="grid grid-cols-2 gap-2 text-xs">
                <div
                  className="p-2 rounded-lg"
                  style={{ backgroundColor: THEME.bg }}
                >
                  <div
                    className="text-[9px] uppercase"
                    style={{ color: THEME.textMuted }}
                  >
                    Aircraft
                  </div>
                  <div
                    className="font-bold font-mono"
                    style={{ color: THEME.text }}
                  >
                    ✈️ {selectedFlight.acft || "—"}
                  </div>
                </div>
                <div
                  className="p-2 rounded-lg"
                  style={{ backgroundColor: THEME.bg }}
                >
                  <div
                    className="text-[9px] uppercase"
                    style={{ color: THEME.textMuted }}
                  >
                    My Position
                  </div>
                  <div
                    className="font-bold font-mono"
                    style={{ color: THEME.accent }}
                  >
                    🎯 {getMyPosition(selectedFlight)}
                  </div>
                </div>
              </div>

              <div>
                <div
                  className="text-[10px] uppercase font-bold mb-1"
                  style={{ color: THEME.textMuted }}
                >
                  Crew ({(selectedFlight.crewSlots || []).length})
                </div>
                <div className="flex flex-wrap gap-1">
                  {(selectedFlight.crewSlots || []).map((slot, i) => {
                    const m = crew.find((c) => c.id === slot.crewId);
                    if (!m) return null;
                    const isMe = m.id === myCrewData.id;
                    return (
                      <span
                        key={i}
                        className="px-2 py-1 rounded-md text-[10px] font-mono font-bold border"
                        style={{
                          backgroundColor: isMe
                            ? `${THEME.accent}30`
                            : "rgba(255,255,255,0.08)",
                          color: isMe ? THEME.accent : THEME.text,
                          borderColor: isMe ? THEME.accent : THEME.borderLight,
                        }}
                        title={`${m.fullName} (${slot.position})`}
                      >
                        {m.empNo || m.fullName?.slice(0, 3)}
                        <span className="ms-1 opacity-70">
                          {POS_SHORT_MAP[slot.position] || slot.position}
                        </span>
                        {isMe && <span className="ms-1">⭐</span>}
                      </span>
                    );
                  })}
                </div>
              </div>

              <div
                className="flex items-center justify-between p-2 rounded-lg"
                style={{ backgroundColor: THEME.bg }}
              >
                <span
                  className="text-[10px] uppercase"
                  style={{ color: THEME.textMuted }}
                >
                  Status
                </span>
                <span
                  className="px-2 py-0.5 rounded-full text-[10px] font-bold border"
                  style={{
                    backgroundColor: `${
                      getStatusColorHex(selectedFlight.status) || THEME.accent
                    }20`,
                    color:
                      getStatusColorHex(selectedFlight.status) || THEME.accent,
                    borderColor:
                      getStatusColorHex(selectedFlight.status) || THEME.accent,
                  }}
                >
                  {selectedFlight.status || "SCHEDULED"}
                </span>
              </div>

              {selectedFlight.notes && (
                <div
                  className="p-2 rounded-lg text-[10px]"
                  style={{ backgroundColor: THEME.bg, color: THEME.textMuted }}
                >
                  📝 {selectedFlight.notes}
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* ═══ File Preview Modal ═══ */}
      {previewDoc && (
        <div
          className="fixed inset-0 z-[70] flex items-center justify-center p-4"
          style={{
            backgroundColor: "rgba(0,0,0,0.85)",
            backdropFilter: "blur(4px)",
          }}
          onClick={() => setPreviewDoc(null)}
        >
          <div
            className="rounded-2xl shadow-2xl w-full max-w-4xl h-[85vh] flex flex-col overflow-hidden"
            style={{
              backgroundColor: THEME.card,
              border: `2px solid ${THEME.border}`,
            }}
            onClick={(e) => e.stopPropagation()}
          >
            <div
              className="p-3 flex items-center justify-between"
              style={{ background: THEME.gradient, color: "white" }}
            >
              <div className="flex items-center gap-2 min-w-0">
                <FileText className="w-5 h-5 flex-shrink-0" />
                <span className="font-bold text-sm truncate">
                  {previewDoc.name.replace(/\.[^/.]+$/, "")}
                </span>
              </div>
              <button
                onClick={() => setPreviewDoc(null)}
                className="p-1.5 rounded-lg hover:bg-white/20 transition flex-shrink-0"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="flex-1 bg-gray-100 dark:bg-gray-900 relative">
              <iframe
                src={previewDoc.url}
                title={previewDoc.name}
                className="w-full h-full border-0"
              />
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

/* ═══ PortalCard ═══ */
function PortalCard({
  icon: Icon,
  label,
  onClick,
  badge,
  badgeColor = "emerald",
  THEME,
}) {
  const badgeCls =
    badgeColor === "emerald"
      ? "bg-emerald-500"
      : badgeColor === "rose"
      ? "bg-rose-500"
      : "bg-sky-500";

  return (
    <button
      onClick={onClick}
      className="relative aspect-square rounded-xl flex flex-col items-center justify-center p-4 active:scale-[0.98] transition shadow-lg border"
      style={{ backgroundColor: THEME.card, borderColor: THEME.borderLight }}
      onMouseEnter={(e) => {
        e.currentTarget.style.backgroundColor = THEME.cardHover;
      }}
      onMouseLeave={(e) => {
        e.currentTarget.style.backgroundColor = THEME.card;
      }}
    >
      <Icon
        className="w-12 h-12 sm:w-14 sm:h-14 mb-2 sm:mb-3 drop-shadow-md"
        style={{ color: THEME.text }}
        strokeWidth={1.5}
      />
      <span
        className="text-[11px] sm:text-xs font-bold text-center uppercase tracking-wider"
        style={{ color: THEME.text }}
      >
        {label}
      </span>
      {badge != null && badge > 0 && (
        <span
          className={`absolute top-2 end-2 ${badgeCls} text-white text-[10px] font-bold rounded-full min-w-[20px] h-5 px-1 flex items-center justify-center shadow-lg`}
        >
          {badge}
        </span>
      )}
    </button>
  );
}

export default CrewPortal;
