/* ═══════════════════════════════════════════════════════════
 * FLEET MODULE — Theme-aware (CSS Variables) + Modern Design
 * v4.0 — يتبع الثيم العام + يحفظ المستندات
 * ═══════════════════════════════════════════════════════════ */
import React, { useState } from "react";
import {
  Plus,
  Edit,
  Trash2,
  Search,
  Plane,
  Save,
  Paperclip,
  Eye,
  FileDown,
  Check,
} from "lucide-react";
import { useT, useAuth } from "../contexts";
import { Field } from "../components/ui/Field";
import { Input } from "../components/ui/Input";
import { Select } from "../components/ui/Select";
import { Modal } from "../components/ui/Modal";
import { AircraftStatusBadge } from "../components/ui/AircraftStatusBadge";
import { AttachmentsEditor } from "../components/AttachmentsEditor";
import { fleetAPI } from "../api";
import { logSafe } from "../utils/audit";
import {
  fmtDate,
  docStatus,
  daysUntil,
  formatFileSize,
  getStatusColor,
} from "../utils/helpers";
import { AIRCRAFT_STATUSES } from "../config/constants";
import { can as checkPerm } from "../config/permissions";
import { useLocalStorage } from "../hooks/useLocalStorage";

function getDocs(a) {
  let att = a.attachments || [];
  if (typeof att === "string") {
    try {
      att = JSON.parse(att);
    } catch {
      att = [];
    }
  }
  return Array.isArray(att) ? att : [];
}

/* ⭐ Theme-aware styles helpers */
const cardStyle = {
  backgroundColor: "var(--bg-card)",
  border: "1px solid var(--border-default)",
  boxShadow: "var(--shadow-sm)",
};

const innerBoxStyle = {
  backgroundColor: "var(--bg-app)",
  border: "1px solid var(--border-default)",
};

export function Fleet({ fleet, setFleet, lang = "en", setSyncStatus }) {
  const t = useT();
  const { user } = useAuth();

  const canCreate = checkPerm(user, "fleet.create");
  const canEdit = checkPerm(user, "fleet.edit");
  const canDelete = checkPerm(user, "fleet.delete");
  const canDocsView = checkPerm(user, "fleet.docs");
  const canDocsEdit = checkPerm(user, "fleet.docs_edit");
  const canDocsDownload = checkPerm(user, "fleet.docs_download");

  const [editing, setEditing] = useState(null);
  const [draft, setDraft] = useState({});
  const [docsAcft, setDocsAcft] = useState(null);
  const [docsDraft, setDocsDraft] = useState([]);
  const [docsSaving, setDocsSaving] = useState(false);
  const [viewMode, setViewMode] = useLocalStorage("aeroops.fleetView", "cards");
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("");

  const filteredFleet = fleet.filter((a) => {
    const matchesSearch =
      !search || (a.reg + a.type).toLowerCase().includes(search.toLowerCase());
    const matchesStatus = !statusFilter || a.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const openNew = () => {
    if (!canCreate) return;
    setDraft({
      reg: "",
      type: "",
      status: "AIRWORTHY",
      tah: 0,
      tac: 0,
      lastCheck: "",
      nextCheck: "",
      attachments: [],
    });
    setEditing("new");
  };

  const openEdit = (a) => {
    if (!canEdit) {
      alert("⚠️ ليس لديك صلاحية تعديل");
      return;
    }
    setDraft({
      ...a,
      lastCheck: a.lastCheck ? String(a.lastCheck).slice(0, 10) : "",
      nextCheck: a.nextCheck ? String(a.nextCheck).slice(0, 10) : "",
    });
    setEditing(a.id);
  };

  const save = async () => {
    if (editing === "new" && !canCreate) {
      alert("⚠️ ليس لديك صلاحية إضافة");
      return;
    }
    if (editing !== "new" && !canEdit) {
      alert("⚠️ ليس لديك صلاحية تعديل");
      return;
    }
    if (!draft.reg) return;
    setSyncStatus?.("syncing");
    try {
      if (editing === "new") {
        const created = await fleetAPI.create({ ...draft, attachments: [] });
        setFleet([...fleet, { ...draft, id: created.id, attachments: [] }]);
        logSafe(user, "CREATE", "Fleet", created.id, draft.reg, {
          reg: draft.reg,
          type: draft.type,
        });
      } else {
        const before = fleet.find((a) => a.id === editing);
        const updated = { ...draft, attachments: before?.attachments || [] };
        await fleetAPI.update(editing, updated);
        setFleet(
          fleet.map((a) => (a.id === editing ? { ...updated, id: editing } : a))
        );
        logSafe(user, "UPDATE", "Fleet", editing, draft.reg, {
          before: { status: before?.status },
          after: { status: draft.status },
        });
      }
      setEditing(null);
      setSyncStatus?.("synced");
    } catch (e) {
      alert("Save failed: " + e.message);
      setSyncStatus?.("error");
    }
  };

  const remove = async (id) => {
    if (!canDelete) {
      alert("⚠️ ليس لديك صلاحية حذف");
      return;
    }
    if (!confirm(t.confirmDelete)) return;
    const aircraft = fleet.find((a) => a.id === id);
    try {
      await fleetAPI.remove(id);
      setFleet(fleet.filter((a) => a.id !== id));
      logSafe(user, "DELETE", "Fleet", id, aircraft?.reg || "", {});
    } catch (e) {
      alert("Delete failed: " + e.message);
    }
  };

  const openDocs = (a) => {
    if (!canDocsView) {
      alert("⚠️ ليس لديك صلاحية عرض المستندات");
      return;
    }
    setDocsAcft(a);
    setDocsDraft(getDocs(a));
  };

  const saveDocs = async () => {
    if (!canDocsEdit) {
      alert("⚠️ ليس لديك صلاحية تعديل المستندات");
      return;
    }
    if (!docsAcft) return;
    setDocsSaving(true);
    try {
      const updated = { ...docsAcft, attachments: docsDraft };
      await fleetAPI.update(docsAcft.id, updated);
      setFleet(fleet.map((a) => (a.id === docsAcft.id ? { ...updated } : a)));
      logSafe(user, "UPDATE", "Fleet (Documents)", docsAcft.id, docsAcft.reg, {
        count: docsDraft.length,
      });
      setDocsAcft(null);
      setDocsDraft([]);
      alert("✅ " + (t.saved || "تم الحفظ"));
    } catch (e) {
      alert("Save failed: " + e.message);
    } finally {
      setDocsSaving(false);
    }
  };

  const hasAnyAction = canEdit || canDocsView || canDelete || canCreate;

  return (
    <div className="space-y-4 fade-in">
      {/* ═══ Toolbar ═══ */}
      <div className="rounded-xl p-3 space-y-3" style={cardStyle}>
        <div className="flex flex-wrap gap-2 items-center justify-between">
          <div className="flex items-center gap-3">
            <div
              className="w-10 h-10 rounded-lg flex items-center justify-center shadow-md"
              style={{ background: "var(--brand-gradient)" }}
            >
              <Plane className="w-6 h-6 text-white" />
            </div>
            <div>
              <h2
                className="text-lg font-bold"
                style={{ color: "var(--text-primary)" }}
              >
                {t.fleet}
              </h2>
              <p className="text-xs" style={{ color: "var(--text-muted)" }}>
                {fleet.length} {t.aircraft || "aircraft"}
              </p>
            </div>
          </div>
          {canCreate && (
            <button
              onClick={openNew}
              className="flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-bold text-white transition hover:-translate-y-0.5"
              style={{
                background: "var(--brand-gradient)",
                boxShadow: "var(--shadow-md)",
              }}
            >
              <Plus className="w-4 h-4" /> {t.addAircraft}
            </button>
          )}
        </div>

        <div className="flex flex-wrap gap-2 items-center">
          <div className="relative flex-1 min-w-[200px]">
            <Search
              className="w-4 h-4 absolute top-1/2 -translate-y-1/2 start-3"
              style={{ color: "var(--text-muted)" }}
            />
            <Input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder={t.search}
              className="ps-9"
            />
          </div>
          <Select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="w-auto"
          >
            <option value="">{t.allStatuses}</option>
            {AIRCRAFT_STATUSES.map((s) => (
              <option key={s.key} value={s.key}>
                {lang === "ar" ? s.ar : s.en}
              </option>
            ))}
          </Select>
          <div
            className="flex rounded-lg overflow-hidden"
            style={{ border: "1px solid var(--border-default)" }}
          >
            {[
              { id: "cards", l: "⊞" },
              { id: "table", l: "☰" },
              { id: "list", l: "≡" },
            ].map((v) => (
              <button
                key={v.id}
                onClick={() => setViewMode(v.id)}
                className="px-3 py-1.5 text-sm font-bold transition"
                style={
                  viewMode === v.id
                    ? {
                        background: "var(--brand-gradient)",
                        color: "white",
                      }
                    : {
                        backgroundColor: "var(--bg-card)",
                        color: "var(--text-muted)",
                      }
                }
              >
                {v.l}
              </button>
            ))}
          </div>
        </div>
      </div>

      {!hasAnyAction && (
        <div className="p-3 rounded-lg text-xs flex items-center gap-2 bg-amber-500/15 border border-amber-500/40 text-amber-500">
          <Eye className="w-4 h-4" /> ⚠️ لديك صلاحية العرض فقط — لا يمكنك تعديل
          أو إضافة أو حذف
        </div>
      )}

      {/* ═══ CARDS VIEW ═══ */}
      {viewMode === "cards" && (
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredFleet.map((a) => {
            const docs = getDocs(a);
            return (
              <div
                key={a.id}
                className="rounded-xl p-4 space-y-3 transition theme-transition"
                style={cardStyle}
                onMouseEnter={(e) => {
                  e.currentTarget.style.boxShadow = "var(--shadow-md)";
                  e.currentTarget.style.transform = "translateY(-2px)";
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.boxShadow = "var(--shadow-sm)";
                  e.currentTarget.style.transform = "translateY(0)";
                }}
              >
                <div className="flex justify-between items-start">
                  <div>
                    <div
                      className="font-bold text-lg font-mono"
                      style={{ color: "var(--text-primary)" }}
                    >
                      {a.reg}
                    </div>
                    <div
                      className="text-sm"
                      style={{ color: "var(--text-muted)" }}
                    >
                      {a.type}
                    </div>
                  </div>
                  <AircraftStatusBadge status={a.status} lang={lang} />
                </div>

                <div className="grid grid-cols-2 gap-2 text-sm">
                  {[
                    { l: t.tah || "TAH", v: a.tah?.toLocaleString() },
                    { l: t.tac || "TAC", v: a.tac?.toLocaleString() },
                    { l: t.lastCheck || "Last Check", v: fmtDate(a.lastCheck) },
                    { l: t.nextCheck || "Next Check", v: fmtDate(a.nextCheck) },
                  ].map((it, idx) => (
                    <div
                      key={idx}
                      className="p-2 rounded"
                      style={innerBoxStyle}
                    >
                      <div
                        className="text-xs"
                        style={{ color: "var(--text-muted)" }}
                      >
                        {it.l}
                      </div>
                      <div
                        className="font-semibold font-mono"
                        style={{ color: "var(--text-primary)" }}
                      >
                        {it.v || "—"}
                      </div>
                    </div>
                  ))}
                </div>

                {hasAnyAction && (
                  <div
                    className="flex gap-2 pt-2"
                    style={{ borderTop: "1px solid var(--border-default)" }}
                  >
                    {canEdit && (
                      <button
                        onClick={() => openEdit(a)}
                        className="flex-1 py-2 rounded-lg bg-amber-500/15 text-amber-500 hover:bg-amber-500/25 text-xs flex items-center justify-center gap-1 font-bold transition"
                      >
                        <Edit className="w-3.5 h-3.5" /> {t.edit || "تعديل"}
                      </button>
                    )}
                    {canDocsView && (
                      <button
                        onClick={() => openDocs(a)}
                        className="relative flex-1 py-2 rounded-lg bg-purple-500/15 text-purple-500 hover:bg-purple-500/25 text-xs flex items-center justify-center gap-1 font-bold transition"
                      >
                        <Paperclip className="w-3.5 h-3.5" />
                        {t.attachments || "مستندات"}
                        {docs.length > 0 && (
                          <span className="absolute -top-1.5 -end-1.5 bg-purple-600 text-white text-[9px] font-bold rounded-full w-4 h-4 flex items-center justify-center">
                            {docs.length}
                          </span>
                        )}
                      </button>
                    )}
                    {canDelete && (
                      <button
                        onClick={() => remove(a.id)}
                        className="py-2 px-3 rounded-lg bg-rose-500/15 text-rose-500 hover:bg-rose-500/25 text-xs transition"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      {/* ═══ TABLE VIEW ═══ */}
      {viewMode === "table" && (
        <div className="overflow-x-auto rounded-xl" style={cardStyle}>
          <table className="w-full text-sm">
            <thead
              style={{
                backgroundColor: "var(--bg-app)",
                borderBottom: "1px solid var(--border-default)",
              }}
            >
              <tr>
                {[
                  "#",
                  t.registration,
                  t.type,
                  t.status,
                  t.tah,
                  t.tac,
                  t.lastCheck,
                  t.nextCheck,
                  "Docs",
                  ...(hasAnyAction ? [t.actions] : []),
                ].map((h) => (
                  <th
                    key={h}
                    className="px-3 py-3 text-start font-semibold"
                    style={{ color: "var(--text-primary)" }}
                  >
                    {h}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filteredFleet.map((a, idx) => {
                const docs = getDocs(a);
                return (
                  <tr
                    key={a.id}
                    style={{
                      borderTop: "1px solid var(--border-default)",
                    }}
                    onMouseEnter={(e) => {
                      e.currentTarget.style.backgroundColor = "var(--bg-app)";
                    }}
                    onMouseLeave={(e) => {
                      e.currentTarget.style.backgroundColor = "transparent";
                    }}
                  >
                    <td
                      className="px-3 py-2 font-mono text-xs"
                      style={{ color: "var(--text-muted)" }}
                    >
                      {idx + 1}
                    </td>
                    <td
                      className="px-3 py-2 font-bold font-mono"
                      style={{ color: "var(--text-primary)" }}
                    >
                      {a.reg}
                    </td>
                    <td
                      className="px-3 py-2"
                      style={{ color: "var(--text-muted)" }}
                    >
                      {a.type}
                    </td>
                    <td className="px-3 py-2">
                      <AircraftStatusBadge status={a.status} lang={lang} />
                    </td>
                    <td
                      className="px-3 py-2 font-mono text-xs"
                      style={{ color: "var(--text-muted)" }}
                    >
                      {a.tah?.toLocaleString()}
                    </td>
                    <td
                      className="px-3 py-2 font-mono text-xs"
                      style={{ color: "var(--text-muted)" }}
                    >
                      {a.tac?.toLocaleString()}
                    </td>
                    <td
                      className="px-3 py-2 text-xs"
                      style={{ color: "var(--text-muted)" }}
                    >
                      {fmtDate(a.lastCheck)}
                    </td>
                    <td
                      className="px-3 py-2 text-xs"
                      style={{ color: "var(--text-muted)" }}
                    >
                      {fmtDate(a.nextCheck)}
                    </td>
                    <td className="px-3 py-2 text-center">
                      {canDocsView ? (
                        <button
                          onClick={() => openDocs(a)}
                          className="inline-flex items-center gap-1 px-2 py-1 rounded bg-purple-500/15 text-purple-500 hover:bg-purple-500/25 text-xs font-bold transition"
                        >
                          <Paperclip className="w-3 h-3" /> {docs.length}
                        </button>
                      ) : (
                        <span
                          className="text-xs"
                          style={{ color: "var(--text-muted)" }}
                        >
                          {docs.length}
                        </span>
                      )}
                    </td>
                    {hasAnyAction && (
                      <td className="px-3 py-2">
                        <div className="flex gap-1">
                          {canEdit && (
                            <button
                              onClick={() => openEdit(a)}
                              className="p-1.5 rounded bg-amber-500/10 text-amber-500 hover:bg-amber-500/25 transition"
                              title={t.edit}
                            >
                              <Edit className="w-4 h-4" />
                            </button>
                          )}
                          {canDelete && (
                            <button
                              onClick={() => remove(a.id)}
                              className="p-1.5 rounded bg-rose-500/10 text-rose-500 hover:bg-rose-500/25 transition"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          )}
                        </div>
                      </td>
                    )}
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}

      {/* ═══ LIST VIEW ═══ */}
      {viewMode === "list" && (
        <div
          className="rounded-xl divide-y"
          style={{ ...cardStyle, borderColor: "var(--border-default)" }}
        >
          {filteredFleet.map((a) => {
            const docs = getDocs(a);
            return (
              <div
                key={a.id}
                className="p-4 flex items-center gap-4 transition"
                onMouseEnter={(e) => {
                  e.currentTarget.style.backgroundColor = "var(--bg-app)";
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.backgroundColor = "transparent";
                }}
              >
                <div
                  className="w-12 h-12 rounded-lg flex items-center justify-center"
                  style={{ background: "var(--brand-gradient)" }}
                >
                  <Plane className="w-6 h-6 text-white" />
                </div>
                <div className="flex-1 min-w-0">
                  <div
                    className="font-bold font-mono"
                    style={{ color: "var(--text-primary)" }}
                  >
                    {a.reg}{" "}
                    <span
                      className="text-sm font-normal"
                      style={{ color: "var(--text-muted)" }}
                    >
                      ({a.type})
                    </span>
                  </div>
                  <div
                    className="text-xs font-mono"
                    style={{ color: "var(--text-muted)" }}
                  >
                    TAH: {a.tah?.toLocaleString()} · TAC:{" "}
                    {a.tac?.toLocaleString()}
                  </div>
                </div>
                <AircraftStatusBadge status={a.status} lang={lang} />
                {canDocsView && (
                  <button
                    onClick={() => openDocs(a)}
                    className="px-3 py-1.5 rounded-lg bg-purple-500/15 text-purple-500 hover:bg-purple-500/25 text-xs font-bold flex items-center gap-1 transition"
                  >
                    <Paperclip className="w-3 h-3" /> {docs.length}
                  </button>
                )}
                {hasAnyAction && (
                  <div className="flex gap-1">
                    {canEdit && (
                      <button
                        onClick={() => openEdit(a)}
                        className="p-1.5 rounded bg-amber-500/10 text-amber-500 hover:bg-amber-500/25 transition"
                      >
                        <Edit className="w-4 h-4" />
                      </button>
                    )}
                    {canDelete && (
                      <button
                        onClick={() => remove(a.id)}
                        className="p-1.5 rounded bg-rose-500/10 text-rose-500 hover:bg-rose-500/25 transition"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      {/* ═══ ADD / EDIT MODAL ═══ */}
      <Modal
        open={!!editing}
        title={editing === "new" ? t.addAircraft : t.editAircraft}
        onClose={() => setEditing(null)}
        wide
        footer={
          <>
            <button
              onClick={() => setEditing(null)}
              className="px-4 py-2 rounded-lg text-sm font-bold"
              style={{
                border: "1px solid var(--border-default)",
                color: "var(--text-muted)",
              }}
            >
              {t.cancel}
            </button>
            <button
              onClick={save}
              className="px-4 py-2 rounded-lg text-sm font-bold text-white flex items-center gap-2"
              style={{
                background: "var(--brand-gradient)",
                boxShadow: "var(--shadow-md)",
              }}
            >
              <Save className="w-4 h-4" /> {t.save}
            </button>
          </>
        }
      >
        <div className="space-y-5">
          <div className="grid md:grid-cols-2 gap-3">
            <Field label={t.registration}>
              <Input
                value={draft.reg || ""}
                onChange={(e) => setDraft({ ...draft, reg: e.target.value })}
              />
            </Field>
            <Field label={t.type}>
              <Input
                value={draft.type || ""}
                onChange={(e) => setDraft({ ...draft, type: e.target.value })}
              />
            </Field>
            <Field label={t.status} span>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                {AIRCRAFT_STATUSES.map((s) => {
                  const active = draft.status === s.key;
                  return (
                    <button
                      key={s.key}
                      type="button"
                      onClick={() => setDraft({ ...draft, status: s.key })}
                      className="flex items-center gap-2 px-3 py-2 rounded-lg border text-xs text-start transition"
                      style={{
                        backgroundColor: active
                          ? "var(--bg-app)"
                          : "var(--bg-card)",
                        borderColor: active
                          ? "var(--brand-primary)"
                          : "var(--border-default)",
                        boxShadow: active
                          ? `0 0 0 2px var(--brand-accent)`
                          : "none",
                      }}
                    >
                      <span
                        className="w-2.5 h-2.5 rounded-full flex-shrink-0"
                        style={{ background: s.dot }}
                      />
                      <span
                        className="flex-1 truncate"
                        style={{ color: "var(--text-primary)" }}
                      >
                        {lang === "ar" ? s.ar : s.en}
                      </span>
                      {active && (
                        <Check
                          className="w-3.5 h-3.5"
                          style={{ color: "var(--brand-primary)" }}
                        />
                      )}
                    </button>
                  );
                })}
              </div>
            </Field>
            <Field label={t.tah}>
              <Input
                type="number"
                value={draft.tah || 0}
                onChange={(e) => setDraft({ ...draft, tah: +e.target.value })}
              />
            </Field>
            <Field label={t.tac}>
              <Input
                type="number"
                value={draft.tac || 0}
                onChange={(e) => setDraft({ ...draft, tac: +e.target.value })}
              />
            </Field>
            <Field label={t.lastCheck}>
              <Input
                type="date"
                value={draft.lastCheck || ""}
                onChange={(e) =>
                  setDraft({ ...draft, lastCheck: e.target.value })
                }
              />
            </Field>
            <Field label={t.nextCheck}>
              <Input
                type="date"
                value={draft.nextCheck || ""}
                onChange={(e) =>
                  setDraft({ ...draft, nextCheck: e.target.value })
                }
              />
            </Field>
          </div>
        </div>
      </Modal>

      {/* ═══ DOCS MODAL ═══ */}
      {docsAcft && (
        <Modal
          open={!!docsAcft}
          title={`📎 ${t.aircraftDocs || "مستندات الطائرة"} — ${docsAcft.reg}`}
          onClose={() => {
            setDocsAcft(null);
            setDocsDraft([]);
          }}
          wide
          footer={
            <>
              <button
                onClick={() => {
                  setDocsAcft(null);
                  setDocsDraft([]);
                }}
                className="px-4 py-2 rounded-lg text-sm font-bold"
                style={{
                  border: "1px solid var(--border-default)",
                  color: "var(--text-muted)",
                }}
              >
                {t.cancel || "إغلاق"}
              </button>
              {canDocsEdit && (
                <button
                  onClick={saveDocs}
                  disabled={docsSaving}
                  className="px-4 py-2 rounded-lg text-sm font-bold text-white flex items-center gap-2 disabled:opacity-50"
                  style={{
                    background: "var(--brand-gradient)",
                    boxShadow: "var(--shadow-md)",
                  }}
                >
                  <Save className="w-4 h-4" />
                  {docsSaving ? "…" : t.save || "حفظ"}
                </button>
              )}
            </>
          }
        >
          <div className="space-y-4">
            <div
              className="p-3 rounded-lg flex items-center gap-3"
              style={{
                backgroundColor: "rgba(168, 85, 247, 0.1)",
                border: "1px solid rgba(168, 85, 247, 0.3)",
              }}
            >
              <div
                className="w-12 h-12 rounded-lg flex items-center justify-center"
                style={{ background: "var(--brand-gradient)" }}
              >
                <Plane className="w-6 h-6 text-white" />
              </div>
              <div className="flex-1">
                <div
                  className="font-bold font-mono"
                  style={{ color: "var(--text-primary)" }}
                >
                  {docsAcft.reg}
                </div>
                <div className="text-xs" style={{ color: "var(--text-muted)" }}>
                  {docsAcft.type}
                </div>
              </div>
              <span className="px-3 py-1 rounded-full bg-purple-500/20 text-purple-500 text-xs font-bold">
                {docsDraft.length} {t.attachments || "مستندات"}
              </span>
            </div>

            {!canDocsEdit && (
              <div className="p-3 rounded-lg text-xs flex items-center gap-2 bg-amber-500/15 border border-amber-500/40 text-amber-500">
                <Eye className="w-4 h-4" />
                {t.docs_readonly || "وضع العرض فقط — لا يمكنك تعديل المستندات"}
              </div>
            )}

            {canDocsEdit ? (
              <AttachmentsEditor
                value={docsDraft}
                onChange={(v) => setDocsDraft(v)}
              />
            ) : (
              <ReadOnlyDocsList
                docs={docsDraft}
                canDownload={canDocsDownload}
              />
            )}

            <div
              className="text-xs p-3 rounded-lg"
              style={{
                ...innerBoxStyle,
                color: "var(--text-muted)",
              }}
            >
              💡{" "}
              {canDocsEdit
                ? t.docsHint ||
                  "أضف المستندات هنا — تُحفظ منفصلة عن معلومات الطائرة."
                : t.docsReadonlyHint || "للتعديل، تواصل مع المسؤول."}
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════
 * READ-ONLY DOCS LIST (Theme-Aware)
 * ═══════════════════════════════════════════════════════════ */
function ReadOnlyDocsList({ docs = [], canDownload = false }) {
  const t = useT();
  if (docs.length === 0) {
    return (
      <div
        className="p-8 text-center text-sm rounded-lg border-2 border-dashed"
        style={{
          color: "var(--text-muted)",
          borderColor: "var(--border-default)",
        }}
      >
        <Paperclip className="w-10 h-10 mx-auto mb-2 opacity-30" />
        <div>{t.noData || "لا توجد مستندات"}</div>
      </div>
    );
  }
  return (
    <div className="space-y-2">
      {docs.map((doc, idx) => {
        const name = doc.name || doc.fileName || `Document ${idx + 1}`;
        const url = doc.url || doc.fileUrl || doc.data || "";
        const size = doc.size ? formatFileSize(doc.size) : "";
        const type = doc.type || doc.mimeType || doc.mime || "";
        const st = docStatus(doc.expiry);
        const days = daysUntil(doc.expiry);
        const colorCls = getStatusColor(st);
        const cardBg =
          st === "expired"
            ? "rgba(244, 63, 94, 0.1)"
            : st === "critical"
            ? "rgba(249, 115, 22, 0.1)"
            : st === "expiring"
            ? "rgba(245, 158, 11, 0.1)"
            : "var(--bg-app)";
        const cardBorder =
          st === "expired"
            ? "rgba(244, 63, 94, 0.4)"
            : st === "critical"
            ? "rgba(249, 115, 22, 0.4)"
            : st === "expiring"
            ? "rgba(245, 158, 11, 0.4)"
            : "var(--border-default)";
        return (
          <div
            key={idx}
            className="flex flex-wrap items-center gap-3 p-3 rounded-lg border"
            style={{ backgroundColor: cardBg, borderColor: cardBorder }}
          >
            <div
              className="w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0"
              style={{ backgroundColor: "rgba(168, 85, 247, 0.15)" }}
            >
              <Paperclip className="w-5 h-5 text-purple-500" />
            </div>
            <div className="flex-1 min-w-0">
              <div
                className="font-bold text-sm truncate"
                style={{ color: "var(--text-primary)" }}
              >
                {name}
              </div>
              <div
                className="text-[10px]"
                style={{ color: "var(--text-muted)" }}
              >
                {type && <span className="font-mono">{type}</span>}
                {size && <span> · {size}</span>}
              </div>
              {doc.expiry && days !== null && (
                <div className="mt-1 flex items-center gap-2 flex-wrap">
                  <span
                    className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-mono"
                    style={{
                      backgroundColor: "var(--bg-card)",
                      color: "var(--text-muted)",
                    }}
                  >
                    📅 {String(doc.expiry).slice(0, 10)}
                  </span>
                  <span
                    className={`inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold border ${colorCls}`}
                  >
                    {days < 0
                      ? `منتهي منذ ${Math.abs(days)} يوم`
                      : days === 0
                      ? "ينتهي اليوم"
                      : `${days} يوم متبقٍ`}
                  </span>
                </div>
              )}
            </div>
            {canDownload && url ? (
              <a
                href={url}
                download={name}
                target="_blank"
                rel="noopener noreferrer"
                className="px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1 transition"
                style={{
                  backgroundColor: "rgba(99, 102, 241, 0.15)",
                  color: "var(--brand-primary)",
                }}
              >
                <FileDown className="w-3.5 h-3.5" /> {t.download || "تحميل"}
              </a>
            ) : (
              <span
                className="text-[10px] italic"
                style={{ color: "var(--text-muted)" }}
              >
                {t.noDownloadPerm || "بدون تحميل"}
              </span>
            )}
          </div>
        );
      })}
    </div>
  );
}

export default Fleet;
