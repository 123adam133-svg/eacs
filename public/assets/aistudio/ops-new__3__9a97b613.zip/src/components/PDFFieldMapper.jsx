/* ═══════════════════════════════════════════════════════════
 * PDF FIELD MAPPER — v2.0
 * يستخدم getPDFBase64 من Apps Script (تجاوز CORS)
 * ═══════════════════════════════════════════════════════════ */
import React, { useState, useRef, useEffect } from "react";
import {
  X,
  Plus,
  Trash2,
  Save,
  MousePointer2,
  AlertCircle,
} from "lucide-react";
import { Field } from "./ui/Field";
import { Input } from "./ui/Input";
import { fetchPDFBytes } from "../utils/pdfFiller";

export function PDFFieldMapper({
  pdfUrl,
  initialFields = [],
  onSave,
  onClose,
}) {
  const [fields, setFields] = useState(
    initialFields.length > 0 ? initialFields : []
  );
  const [pendingField, setPendingField] = useState(null);
  const [pdfRendered, setPdfRendered] = useState(false);
  const [currentPage, setCurrentPage] = useState(0);
  const [totalPages, setTotalPages] = useState(1);
  const [pageSize, setPageSize] = useState({ width: 0, height: 0 });
  const [pdfDoc, setPdfDoc] = useState(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);

  const canvasRef = useRef(null);
  const containerRef = useRef(null);

  /* ═══ تحميل pdfjs + PDF (عبر fetchPDFBytes) ═══ */
  useEffect(() => {
    let cancelled = false;

    const loadPdfJs = () => {
      return new Promise((resolve, reject) => {
        if (window.pdfjsLib) {
          resolve(window.pdfjsLib);
          return;
        }
        const script = document.createElement("script");
        script.src =
          "https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.min.js";
        script.onload = () => resolve(window.pdfjsLib);
        script.onerror = () => reject(new Error("فشل تحميل pdfjs من CDN"));
        document.head.appendChild(script);
      });
    };

    (async () => {
      try {
        // 1. تحميل pdfjs
        const pdfjsLib = await loadPdfJs();
        pdfjsLib.GlobalWorkerOptions.workerSrc =
          "https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js";

        console.log("📄 PDFFieldMapper: Loading PDF...");
        console.log("  URL:", pdfUrl);

        // 2. تحميل PDF bytes عبر fetchPDFBytes (يتجاوز CORS)
        const arrayBuffer = await fetchPDFBytes(pdfUrl);

        console.log("  Bytes:", arrayBuffer.byteLength);
        console.log(
          "  First 8:",
          new TextDecoder().decode(arrayBuffer.slice(0, 8))
        );

        // 3. تمرير arrayBuffer لـ pdfjs
        const loadingTask = pdfjsLib.getDocument({
          data: arrayBuffer,
          cMapUrl:
            "https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/cmaps/",
          cMapPacked: true,
        });
        const pdf = await loadingTask.promise;

        if (cancelled) return;

        setPdfDoc(pdf);
        setTotalPages(pdf.numPages);
        await renderPage(pdf, 0);
        setPdfRendered(true);
        setLoading(false);
      } catch (err) {
        console.error("PDF load error:", err);
        if (!cancelled) {
          setError("فشل تحميل PDF: " + err.message);
          setLoading(false);
        }
      }
    })();

    return () => {
      cancelled = true;
    };
  }, [pdfUrl]);

  /* ═══ عرض صفحة معينة ═══ */
  const renderPage = async (pdf, pageNum) => {
    const page = await pdf.getPage(pageNum + 1);
    const viewport = page.getViewport({ scale: 1.5 });

    const canvas = canvasRef.current;
    if (!canvas) return;

    const context = canvas.getContext("2d");
    canvas.width = viewport.width;
    canvas.height = viewport.height;

    setPageSize({ width: viewport.width, height: viewport.height });

    await page.render({ canvasContext: context, viewport }).promise;
  };

  const changePage = async (delta) => {
    const newPage = currentPage + delta;
    if (newPage < 0 || newPage >= totalPages || !pdfDoc) return;
    setCurrentPage(newPage);
    await renderPage(pdfDoc, newPage);
  };

  /* ═══ إضافة حقل جديد ═══ */
  const startAddField = () => {
    setPendingField({
      key: "",
      label: "",
      fontSize: 12,
      bold: false,
    });
    setError("");
  };

  /* ═══ النقر على PDF لتحديد الموقع ═══ */
  const handleCanvasClick = (e) => {
    if (!pendingField) return;

    const rect = canvasRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    // تحويل من إحداثيات Canvas إلى PDF (A4: 595x842 pt)
    const pdfX = Math.round((x / pageSize.width) * 595);
    const pdfY = Math.round(((pageSize.height - y) / pageSize.height) * 842);

    if (!pendingField.key) {
      setError("⚠️ أدخل اسم الحقل أولاً");
      return;
    }

    if (!/^[a-zA-Z_][a-zA-Z0-9_]*$/.test(pendingField.key)) {
      setError(
        "⚠️ اسم الحقل يجب أن يبدأ بحرف ويحتوي فقط على أحرف/أرقام/underscore"
      );
      return;
    }

    if (fields.some((f) => f.key === pendingField.key)) {
      setError(`⚠️ الحقل "${pendingField.key}" موجود بالفعل`);
      return;
    }

    const newField = {
      ...pendingField,
      x: pdfX,
      y: pdfY,
      page: currentPage,
    };

    setFields([...fields, newField]);
    setPendingField(null);
    setError("");
  };

  const removeField = (key) => {
    setFields(fields.filter((f) => f.key !== key));
  };

  const handleSave = () => {
    if (fields.length === 0) {
      setError("⚠️ أضف حقلاً واحداً على الأقل");
      return;
    }
    onSave(fields);
  };

  return (
    <div
      className="fixed inset-0 z-[95] flex items-center justify-center p-4"
      style={{ backgroundColor: "rgba(0,0,0,0.85)" }}
      onClick={onClose}
    >
      <div
        className="bg-white dark:bg-slate-800 rounded-2xl w-full max-w-6xl max-h-[95vh] flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div
          className="flex justify-between items-center p-4 border-b"
          style={{ borderColor: "var(--border-default)" }}
        >
          <div>
            <h2
              className="text-lg font-bold flex items-center gap-2"
              style={{ color: "var(--text-primary)" }}
            >
              <MousePointer2
                className="w-5 h-5"
                style={{ color: "var(--brand-primary)" }}
              />
              Field Mapper — حدد أماكن الحقول على PDF
            </h2>
            <p className="text-xs" style={{ color: "var(--text-muted)" }}>
              أضف حقلاً، ثم انقر على PDF لتحديد موقعه
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-700"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="flex-1 overflow-hidden flex flex-col md:flex-row">
          {/* Sidebar */}
          <div
            className="w-full md:w-80 p-3 border-b md:border-b-0 md:border-e overflow-y-auto max-h-[40vh] md:max-h-full"
            style={{ borderColor: "var(--border-default)" }}
          >
            <div className="flex justify-between items-center mb-2">
              <h3
                className="text-sm font-bold"
                style={{ color: "var(--text-primary)" }}
              >
                📋 الحقول ({fields.length})
              </h3>
              <button
                onClick={startAddField}
                disabled={!!pendingField}
                className="px-2 py-1 rounded bg-sky-500/15 text-sky-500 text-xs font-bold flex items-center gap-1 disabled:opacity-50"
              >
                <Plus className="w-3 h-3" /> جديد
              </button>
            </div>

            {pendingField && (
              <div className="p-2 mb-2 rounded bg-amber-500/15 border border-amber-500/50">
                <div className="text-[10px] font-bold text-amber-600 mb-1">
                  🎯 حقل جديد — انقر على PDF لتحديد موقعه
                </div>
                <Input
                  value={pendingField.key}
                  onChange={(e) =>
                    setPendingField({ ...pendingField, key: e.target.value })
                  }
                  placeholder="مثل: flightNo"
                  className="mb-1 text-xs"
                />
                <div className="flex gap-1">
                  <Input
                    type="number"
                    value={pendingField.fontSize}
                    onChange={(e) =>
                      setPendingField({
                        ...pendingField,
                        fontSize: parseInt(e.target.value) || 12,
                      })
                    }
                    className="w-16 text-xs"
                    placeholder="حجم"
                  />
                  <button
                    onClick={() => setPendingField(null)}
                    className="px-2 py-1 rounded bg-rose-500/15 text-rose-500 text-xs"
                  >
                    إلغاء
                  </button>
                </div>
              </div>
            )}

            {error && (
              <div className="p-2 mb-2 rounded bg-rose-500/15 text-rose-500 text-xs flex items-start gap-1">
                <AlertCircle className="w-3 h-3 flex-shrink-0 mt-0.5" />
                <span>{error}</span>
              </div>
            )}

            {fields.length === 0 ? (
              <div
                className="text-center py-6 text-xs"
                style={{ color: "var(--text-muted)" }}
              >
                لا توجد حقول بعد
              </div>
            ) : (
              <div className="space-y-1">
                {fields.map((f) => (
                  <div
                    key={f.key}
                    className="p-2 rounded bg-slate-100 dark:bg-slate-700 text-xs flex items-center gap-1"
                  >
                    <div className="flex-1 min-w-0">
                      <div
                        className="font-bold truncate"
                        style={{ color: "var(--text-primary)" }}
                      >
                        {f.key}
                      </div>
                      <div
                        className="text-[10px] font-mono"
                        style={{ color: "var(--text-muted)" }}
                      >
                        x:{f.x} y:{f.y} · {f.fontSize}pt · p{f.page + 1}
                      </div>
                    </div>
                    <button
                      onClick={() => removeField(f.key)}
                      className="p-1 text-rose-500 hover:bg-rose-500/20 rounded"
                    >
                      <Trash2 className="w-3 h-3" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* PDF Canvas */}
          <div
            ref={containerRef}
            className="flex-1 overflow-auto p-4 flex flex-col items-center"
            style={{ backgroundColor: "var(--bg-app)" }}
          >
            {totalPages > 1 && (
              <div className="mb-2 flex items-center gap-2 text-xs">
                <button
                  onClick={() => changePage(-1)}
                  disabled={currentPage === 0}
                  className="px-2 py-1 rounded bg-slate-200 dark:bg-slate-700 disabled:opacity-50"
                >
                  ◀
                </button>
                <span style={{ color: "var(--text-primary)" }}>
                  صفحة {currentPage + 1} / {totalPages}
                </span>
                <button
                  onClick={() => changePage(1)}
                  disabled={currentPage === totalPages - 1}
                  className="px-2 py-1 rounded bg-slate-200 dark:bg-slate-700 disabled:opacity-50"
                >
                  ▶
                </button>
              </div>
            )}

            <div
              className="relative border-2 border-dashed inline-block"
              style={{
                borderColor: pendingField ? "#f59e0b" : "var(--border-default)",
                cursor: pendingField ? "crosshair" : "default",
              }}
              onClick={handleCanvasClick}
            >
              <canvas ref={canvasRef} className="block" />

              {pdfRendered && pageSize.width > 0 && (
                <>
                  {fields
                    .filter((f) => f.page === currentPage)
                    .map((f) => {
                      const canvasX = (f.x / 595) * pageSize.width;
                      const canvasY =
                        pageSize.height - (f.y / 842) * pageSize.height;

                      return (
                        <div
                          key={f.key}
                          className="absolute pointer-events-none"
                          style={{
                            left: canvasX,
                            top: canvasY - 12,
                            backgroundColor: "rgba(59, 130, 246, 0.3)",
                            border: "1px solid #3b82f6",
                            borderRadius: "2px",
                            padding: "1px 4px",
                            fontSize: "10px",
                            fontWeight: "bold",
                            color: "#1e40af",
                            whiteSpace: "nowrap",
                            transform: "translateY(-100%)",
                          }}
                        >
                          {f.key}
                        </div>
                      );
                    })}
                </>
              )}
            </div>

            {loading && !error && (
              <div
                className="text-center py-12 text-sm"
                style={{ color: "var(--text-muted)" }}
              >
                Loading PDF...
              </div>
            )}

            {error && !pdfRendered && (
              <div className="mt-4 p-3 rounded bg-rose-500/15 text-rose-500 text-sm max-w-md">
                {error}
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div
          className="p-4 border-t flex justify-between gap-2"
          style={{ borderColor: "var(--border-default)" }}
        >
          <div className="text-xs" style={{ color: "var(--text-muted)" }}>
            {pendingField && "🎯 انقر على PDF لتحديد موقع الحقل"}
          </div>
          <div className="flex gap-2">
            <button
              onClick={onClose}
              className="px-4 py-2 rounded-lg text-sm font-bold border"
              style={{
                borderColor: "var(--border-default)",
                color: "var(--text-muted)",
              }}
            >
              Cancel
            </button>
            <button
              onClick={handleSave}
              className="px-4 py-2 rounded-lg text-sm font-bold text-white flex items-center gap-2"
              style={{ background: "var(--brand-gradient)" }}
            >
              <Save className="w-4 h-4" /> حفظ ({fields.length} حقل)
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default PDFFieldMapper;
