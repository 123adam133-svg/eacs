import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";

async function initPWA() {
  let companyName = "AeroOps";
  let logoUrl = "https://cdn-icons-png.flaticon.com/512/3125/3125713.png";

  // 1. جلب الشعار والاسم من Google Sheets
  try {
    const res = await fetch(
      "https://script.google.com/macros/s/AKfycbx1Q_uFSgUs43Y3xqS7C8_yptcPPizMIBaUf0Kf07TKf4n_X75j84rHlAvwcXcTeMVtTg/exec?sheet=Settings"
    );
    const data = await res.json();
    if (data.ok && data.data && data.data[0]) {
      const settings = data.data[0];
      companyName = settings.companyName || "AeroOps";
      logoUrl = settings.logo || logoUrl;

      const match = logoUrl.match(/[?&]id=([^&]+)/);
      if (match) {
        logoUrl = `https://lh3.googleusercontent.com/d/${match[1]}=s512`;
      }

      let iconLink = document.querySelector("link[rel~='icon']");
      if (!iconLink) {
        iconLink = document.createElement("link");
        iconLink.rel = "icon";
        document.head.appendChild(iconLink);
      }
      iconLink.href = logoUrl;
    }
  } catch (err) {
    console.error("PWA Fetch Error:", err);
  }

  // 2. ⭐ Service Worker ذكي يعترض طلب manifest.json
  if ("serviceWorker" in navigator) {
    const swCode = `
      self.addEventListener('install', (e) => self.skipWaiting());
      self.addEventListener('activate', (e) => e.waitUntil(clients.claim()));
      
      self.addEventListener('fetch', (event) => {
        if (event.request.url.includes('manifest.json')) {
          const manifest = {
            short_name: "${companyName}",
            name: "${companyName} — Flight Operations",
            start_url: "/",
            display: "standalone",
            background_color: "#0f172a",
            theme_color: "#6366f1",
            icons: [{
              src: "${logoUrl}",
              sizes: "192x192 512x512",
              type: "image/png",
              purpose: "any maskable"
            }]
          };
          event.respondWith(
            new Response(JSON.stringify(manifest), {
              headers: { 'Content-Type': 'application/json' }
            })
          );
          return;
        }
        if (event.request.url.includes('script.google.com')) return;
      });
    `;
    const swBlob = new Blob([swCode], { type: "application/javascript" });
    const swUrl = URL.createObjectURL(swBlob);

    navigator.serviceWorker
      .register(swUrl)
      .then(() => console.log("✅ PWA Service Worker Registered"))
      .catch((err) => console.warn("⚠️ SW Failed:", err));
  }

  // 3. تشغيل التطبيق
  const rootElement = document.getElementById("root");
  const root = createRoot(rootElement);
  root.render(
    <StrictMode>
      <App />
    </StrictMode>
  );
}

initPWA();
