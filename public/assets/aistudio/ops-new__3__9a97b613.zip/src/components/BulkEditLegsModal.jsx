/* ═══════════════════════════════════════════════════════════
 * BULK EDIT LEGS MODAL — v1.0
 * تعديل جماعي للقطاعات المضافة (legs) فقط
 * ═══════════════════════════════════════════════════════════ */
import React, { useState, useMemo } from "react";
import { X, Save, Calendar, Clock, Plane } from "lucide-react";

export function BulkEditLegsModal({ flights, fleet = [], onClose, onSave }) {
  const lang = document.documentElement.lang || "en";
  const isRTL = lang === "ar";

  const [date, setDate] = useState("");
  const [std, setStd] = useState("");
  const [sta, setSta] = useState("");
  const [acft, setAcft] = useState("");
  const [saving, setSaving] = useState(false);

  const legsInfo = useMemo(() => {
    let totalLegs = 0;
    let flightsWithLegs = 0;
    flights.forEach((f) => {
      const legs = Array.isArray(f.legs) ? f.legs : [];
      if (legs.length > 0) {
        flightsWithLegs++;
        totalLegs += legs.length;
      }
    });
    return { totalLegs, flightsWithLegs };
  }, [flights]);

  if (!flights || flights.length === 0) return null;

  const hasAnyChange = date || std || sta || acft;

  const handleSave = async () => {
    if (!hasAnyChange) {
      alert(isRTL ? "⚠️ لم تقم بتعديل أي حقل" : "⚠️ No fields modified");
      return;
    }
    if (legsInfo.totalLegs === 0) {
      alert(
        isRTL
          ? "⚠️ الرحلات المحددة لا تحتوي على قطاعات إضافية"
          : "⚠️ Selected flights have no additional legs"
      );
      return;
    }

    const confirmMsg = isRTL
      ? `✏️ سيتم تعديل ${legsInfo.totalLegs} قطاع في ${legsInfo.flightsWithLegs} رحلة\n\n` +
        `${date ? `📅 التاريخ: ${date}\n` : ""}` +
        `${std ? `🕐 STD: ${std}\n` : ""}` +
        `${sta ? `🕐 STA: ${sta}\n` : ""}` +
        `${acft ? `✈️ الطائرة: ${acft}\n` : ""}` +
        `\n⚠️ القطاع الأساسي (Main) لن يتأثر\n\nهل تريد المتابعة؟`
      : `✏️ Update ${legsInfo.totalLegs} legs in ${legsInfo.flightsWithLegs} flight(s)?`;

    if (!window.confirm(confirmMsg)) return;

    setSaving(true);
    try {
      const changes = {};
      if (date) changes.date = date;
      if (std) changes.std = std;
      if (sta) changes.sta = sta;
      if (acft) changes.acft = acft;
      await onSave(changes);
      onClose();
    } catch (e) {
      console.error(e);
      alert((isRTL ? "فشل: " : "Failed: ") + e.message);
    } finally {
      setSaving(false);
    }
  };

  return (
    <div
      className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4"
      onClick={onClose}
    >
      <div
        className="bg-white dark:bg-slate-800 rounded-2xl max-w-lg w-full p-6"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex justify-between items-start mb-4">
          <div>
            <h2 className="text-xl font-bold text-slate-800 dark:text-slate-100">
              {isRTL ? "تعديل القطاعات" : "Edit Legs"}
            </h2>
            <p className="text-sm text-slate-500">
              {isRTL
                ? `${flights.length} رحلة — ${legsInfo.totalLegs} قطاع`
                : `${flights.length} flight(s) — ${legsInfo.totalLegs} leg(s)`}
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-300"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {legsInfo.totalLegs === 0 && (
          <div className="bg-amber-50 dark:bg-amber-950 border border-amber-300 dark:border-amber-700 rounded-lg p-3 mb-4 text-xs text-amber-700 dark:text-amber-300">
            ⚠️{" "}
            {isRTL
              ? "الرحلات المحددة لا تحتوي على قطاعات إضافية (legs)"
              : "Selected flights have no additional legs"}
          </div>
        )}

        <div className="space-y-4">
          <div>
            <label className="flex items-center gap-2 text-sm font-bold text-slate-700 dark:text-slate-200 mb-1">
              <Calendar className="w-4 h-4" />
              {isRTL ? "التاريخ" : "Date"}
            </label>
            <input
              type="date"
              value={date}
              onChange={(e) => setDate(e.target.value)}
              className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-sm text-slate-800 dark:text-slate-100 outline-none focus:ring-2 focus:ring-sky-400"
            />
            <p className="text-[10px] text-slate-500 mt-1">
              {isRTL
                ? "اتركه فارغاً للإبقاء على التاريخ الحالي"
                : "Leave empty to keep current date"}
            </p>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="flex items-center gap-2 text-sm font-bold text-slate-700 dark:text-slate-200 mb-1">
                <Clock className="w-4 h-4" />
                STD
              </label>
              <input
                type="time"
                value={std}
                onChange={(e) => setStd(e.target.value)}
                className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-sm text-slate-800 dark:text-slate-100 outline-none focus:ring-2 focus:ring-sky-400"
              />
            </div>
            <div>
              <label className="flex items-center gap-2 text-sm font-bold text-slate-700 dark:text-slate-200 mb-1">
                <Clock className="w-4 h-4" />
                STA
              </label>
              <input
                type="time"
                value={sta}
                onChange={(e) => setSta(e.target.value)}
                className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-sm text-slate-800 dark:text-slate-100 outline-none focus:ring-2 focus:ring-sky-400"
              />
            </div>
          </div>

          <div>
            <label className="flex items-center gap-2 text-sm font-bold text-slate-700 dark:text-slate-200 mb-1">
              <Plane className="w-4 h-4" />
              {isRTL ? "الطائرة" : "Aircraft"}
            </label>
            <select
              value={acft}
              onChange={(e) => setAcft(e.target.value)}
              className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-sm text-slate-800 dark:text-slate-100 outline-none focus:ring-2 focus:ring-sky-400"
            >
              <option value="">
                {isRTL ? "— بدون تغيير —" : "— No change —"}
              </option>
              {fleet.map((a) => (
                <option key={a.id} value={a.reg}>
                  {a.reg} ({a.type})
                </option>
              ))}
            </select>
          </div>
        </div>

        <div className="flex justify-end gap-2 pt-4 mt-4 border-t border-slate-200 dark:border-slate-700">
          <button
            onClick={onClose}
            disabled={saving}
            className="px-4 py-2 rounded-lg border border-slate-300 dark:border-slate-600 text-sm text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-700 transition disabled:opacity-50"
          >
            {isRTL ? "إلغاء" : "Cancel"}
          </button>
          <button
            onClick={handleSave}
            disabled={!hasAnyChange || saving || legsInfo.totalLegs === 0}
            className="px-6 py-2 rounded-lg bg-sky-600 hover:bg-sky-700 disabled:opacity-50 text-white text-sm flex items-center gap-2 font-bold transition"
          >
            <Save className="w-4 h-4" />
            {saving
              ? isRTL
                ? "جاري التطبيق..."
                : "Applying..."
              : isRTL
              ? "تطبيق جماعي"
              : "Apply to All"}
          </button>
        </div>
      </div>
    </div>
  );
}

export default BulkEditLegsModal;
