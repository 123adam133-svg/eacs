/* ═══════════════════════════════════════════════════════════
 * AeroOps API Client — Google Sheets + Drive
 * Version 5.1 — Added Settings fields (aircraft, COA, etc.)
 *              + route in Flights + toDirectDriveUrl
 * ═══════════════════════════════════════════════════════════ */

const API_URL =
  "https://script.google.com/macros/s/AKfycbyWvE4E4dCzWIpm4t6Vul_27CqqYQJ1MsKIUVDZVxAdGogXf76MlR0_Bzs1WHtqYvEXQQ/exec";

/* ═══════════════════════════════════════════════════════════
 * SAFE HELPERS
 * ═══════════════════════════════════════════════════════════ */
function safeArray(val) {
  if (!val) return [];
  if (Array.isArray(val)) return val;
  if (typeof val === "string") {
    try {
      const parsed = JSON.parse(val);
      return Array.isArray(parsed) ? parsed : [];
    } catch {
      return [];
    }
  }
  return [];
}

function safeObject(val) {
  if (!val) return null;
  if (typeof val === "object" && !Array.isArray(val)) {
    if (val instanceof Date) return null;
    return Object.keys(val).length > 0 ? val : null;
  }
  if (typeof val === "string") {
    let trimmed = val.trim();
    if (trimmed.startsWith("'")) trimmed = trimmed.slice(1);
    if (!trimmed || trimmed === "null" || trimmed === "undefined") return null;
    try {
      const parsed = JSON.parse(trimmed);
      if (parsed && typeof parsed === "object" && !Array.isArray(parsed))
        return parsed;
      return null;
    } catch {
      return null;
    }
  }
  return null;
}

function safeNumber(val, fallback = 0) {
  if (val === null || val === undefined || val === "") return fallback;
  const n = Number(val);
  return isNaN(n) ? fallback : n;
}

function safeBool(val) {
  return (
    val === true || val === "true" || val === "TRUE" || val === 1 || val === "1"
  );
}

function safeString(val, fallback = "") {
  if (val === null || val === undefined) return fallback;
  return String(val);
}

function cleanUrl(url) {
  if (!url) return "";
  let str = String(url).trim();
  if (str.startsWith("'")) str = str.slice(1);
  if (str === "undefined" || str === "null") return "";
  return str;
}

/* ═══ تحويل روابط Google Drive إلى رابط مباشر ═══ */
export function toDirectDriveUrl(url) {
  if (!url) return url;
  const str = String(url).trim();
  if (!str) return "";

  // إذا كان صحيح مسبقاً
  if (str.includes("uc?export=download") || str.includes("uc?id=")) {
    if (!str.includes("confirm=")) {
      return str + (str.includes("?") ? "&" : "?") + "confirm=t";
    }
    return str;
  }

  // استخراج fileId
  let fileId = null;
  const patterns = [
    /\/d\/([^/]+)/,
    /[?&]id=([^&]+)/,
    /lh3\.googleusercontent\.com\/d\/([^/?]+)/,
  ];

  for (const pattern of patterns) {
    const match = str.match(pattern);
    if (match) {
      fileId = match[1];
      break;
    }
  }

  if (!fileId) return str;

  return `https://drive.google.com/uc?export=download&confirm=t&id=${fileId}`;
}

/* ═══ Attachments ═══ */
function serializeAttachments(att) {
  if (att === null || att === undefined) return "[]";
  if (typeof att === "string") {
    const trimmed = att.trim();
    if (!trimmed || trimmed === "null" || trimmed === "undefined") return "[]";
    try {
      const parsed = JSON.parse(trimmed);
      if (Array.isArray(parsed)) return JSON.stringify(parsed);
      return "[]";
    } catch {
      return "[]";
    }
  }
  if (Array.isArray(att)) return JSON.stringify(att);
  return "[]";
}

function normalizeAttachments(val) {
  if (!val) return [];
  let current = val;
  for (let i = 0; i < 3; i++) {
    if (Array.isArray(current)) return current;
    if (typeof current !== "string") break;
    const trimmed = current.trim();
    if (!trimmed) return [];
    try {
      current = JSON.parse(trimmed);
    } catch {
      return [];
    }
  }
  return Array.isArray(current) ? current : [];
}

/* ═══ Aircraft ═══ */
function normalizeAircraft(val) {
  if (!val) return [];
  if (Array.isArray(val)) return val.map(String).filter(Boolean);
  if (typeof val === "string") {
    const trimmed = val.trim();
    if (!trimmed) return [];
    try {
      const parsed = JSON.parse(trimmed);
      if (Array.isArray(parsed)) return parsed.map(String).filter(Boolean);
    } catch {
      return trimmed
        .split(",")
        .map((s) => s.trim())
        .filter(Boolean);
    }
  }
  return [];
}

function serializeAircraft(arr) {
  if (arr === null || arr === undefined) return "[]";
  if (typeof arr === "string") {
    const trimmed = arr.trim();
    if (!trimmed) return "[]";
    try {
      const parsed = JSON.parse(trimmed);
      if (Array.isArray(parsed)) return JSON.stringify(parsed);
    } catch {
      return JSON.stringify(
        trimmed
          .split(",")
          .map((s) => s.trim())
          .filter(Boolean)
      );
    }
  }
  if (Array.isArray(arr)) return JSON.stringify(arr);
  return "[]";
}

/* ═══ Positions ═══ */
function normalizePositions(val) {
  if (!val) return [];
  if (Array.isArray(val)) return val;
  if (typeof val === "string") {
    const trimmed = val.trim();
    if (!trimmed) return [];
    try {
      const parsed = JSON.parse(trimmed);
      if (Array.isArray(parsed)) return parsed;
    } catch {
      return [];
    }
  }
  return [];
}

function serializePositions(arr) {
  if (arr === null || arr === undefined) return "";
  if (typeof arr === "string") {
    const trimmed = arr.trim();
    if (!trimmed) return "";
    try {
      const parsed = JSON.parse(trimmed);
      if (Array.isArray(parsed)) return JSON.stringify(parsed);
    } catch {
      return "";
    }
  }
  if (Array.isArray(arr)) return JSON.stringify(arr);
  return "";
}

/* ═══ Secondary Roles ═══ */
function normalizeSecondaryRoles(val) {
  if (!val) return [];
  if (Array.isArray(val)) return val.map(String).filter(Boolean);
  if (typeof val === "string") {
    const trimmed = val.trim();
    if (!trimmed) return [];
    try {
      const parsed = JSON.parse(trimmed);
      if (Array.isArray(parsed)) return parsed.map(String).filter(Boolean);
    } catch {
      return trimmed
        .split(",")
        .map((s) => s.trim())
        .filter(Boolean);
    }
  }
  return [];
}

function serializeSecondaryRoles(arr) {
  if (arr === null || arr === undefined) return "[]";
  if (typeof arr === "string") {
    const trimmed = arr.trim();
    if (!trimmed) return "[]";
    try {
      const parsed = JSON.parse(trimmed);
      if (Array.isArray(parsed)) return JSON.stringify(parsed);
    } catch {
      return JSON.stringify(
        trimmed
          .split(",")
          .map((s) => s.trim())
          .filter(Boolean)
      );
    }
  }
  if (Array.isArray(arr)) return JSON.stringify(arr);
  return "[]";
}

/* ═══ Legs ═══ */
function normalizeLegs(val) {
  if (!val) return [];
  if (Array.isArray(val)) return val;
  if (typeof val === "string") {
    const trimmed = val.trim();
    if (!trimmed || trimmed === "null" || trimmed === "undefined") return [];
    try {
      const parsed = JSON.parse(trimmed);
      return Array.isArray(parsed) ? parsed : [];
    } catch {
      return [];
    }
  }
  return [];
}

function serializeLegs(arr) {
  if (arr === null || arr === undefined) return "[]";
  if (Array.isArray(arr)) return JSON.stringify(arr);
  if (typeof arr === "string") {
    const trimmed = arr.trim();
    if (!trimmed) return "[]";
    try {
      const parsed = JSON.parse(trimmed);
      if (Array.isArray(parsed)) return JSON.stringify(parsed);
    } catch {}
  }
  return "[]";
}

/* ═══ CAMO Attachments ═══ */
function normalizeCamoAttachments(val) {
  if (!val) return [];
  if (Array.isArray(val)) return val;
  if (typeof val === "string") {
    try {
      const p = JSON.parse(val);
      return Array.isArray(p) ? p : [];
    } catch {
      return [];
    }
  }
  return [];
}

/* ═══ Menu Items ═══ */
function normalizeMenuItems(val) {
  if (!val) return [];
  if (Array.isArray(val)) return val;
  if (typeof val === "string") {
    try {
      const p = JSON.parse(val);
      return Array.isArray(p) ? p : [];
    } catch {
      return [];
    }
  }
  return [];
}

/* ═══════════════════════════════════════════════════════════
 * Core
 * ═══════════════════════════════════════════════════════════ */
async function apiCall(action, sheet, data = {}, id = null) {
  const payload = JSON.stringify({ action, sheet, data, id });
  const body = "payload=" + encodeURIComponent(payload);

  const res = await fetch(API_URL, {
    method: "POST",
    body,
    headers: {
      "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8",
    },
    redirect: "follow",
  });

  const text = await res.text();
  if (text.trim().startsWith("<")) {
    const m = text.match(/<title>(.*?)<\/title>/i);
    throw new Error("Apps Script error: " + (m ? m[1] : "HTML"));
  }

  let result;
  try {
    result = JSON.parse(text);
  } catch {
    throw new Error("Non-JSON: " + text.substring(0, 200));
  }

  if (!result.ok) throw new Error(result.error || "API Error");
  return result.data;
}

async function apiRead(sheet) {
  const res = await fetch(`${API_URL}?sheet=${encodeURIComponent(sheet)}`, {
    method: "GET",
    redirect: "follow",
  });

  const text = await res.text();
  if (text.trim().startsWith("<")) {
    const m = text.match(/<title>(.*?)<\/title>/i);
    throw new Error("Apps Script error: " + (m ? m[1] : "HTML"));
  }

  let result;
  try {
    result = JSON.parse(text);
  } catch {
    throw new Error("Non-JSON: " + text.substring(0, 200));
  }

  if (!result.ok) throw new Error(result.error || "Read Error");
  return result.data || [];
}

/* ═══════════════════════════════════════════════════════════
 * CREW
 * ═══════════════════════════════════════════════════════════ */
export const crewAPI = {
  list: async () => {
    const list = await apiRead("Crew");
    return list.map((c) => ({
      ...c,
      attachments: normalizeAttachments(c.attachments),
      assignedAircraft: normalizeAircraft(c.assignedAircraft),
      secondaryRoles: normalizeSecondaryRoles(c.secondaryRoles),
      ftl28: safeNumber(c.ftl28, 0),
      active: safeBool(c.active),
      status: safeString(c.status, "active"),
    }));
  },
  create: (c) =>
    apiCall("create", "Crew", {
      fullName: c.fullName || "",
      role: c.role || "",
      secondaryRoles: serializeSecondaryRoles(c.secondaryRoles),
      empNo: c.empNo || "",
      email: c.email || "",
      phone: c.phone || "",
      nationality: c.nationality || "",
      dob: c.dob || "",
      gender: c.gender || "male",
      base: c.base || "",
      licenseNo: c.licenseNo || "",
      licenseExpiry: c.licenseExpiry || "",
      medicalExpiry: c.medicalExpiry || "",
      passportNo: c.passportNo || "",
      passportExpiry: c.passportExpiry || "",
      eNumber: c.eNumber || "",
      ftl28: c.ftl28 || 0,
      avatar: c.avatar || "",
      status: c.status || "active",
      attachments: serializeAttachments(c.attachments),
      assignedAircraft: serializeAircraft(c.assignedAircraft),
    }),
  update: (id, c) =>
    apiCall(
      "update",
      "Crew",
      {
        fullName: c.fullName || "",
        role: c.role || "",
        secondaryRoles: serializeSecondaryRoles(c.secondaryRoles),
        empNo: c.empNo || "",
        email: c.email || "",
        phone: c.phone || "",
        nationality: c.nationality || "",
        dob: c.dob || "",
        gender: c.gender || "male",
        base: c.base || "",
        licenseNo: c.licenseNo || "",
        licenseExpiry: c.licenseExpiry || "",
        medicalExpiry: c.medicalExpiry || "",
        passportNo: c.passportNo || "",
        passportExpiry: c.passportExpiry || "",
        eNumber: c.eNumber || "",
        ftl28: c.ftl28 || 0,
        avatar: c.avatar || "",
        status: c.status || "active",
        attachments: serializeAttachments(c.attachments),
        assignedAircraft: serializeAircraft(c.assignedAircraft),
      },
      id
    ),
  remove: (id) => apiCall("delete", "Crew", {}, id),
};

/* ═══════════════════════════════════════════════════════════
 * FLEET
 * ═══════════════════════════════════════════════════════════ */
export const fleetAPI = {
  list: async () => {
    const list = await apiRead("Fleet");
    return list.map((a) => ({
      ...a,
      attachments: normalizeAttachments(a.attachments),
      tah: safeNumber(a.tah, 0),
      tac: safeNumber(a.tac, 0),
      status: safeString(a.status, "AIRWORTHY"),
    }));
  },
  create: (a) =>
    apiCall("create", "Fleet", {
      reg: a.reg || "",
      type: a.type || "",
      status: a.status || "AIRWORTHY",
      tah: a.tah || 0,
      tac: a.tac || 0,
      lastCheck: a.lastCheck || "",
      nextCheck: a.nextCheck || "",
      attachments: serializeAttachments(a.attachments),
    }),
  update: (id, a) =>
    apiCall(
      "update",
      "Fleet",
      {
        reg: a.reg || "",
        type: a.type || "",
        status: a.status || "AIRWORTHY",
        tah: a.tah || 0,
        tac: a.tac || 0,
        lastCheck: a.lastCheck || "",
        nextCheck: a.nextCheck || "",
        attachments: serializeAttachments(a.attachments),
      },
      id
    ),
  remove: (id) => apiCall("delete", "Fleet", {}, id),
};

/* ═══════════════════════════════════════════════════════════
 * FLIGHTS — v5.1 (added route)
 * ═══════════════════════════════════════════════════════════ */
export const flightsAPI = {
  list: async () => {
    const list = await apiRead("Flights");
    return list.map((f) => {
      const actual = safeObject(f.actual);
      return {
        ...f,
        crewSlots: safeArray(f.crewSlots),
        legs: normalizeLegs(f.legs),
        actual: actual || {},
        pax: safeNumber(f.pax, 0),
        cargo: safeNumber(f.cargo, 0),
        status: safeString(f.status, "SCHEDULED"),
        flightType: safeString(f.flightType, "SCHEDULED"),
        notes: safeString(f.notes),
        permits: safeString(f.permits),
        services: safeString(f.services),
        // ⭐ جديد: route (يُملأ تلقائياً إذا لم يكن موجوداً)
        route: safeString(f.route, `${f.dep || ""}/${f.arr || ""}`),
      };
    });
  },
  create: (f) =>
    apiCall("create", "Flights", {
      flightNo: f.flightNo || "",
      dep: f.dep || "",
      arr: f.arr || "",
      altn: f.altn || "",
      altn2: f.altn2 || "",
      std: f.std || "",
      sta: f.sta || "",
      acft: f.acft || "",
      status: f.status || "SCHEDULED",
      flightType: f.flightType || "SCHEDULED",
      notes: f.notes || "",
      permits: f.permits || "",
      services: f.services || "",
      pax: f.pax || 0,
      cargo: f.cargo || 0,
      crewSlots: JSON.stringify(f.crewSlots || []),
      actual: f.actual ? JSON.stringify(f.actual) : "",
      legs: serializeLegs(f.legs || []),
      // ⭐ جديد
      route: f.route || `${f.dep || ""}/${f.arr || ""}`,
    }),
  update: (id, f) =>
    apiCall(
      "update",
      "Flights",
      {
        flightNo: f.flightNo || "",
        dep: f.dep || "",
        arr: f.arr || "",
        altn: f.altn || "",
        altn2: f.altn2 || "",
        std: f.std || "",
        sta: f.sta || "",
        acft: f.acft || "",
        status: f.status || "SCHEDULED",
        flightType: f.flightType || "SCHEDULED",
        notes: f.notes || "",
        permits: f.permits || "",
        services: f.services || "",
        pax: f.pax || 0,
        cargo: f.cargo || 0,
        crewSlots: JSON.stringify(f.crewSlots || []),
        actual: f.actual ? JSON.stringify(f.actual) : "",
        legs: serializeLegs(f.legs || []),
        // ⭐ جديد
        route: f.route || `${f.dep || ""}/${f.arr || ""}`,
      },
      id
    ),
  remove: (id) => apiCall("delete", "Flights", {}, id),
};

/* ═══════════════════════════════════════════════════════════
 * USERS / ROLES
 * ═══════════════════════════════════════════════════════════ */
export const usersAPI = {
  list: async () => {
    const list = await apiRead("Users");
    return list.map((u) => ({
      ...u,
      perms: safeArray(u.perms),
      active: safeBool(u.active),
      username: safeString(u.username),
      password: safeString(u.password),
      fullName: safeString(u.fullName),
      role: safeString(u.role, "crewMember"),
    }));
  },
  create: (u) =>
    apiCall("create", "Users", {
      username: u.username || "",
      password: u.password || "",
      fullName: u.fullName || "",
      role: u.role || "dispatcher",
      email: u.email || "",
      phone: u.phone || "",
      jobTitle: u.jobTitle || "",
      active: u.active !== false,
      crewId: u.crewId || "",
      perms: JSON.stringify(u.perms || []),
      avatar: u.avatar || "",
    }),
  update: (id, u) =>
    apiCall(
      "update",
      "Users",
      {
        username: u.username || "",
        password: u.password || "",
        fullName: u.fullName || "",
        role: u.role || "dispatcher",
        email: u.email || "",
        phone: u.phone || "",
        jobTitle: u.jobTitle || "",
        active: u.active !== false,
        crewId: u.crewId || "",
        perms: JSON.stringify(u.perms || []),
        avatar: u.avatar || "",
      },
      id
    ),
  remove: (id) => apiCall("delete", "Users", {}, id),
};

export const rolesAPI = {
  list: async () => {
    const list = await apiRead("Roles");
    return list.map((r) => ({
      id: r.id,
      name: safeString(r.name),
      nameAr: safeString(r.nameAr, r.name),
      description: safeString(r.description),
      perms: safeArray(r.perms),
      active: safeBool(r.active),
    }));
  },
  create: (role) =>
    apiCall("create", "Roles", {
      name: role.name || "",
      nameAr: role.nameAr || role.name || "",
      description: role.description || "",
      perms: JSON.stringify(role.perms || []),
      active: role.active !== false,
    }),
  update: (id, role) =>
    apiCall(
      "update",
      "Roles",
      {
        name: role.name || "",
        nameAr: role.nameAr || role.name || "",
        description: role.description || "",
        perms: JSON.stringify(role.perms || []),
        active: role.active !== false,
      },
      id
    ),
  remove: (id) => apiCall("delete", "Roles", {}, id),
};

/* ═══════════════════════════════════════════════════════════
 * SETTINGS — v5.1 (added aircraft, COA, address, etc.)
 * ═══════════════════════════════════════════════════════════ */
export const settingsAPI = {
  get: async () => {
    const list = await apiRead("Settings");
    if (!list[0]) return null;
    const s = list[0];
    return {
      ...s,
      companyName: safeString(s.companyName, "AeroOps"),
      companyNameAr: safeString(s.companyNameAr, "إيرو أوبس"),
      operatorCode: safeString(s.operatorCode, "EACS"),
      country: safeString(s.country, ""),
      navLayout: safeString(s.navLayout, "top"),
      tabPreferences: safeObject(s.tabPreferences) || null,
      logo: cleanUrl(s.logo),
      stamp: cleanUrl(s.stamp),
      timeMode: safeString(s.timeMode, "utc"),
      emailFrom: cleanUrl(s.emailFrom || ""),
      autoFlightEmails: s.autoFlightEmails !== false,
      autoExpiryAlerts: s.autoExpiryAlerts !== false,
      positions: normalizePositions(s.positions),
      globalTheme: safeString(s.globalTheme, "modern"),
      portalTheme: safeString(s.portalTheme, "modern"),
      // ⭐ v5.1 — حقول Permits
      aircraftType: safeString(s.aircraftType, "A319"),
      coaExpiry: safeString(s.coaExpiry, ""),
      address: safeString(s.address, ""),
      phone: safeString(s.phone, ""),
      email: safeString(s.email, ""),
      sita: safeString(s.sita, ""),
      fax: safeString(s.fax, ""),
      contactPerson: safeString(s.contactPerson, ""),
      seatCapacity: safeNumber(s.seatCapacity, 0),
      cargoCapacity: safeNumber(s.cargoCapacity, 0),
      noiseCertificate: safeString(s.noiseCertificate, ""),
    };
  },
  save: async (data) => {
    let existing = null;
    try {
      existing = await settingsAPI.get();
    } catch {}

    const pick = (key, fallback) =>
      data[key] !== undefined ? data[key] : existing?.[key] ?? fallback;

    const merged = {
      companyName: pick("companyName", ""),
      companyNameAr: pick("companyNameAr", ""),
      operatorCode: String(pick("operatorCode", "EACS")).toUpperCase(),
      country: pick("country", ""),
      navLayout: pick("navLayout", "top"),
      tabPreferences: pick("tabPreferences", null),
      logo: pick("logo", ""),
      stamp: pick("stamp", ""),
      timeMode: pick("timeMode", "utc"),
      emailFrom: pick("emailFrom", ""),
      autoFlightEmails: pick("autoFlightEmails", true),
      autoExpiryAlerts: pick("autoExpiryAlerts", true),
      positions: pick("positions", []),
      globalTheme: pick("globalTheme", "modern"),
      portalTheme: pick("portalTheme", "modern"),
      // ⭐ v5.1 — حقول Permits
      aircraftType: pick("aircraftType", ""),
      coaExpiry: pick("coaExpiry", ""),
      address: pick("address", ""),
      phone: pick("phone", ""),
      email: pick("email", ""),
      sita: pick("sita", ""),
      fax: pick("fax", ""),
      contactPerson: pick("contactPerson", ""),
      seatCapacity: pick("seatCapacity", 0),
      cargoCapacity: pick("cargoCapacity", 0),
      noiseCertificate: pick("noiseCertificate", ""),
    };

    const payload = {
      ...merged,
      tabPreferences: merged.tabPreferences
        ? JSON.stringify(merged.tabPreferences)
        : "",
      positions: serializePositions(merged.positions),
    };

    if (existing && existing.id)
      return apiCall("update", "Settings", payload, existing.id);
    return apiCall("create", "Settings", payload);
  },
};

/* ═══════════════════════════════════════════════════════════
 * AUDIT / ROSTER / STANDBY / LEAVE / TRAINING
 * ═══════════════════════════════════════════════════════════ */
export const auditAPI = {
  list: async () => {
    const list = await apiRead("AuditLog");
    return list.map((l) => ({
      ...l,
      timestamp: safeString(l.timestamp),
      userId: safeString(l.userId),
      userName: safeString(l.userName),
      userRole: safeString(l.userRole),
      action: safeString(l.action),
      entity: safeString(l.entity),
      entityId: safeString(l.entityId),
      entityName: safeString(l.entityName),
      details: safeString(l.details, "{}"),
      ipAddress: safeString(l.ipAddress),
      userAgent: safeString(l.userAgent),
    }));
  },
  create: (log) =>
    apiCall("create", "AuditLog", {
      timestamp: log.timestamp || new Date().toISOString(),
      userId: log.userId || "",
      userName: log.userName || "",
      userRole: log.userRole || "",
      action: log.action || "",
      entity: log.entity || "",
      entityId: log.entityId || "",
      entityName: log.entityName || "",
      details:
        typeof log.details === "string"
          ? log.details
          : JSON.stringify(log.details || {}),
      ipAddress: log.ipAddress || "",
      userAgent: log.userAgent || "",
    }),
  remove: (id) => apiCall("delete", "AuditLog", {}, id),
};

export const rosterAPI = {
  list: async () => {
    const list = await apiRead("Roster");
    return list.map((r) => ({
      ...r,
      date: safeString(r.date),
      crewId: safeString(r.crewId),
      crewName: safeString(r.crewName),
      type: safeString(r.type, "FLIGHT"),
      flightIds: safeArray(r.flightIds),
      startTime: safeString(r.startTime),
      endTime: safeString(r.endTime),
      notes: safeString(r.notes),
      status: safeString(r.status, "published"),
      publishedAt: safeString(r.publishedAt),
    }));
  },
  create: (r) =>
    apiCall("create", "Roster", {
      date: r.date || "",
      crewId: r.crewId || "",
      crewName: r.crewName || "",
      type: r.type || "FLIGHT",
      flightIds: JSON.stringify(r.flightIds || []),
      startTime: r.startTime || "",
      endTime: r.endTime || "",
      notes: r.notes || "",
      status: r.status || "published",
      publishedAt: r.publishedAt || "",
    }),
  update: (id, r) =>
    apiCall(
      "update",
      "Roster",
      {
        date: r.date || "",
        crewId: r.crewId || "",
        crewName: r.crewName || "",
        type: r.type || "FLIGHT",
        flightIds: JSON.stringify(r.flightIds || []),
        startTime: r.startTime || "",
        endTime: r.endTime || "",
        notes: r.notes || "",
        status: r.status || "published",
        publishedAt: r.publishedAt || "",
      },
      id
    ),
  remove: (id) => apiCall("delete", "Roster", {}, id),
};

export const standbyAPI = {
  list: async () => {
    const list = await apiRead("Standby");
    return list.map((s) => ({
      ...s,
      date: safeString(s.date),
      crewId: safeString(s.crewId),
      crewName: safeString(s.crewName),
      type: safeString(s.type, "AIRPORT"),
      startTime: safeString(s.startTime),
      endTime: safeString(s.endTime),
      durationMin: safeNumber(s.durationMin, 0),
      activated: safeBool(s.activated),
      activatedAt: safeString(s.activatedAt),
      flightId: safeString(s.flightId),
      notes: safeString(s.notes),
    }));
  },
  create: (s) =>
    apiCall("create", "Standby", {
      date: s.date || "",
      crewId: s.crewId || "",
      crewName: s.crewName || "",
      type: s.type || "AIRPORT",
      startTime: s.startTime || "",
      endTime: s.endTime || "",
      durationMin: s.durationMin || 0,
      activated: s.activated || false,
      activatedAt: s.activatedAt || "",
      flightId: s.flightId || "",
      notes: s.notes || "",
    }),
  update: (id, s) =>
    apiCall(
      "update",
      "Standby",
      {
        date: s.date || "",
        crewId: s.crewId || "",
        crewName: s.crewName || "",
        type: s.type || "AIRPORT",
        startTime: s.startTime || "",
        endTime: s.endTime || "",
        durationMin: s.durationMin || 0,
        activated: s.activated || false,
        activatedAt: s.activatedAt || "",
        flightId: s.flightId || "",
        notes: s.notes || "",
      },
      id
    ),
  remove: (id) => apiCall("delete", "Standby", {}, id),
};

export const leaveAPI = {
  list: async () => {
    const list = await apiRead("Leave");
    return list.map((l) => ({
      ...l,
      crewId: safeString(l.crewId),
      crewName: safeString(l.crewName),
      type: safeString(l.type, "ANNUAL"),
      fromDate: safeString(l.fromDate),
      toDate: safeString(l.toDate),
      days: safeNumber(l.days, 0),
      reason: safeString(l.reason),
      status: safeString(l.status, "pending"),
      requestedAt: safeString(l.requestedAt),
      approvedBy: safeString(l.approvedBy),
      approvedAt: safeString(l.approvedAt),
      notes: safeString(l.notes),
    }));
  },
  create: (l) =>
    apiCall("create", "Leave", {
      crewId: l.crewId || "",
      crewName: l.crewName || "",
      type: l.type || "ANNUAL",
      fromDate: l.fromDate || "",
      toDate: l.toDate || "",
      days: l.days || 0,
      reason: l.reason || "",
      status: l.status || "pending",
      requestedAt: l.requestedAt || new Date().toISOString(),
      approvedBy: l.approvedBy || "",
      approvedAt: l.approvedAt || "",
      notes: l.notes || "",
    }),
  update: (id, l) =>
    apiCall(
      "update",
      "Leave",
      {
        crewId: l.crewId || "",
        crewName: l.crewName || "",
        type: l.type || "ANNUAL",
        fromDate: l.fromDate || "",
        toDate: l.toDate || "",
        days: l.days || 0,
        reason: l.reason || "",
        status: l.status || "pending",
        requestedAt: l.requestedAt || "",
        approvedBy: l.approvedBy || "",
        approvedAt: l.approvedAt || "",
        notes: l.notes || "",
      },
      id
    ),
  remove: (id) => apiCall("delete", "Leave", {}, id),
};

export const trainingAPI = {
  list: async () => {
    const list = await apiRead("Training");
    return list.map((t) => ({
      ...t,
      crewId: safeString(t.crewId),
      crewName: safeString(t.crewName),
      type: safeString(t.type, "SIMULATOR"),
      title: safeString(t.title),
      date: safeString(t.date),
      expiryDate: safeString(t.expiryDate),
      instructor: safeString(t.instructor),
      location: safeString(t.location),
      result: safeString(t.result, "PASS"),
      score: safeString(t.score),
      notes: safeString(t.notes),
      certificate: safeString(t.certificate),
    }));
  },
  create: (t) =>
    apiCall("create", "Training", {
      crewId: t.crewId || "",
      crewName: t.crewName || "",
      type: t.type || "SIMULATOR",
      title: t.title || "",
      date: t.date || "",
      expiryDate: t.expiryDate || "",
      instructor: t.instructor || "",
      location: t.location || "",
      result: t.result || "PASS",
      score: t.score || "",
      notes: t.notes || "",
      certificate: t.certificate || "",
    }),
  update: (id, t) =>
    apiCall(
      "update",
      "Training",
      {
        crewId: t.crewId || "",
        crewName: t.crewName || "",
        type: t.type || "SIMULATOR",
        title: t.title || "",
        date: t.date || "",
        expiryDate: t.expiryDate || "",
        instructor: t.instructor || "",
        location: t.location || "",
        result: t.result || "PASS",
        score: t.score || "",
        notes: t.notes || "",
        certificate: t.certificate || "",
      },
      id
    ),
  remove: (id) => apiCall("delete", "Training", {}, id),
};

/* ═══════════════════════════════════════════════════════════
 * LOGIN HISTORY / MANUALS / MANUALS AUDIT
 * ═══════════════════════════════════════════════════════════ */
export const loginHistoryAPI = {
  list: async () => {
    const list = await apiRead("LoginHistory");
    return list.map((h) => ({
      ...h,
      timestamp: safeString(h.timestamp),
      userId: safeString(h.userId),
      userName: safeString(h.userName),
      username: safeString(h.username),
      userRole: safeString(h.userRole),
      action: safeString(h.action, "LOGIN"),
      browser: safeString(h.browser),
      os: safeString(h.os),
      userAgent: safeString(h.userAgent),
      ipAddress: safeString(h.ipAddress),
      success: safeBool(h.success) || h.success === undefined,
      reason: safeString(h.reason),
    }));
  },
  create: (h) =>
    apiCall("create", "LoginHistory", {
      timestamp: h.timestamp || new Date().toISOString(),
      userId: h.userId || "",
      userName: h.userName || "",
      username: h.username || "",
      userRole: h.userRole || "",
      action: h.action || "LOGIN",
      browser: h.browser || "",
      os: h.os || "",
      userAgent: h.userAgent || "",
      ipAddress: h.ipAddress || "",
      success: h.success !== false,
      reason: h.reason || "",
    }),
  remove: (id) => apiCall("delete", "LoginHistory", {}, id),
};

export const manualsAPI = {
  list: async () => {
    const list = await apiRead("Manuals");
    return list.map((m) => ({
      ...m,
      code: safeString(m.code, ""),
      title_en: safeString(m.title_en, "Untitled"),
      title_ar: safeString(m.title_ar, ""),
      category: safeString(m.category, "Operations"),
      rev: safeString(m.rev, ""),
      effectiveDate: safeString(m.effectiveDate, ""),
      approval: safeString(m.approval, ""),
      status: safeString(m.status, "active"),
      pages: safeNumber(m.pages, 0),
      fileSize: safeString(m.fileSize, ""),
      pdfData: safeString(m.pdfData, ""),
      pdfName: safeString(m.pdfName, ""),
      visibleTo: safeString(m.visibleTo, "all"),
      lastUpdated: safeString(m.lastUpdated, ""),
      lastUpdatedBy: safeString(m.lastUpdatedBy, ""),
      lastUpdatedById: safeString(m.lastUpdatedById, ""),
      summary: safeString(m.summary, ""),
      chapters: safeArray(m.chapters),
    }));
  },
  create: (m) =>
    apiCall("create", "Manuals", {
      code: m.code || "",
      title_en: m.title_en || "",
      title_ar: m.title_ar || "",
      category: m.category || "Operations",
      rev: m.rev || "",
      effectiveDate: m.effectiveDate || "",
      approval: m.approval || "",
      status: m.status || "active",
      pages: m.pages || 0,
      fileSize: m.fileSize || "",
      pdfData: m.pdfData || "",
      pdfName: m.pdfName || "",
      visibleTo: m.visibleTo || "all",
      lastUpdated: m.lastUpdated || new Date().toISOString(),
      lastUpdatedBy: m.lastUpdatedBy || "",
      lastUpdatedById: m.lastUpdatedById || "",
      summary: m.summary || "",
      chapters: JSON.stringify(m.chapters || []),
    }),
  update: (id, m) =>
    apiCall(
      "update",
      "Manuals",
      {
        code: m.code || "",
        title_en: m.title_en || "",
        title_ar: m.title_ar || "",
        category: m.category || "Operations",
        rev: m.rev || "",
        effectiveDate: m.effectiveDate || "",
        approval: m.approval || "",
        status: m.status || "active",
        pages: m.pages || 0,
        fileSize: m.fileSize || "",
        pdfData: m.pdfData || "",
        pdfName: m.pdfName || "",
        visibleTo: m.visibleTo || "all",
        lastUpdated: m.lastUpdated || new Date().toISOString(),
        lastUpdatedBy: m.lastUpdatedBy || "",
        lastUpdatedById: m.lastUpdatedById || "",
        summary: m.summary || "",
        chapters: JSON.stringify(m.chapters || []),
      },
      id
    ),
  remove: (id) => apiCall("delete", "Manuals", {}, id),
};

export const manualAuditAPI = {
  list: async () => {
    const list = await apiRead("ManualsAuditLog");
    return list.map((l) => ({
      ...l,
      timestamp: safeString(l.timestamp),
      userId: safeString(l.userId),
      userName: safeString(l.userName),
      userRole: safeString(l.userRole),
      action: safeString(l.action),
      manualId: safeString(l.manualId),
      manualCode: safeString(l.manualCode),
      manualTitle: safeString(l.manualTitle),
      previousUpdate: safeString(l.previousUpdate),
      newUpdate: safeString(l.newUpdate),
      details: safeString(l.details, "{}"),
    }));
  },
  create: (log) => apiCall("logManualAudit", null, log),
  remove: (id) => apiCall("deleteManualAuditLog", null, {}, id),
  clearOld: async (beforeDate) =>
    apiCall("clearOldManualAuditLog", null, { beforeDate }),
};

/* ═══════════════════════════════════════════════════════════
 * ALERTS
 * ═══════════════════════════════════════════════════════════ */
export const alertsAPI = {
  listDismissed: async () => {
    const list = await apiRead("DismissedAlerts");
    return list.map((d) => ({
      id: safeString(d.id),
      alertKey: safeString(d.alertKey),
      dismissedBy: safeString(d.dismissedBy),
      dismissedAt: safeString(d.dismissedAt),
      reason: safeString(d.reason),
    }));
  },
  dismiss: (alertKey, userId, userName, reason = "") =>
    apiCall("dismissAlert", null, { alertKey, dismissedBy: userName, reason }),
  undismiss: (alertKey) => apiCall("undismissAlert", null, { alertKey }),
};

/* ═══════════════════════════════════════════════════════════
 * CAMO / MEL
 * ═══════════════════════════════════════════════════════════ */
export const camoAPI = {
  list: async () => {
    const list = await apiRead("CAMO");
    return list.map((c) => ({
      ...c,
      tah: safeNumber(c.tah, 0),
      tac: safeNumber(c.tac, 0),
      engine1Hours: safeNumber(c.engine1Hours, 0),
      engine1Cycles: safeNumber(c.engine1Cycles, 0),
      engine2Hours: safeNumber(c.engine2Hours, 0),
      engine2Cycles: safeNumber(c.engine2Cycles, 0),
      apuHours: safeNumber(c.apuHours, 0),
      apuCycles: safeNumber(c.apuCycles, 0),
      llpHours: safeNumber(c.llpHours, 0),
      llpCycles: safeNumber(c.llpCycles, 0),
      adCompliance: safeArray(c.adCompliance),
      sbCompliance: safeArray(c.sbCompliance),
      damageList: safeArray(c.damageList),
      attachments: normalizeCamoAttachments(c.attachments),
      status: safeString(c.status, "AIRWORTHY"),
    }));
  },
  create: (c) =>
    apiCall("create", "CAMO", {
      reg: c.reg || "",
      type: c.type || "",
      tah: c.tah || 0,
      tac: c.tac || 0,
      lastCheckDate: c.lastCheckDate || "",
      lastCheckType: c.lastCheckType || "",
      nextCheckDate: c.nextCheckDate || "",
      nextCheckType: c.nextCheckType || "",
      coaExpiry: c.coaExpiry || "",
      insuranceExpiry: c.insuranceExpiry || "",
      noiseCertExpiry: c.noiseCertExpiry || "",
      engine1Hours: c.engine1Hours || 0,
      engine1Cycles: c.engine1Cycles || 0,
      engine2Hours: c.engine2Hours || 0,
      engine2Cycles: c.engine2Cycles || 0,
      apuHours: c.apuHours || 0,
      apuCycles: c.apuCycles || 0,
      llpHours: c.llpHours || 0,
      llpCycles: c.llpCycles || 0,
      adCompliance: JSON.stringify(c.adCompliance || []),
      sbCompliance: JSON.stringify(c.sbCompliance || []),
      damageList: JSON.stringify(c.damageList || []),
      notes: c.notes || "",
      status: c.status || "AIRWORTHY",
      attachments: JSON.stringify(c.attachments || []),
      lastUpdated: new Date().toISOString(),
      updatedBy: c.updatedBy || "",
    }),
  update: (id, c) =>
    apiCall(
      "update",
      "CAMO",
      {
        reg: c.reg || "",
        type: c.type || "",
        tah: c.tah || 0,
        tac: c.tac || 0,
        lastCheckDate: c.lastCheckDate || "",
        lastCheckType: c.lastCheckType || "",
        nextCheckDate: c.nextCheckDate || "",
        nextCheckType: c.nextCheckType || "",
        coaExpiry: c.coaExpiry || "",
        insuranceExpiry: c.insuranceExpiry || "",
        noiseCertExpiry: c.noiseCertExpiry || "",
        engine1Hours: c.engine1Hours || 0,
        engine1Cycles: c.engine1Cycles || 0,
        engine2Hours: c.engine2Hours || 0,
        engine2Cycles: c.engine2Cycles || 0,
        apuHours: c.apuHours || 0,
        apuCycles: c.apuCycles || 0,
        llpHours: c.llpHours || 0,
        llpCycles: c.llpCycles || 0,
        adCompliance: JSON.stringify(c.adCompliance || []),
        sbCompliance: JSON.stringify(c.sbCompliance || []),
        damageList: JSON.stringify(c.damageList || []),
        notes: c.notes || "",
        status: c.status || "AIRWORTHY",
        attachments: JSON.stringify(c.attachments || []),
        lastUpdated: new Date().toISOString(),
        updatedBy: c.updatedBy || "",
      },
      id
    ),
  remove: (id) => apiCall("delete", "CAMO", {}, id),
};

export const melAPI = {
  list: async () => {
    const list = await apiRead("MEL");
    return list.map((m) => ({
      ...m,
      status: safeString(m.status, "OPEN"),
      category: safeString(m.category, "C"),
      attachments: normalizeCamoAttachments(m.attachments),
    }));
  },
  create: (m) =>
    apiCall("create", "MEL", {
      reg: m.reg || "",
      melRef: m.melRef || "",
      item: m.item || "",
      status: m.status || "OPEN",
      category: m.category || "C",
      openedDate: m.openedDate || "",
      dueDate: m.dueDate || "",
      closedDate: m.closedDate || "",
      restrictions: m.restrictions || "",
      remarks: m.remarks || "",
      deferredReason: m.deferredReason || "",
      reportedBy: m.reportedBy || "",
      closedBy: m.closedBy || "",
      attachments: JSON.stringify(m.attachments || []),
    }),
  update: (id, m) =>
    apiCall(
      "update",
      "MEL",
      {
        reg: m.reg || "",
        melRef: m.melRef || "",
        item: m.item || "",
        status: m.status || "OPEN",
        category: m.category || "C",
        openedDate: m.openedDate || "",
        dueDate: m.dueDate || "",
        closedDate: m.closedDate || "",
        restrictions: m.restrictions || "",
        remarks: m.remarks || "",
        deferredReason: m.deferredReason || "",
        reportedBy: m.reportedBy || "",
        closedBy: m.closedBy || "",
        attachments: JSON.stringify(m.attachments || []),
      },
      id
    ),
  remove: (id) => apiCall("delete", "MEL", {}, id),
};

/* ═══════════════════════════════════════════════════════════
 * PERMITS
 * ═══════════════════════════════════════════════════════════ */
export const permitTemplatesAPI = {
  list: async () => {
    const list = await apiRead("PermitTemplates");
    return list.map((t) => ({
      ...t,
      fields: safeArray(t.fields),
      flightFields: safeArray(t.flightFields),
      attachments: normalizeCamoAttachments(t.attachments),
    }));
  },
  create: (t) =>
    apiCall("create", "PermitTemplates", {
      country: t.country || "",
      name: t.name || "",
      permitType: t.permitType || "OVERFLIGHT",
      fields: JSON.stringify(t.fields || []),
      flightFields: JSON.stringify(t.flightFields || []),
      attachments: JSON.stringify(t.attachments || []),
      notes: t.notes || "",
    }),
  update: (id, t) =>
    apiCall(
      "update",
      "PermitTemplates",
      {
        country: t.country || "",
        name: t.name || "",
        permitType: t.permitType || "OVERFLIGHT",
        fields: JSON.stringify(t.fields || []),
        flightFields: JSON.stringify(t.flightFields || []),
        attachments: JSON.stringify(t.attachments || []),
        notes: t.notes || "",
      },
      id
    ),
  remove: (id) => apiCall("delete", "PermitTemplates", {}, id),
};

export const flightPermitsAPI = {
  list: async () => {
    const list = await apiRead("FlightPermits");
    return list.map((p) => ({
      ...p,
      customFields: safeObject(p.customFields) || {},
      attachments: normalizeCamoAttachments(p.attachments),
      status: safeString(p.status, "DRAFT"),
    }));
  },
  listByFlight: async (flightId) => {
    const all = await flightPermitsAPI.list();
    return all.filter((p) => String(p.flightId) === String(flightId));
  },
  create: (p) =>
    apiCall("create", "FlightPermits", {
      flightId: p.flightId || "",
      country: p.country || "",
      permitType: p.permitType || "",
      permitNo: p.permitNo || "",
      issuedDate: p.issuedDate || "",
      expiryDate: p.expiryDate || "",
      issuedBy: p.issuedBy || "",
      customFields: JSON.stringify(p.customFields || {}),
      attachments: JSON.stringify(p.attachments || []),
      status: p.status || "DRAFT",
      notes: p.notes || "",
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      updatedBy: p.updatedBy || "",
    }),
  update: (id, p) =>
    apiCall(
      "update",
      "FlightPermits",
      {
        flightId: p.flightId || "",
        country: p.country || "",
        permitType: p.permitType || "",
        permitNo: p.permitNo || "",
        issuedDate: p.issuedDate || "",
        expiryDate: p.expiryDate || "",
        issuedBy: p.issuedBy || "",
        customFields: JSON.stringify(p.customFields || {}),
        attachments: JSON.stringify(p.attachments || []),
        status: p.status || "DRAFT",
        notes: p.notes || "",
        updatedAt: new Date().toISOString(),
        updatedBy: p.updatedBy || "",
      },
      id
    ),
  remove: (id) => apiCall("delete", "FlightPermits", {}, id),
};

/* ═══════════════════════════════════════════════════════════
 * CATERING
 * ═══════════════════════════════════════════════════════════ */
export const cateringTemplatesAPI = {
  list: async () => {
    const list = await apiRead("CateringTemplates");
    return list.map((t) => ({
      ...t,
      items: normalizeMenuItems(t.items),
      mealType: safeString(t.mealType, "LUNCH"),
    }));
  },
  create: (t) =>
    apiCall("create", "CateringTemplates", {
      name: t.name || "",
      mealType: t.mealType || "LUNCH",
      items: JSON.stringify(t.items || []),
      notes: t.notes || "",
    }),
  update: (id, t) =>
    apiCall(
      "update",
      "CateringTemplates",
      {
        name: t.name || "",
        mealType: t.mealType || "LUNCH",
        items: JSON.stringify(t.items || []),
        notes: t.notes || "",
      },
      id
    ),
  remove: (id) => apiCall("delete", "CateringTemplates", {}, id),
};

export const cateringOrdersAPI = {
  list: async () => {
    const list = await apiRead("CateringOrders");
    return list.map((o) => ({
      ...o,
      items: normalizeMenuItems(o.items),
      attachments: normalizeCamoAttachments(o.attachments),
      paxCount: safeNumber(o.paxCount, 0),
      crewCount: safeNumber(o.crewCount, 0),
      status: safeString(o.status, "PENDING"),
    }));
  },
  create: (o) =>
    apiCall("create", "CateringOrders", {
      flightId: o.flightId || "",
      flightNo: o.flightNo || "",
      date: o.date || "",
      templateId: o.templateId || "",
      templateName: o.templateName || "",
      mealType: o.mealType || "LUNCH",
      paxCount: o.paxCount || 0,
      crewCount: o.crewCount || 0,
      items: JSON.stringify(o.items || []),
      specialMeals: o.specialMeals || "",
      status: o.status || "PENDING",
      notes: o.notes || "",
      attachments: JSON.stringify(o.attachments || []),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      updatedBy: o.updatedBy || "",
    }),
  update: (id, o) =>
    apiCall(
      "update",
      "CateringOrders",
      {
        flightId: o.flightId || "",
        flightNo: o.flightNo || "",
        date: o.date || "",
        templateId: o.templateId || "",
        templateName: o.templateName || "",
        mealType: o.mealType || "LUNCH",
        paxCount: o.paxCount || 0,
        crewCount: o.crewCount || 0,
        items: JSON.stringify(o.items || []),
        specialMeals: o.specialMeals || "",
        status: o.status || "PENDING",
        notes: o.notes || "",
        attachments: JSON.stringify(o.attachments || []),
        updatedAt: new Date().toISOString(),
        updatedBy: o.updatedBy || "",
      },
      id
    ),
  remove: (id) => apiCall("delete", "CateringOrders", {}, id),
};

/* ═══════════════════════════════════════════════════════════
 * FILES
 * ═══════════════════════════════════════════════════════════ */
export async function uploadFile(file, folder = "general") {
  if (!file) throw new Error("لم يتم اختيار ملف");
  if (file.size === 0) throw new Error("الملف فارغ");
  if (file.size > 10 * 1024 * 1024) throw new Error("حجم الملف يتجاوز 10 MB");

  const base64 = await new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const result = reader.result;
      if (!result || typeof result !== "string")
        return reject(new Error("FileReader result invalid"));
      const parts = result.split(",");
      if (parts.length < 2 || !parts[1])
        return reject(new Error("Cannot extract base64"));
      resolve(parts[1]);
    };
    reader.onerror = () => reject(new Error("FileReader failed"));
    reader.readAsDataURL(file);
  });

  const payload = JSON.stringify({
    action: "upload",
    fileName: file.name || "file",
    mimeType: file.type || "application/octet-stream",
    base64,
    folder,
  });

  const body = "payload=" + encodeURIComponent(payload);

  const res = await fetch(API_URL, {
    method: "POST",
    body,
    headers: {
      "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8",
    },
    redirect: "follow",
  });

  const text = await res.text();
  if (text.trim().startsWith("<")) {
    const m = text.match(/<title>(.*?)<\/title>/i);
    throw new Error("Apps Script error: " + (m ? m[1] : "HTML"));
  }

  let result;
  try {
    result = JSON.parse(text);
  } catch {
    throw new Error("Non-JSON: " + text.substring(0, 200));
  }
  if (!result.ok) throw new Error(result.error || "Upload failed");
  return result.data;
}

export async function deleteFile(filePath) {
  if (!filePath) return { ok: true };
  return apiCall("deleteFile", null, { filePath });
}

/* ═══════════════════════════════════════════════════════════
 * EMAIL
 * ═══════════════════════════════════════════════════════════ */
export async function sendEmail({ to, subject, body }) {
  return apiCall("sendEmail", null, { to, subject, body });
}

export async function sendFlightEmail(flight) {
  return apiCall("sendFlightEmail", null, { flight });
}

export async function checkExpiryAlerts() {
  return apiCall("checkExpiry", null, {});
}
