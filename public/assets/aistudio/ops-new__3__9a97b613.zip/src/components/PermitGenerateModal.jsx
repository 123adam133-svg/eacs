/* ═══════════════════════════════════════════════════════════
 * PERMIT GENERATE MODAL — v2.1
 * يملأ الحقول تلقائياً من الرحلة + يعبئ PDF المرفق
 * + Print HTML (Libya Flight Permission + Morocco + Generic)
 * ═══════════════════════════════════════════════════════════ */
import React, { useState, useMemo } from "react";
import {
  X,
  Save,
  Plane,
  FileText,
  Download,
  Eye,
  Loader2,
  Printer,
} from "lucide-react";
import { Field } from "./ui/Field";
import { Input } from "./ui/Input";
import { Select } from "./ui/Select";
import { fillPermitPDF, downloadPDF, openPDF } from "../utils/pdfFiller";
import { PermitHTMLPreview } from "./PermitHTMLPreview";

export function PermitGenerateModal({
  template,
  flight,
  crew = [],
  settings = {},
  user,
  onClose,
  onSave,
}) {
  /* ═══ الحقول الافتراضية من الرحلة ═══ */
  const autoFilled = useMemo(
    () => ({
      flightNo: flight?.flightNo || "",
      aircraft: flight?.acft || "",
      departure: flight?.dep || "",
      arrival: flight?.arr || "",
      route: flight?.route || `${flight?.dep || ""}/${flight?.arr || ""}`,
      date: flight?.std ? String(flight.std).slice(0, 10) : "",
      std: flight?.std ? String(flight.std).slice(11, 16) : "",
      sta: flight?.sta ? String(flight.sta).slice(11, 16) : "",
      crew: (flight?.crewSlots || [])
        .map((s) => {
          const m = crew.find((c) => String(c.id) === String(s.crewId));
          return m ? `${s.position}: ${m.fullName}` : null;
        })
        .filter(Boolean)
        .join(", "),
    }),
    [flight, crew]
  );

  /* ═══ الحقول اليدوية ═══ */
  const [manual, setManual] = useState({
    permitNo: "",
    issuedDate: new Date().toISOString().slice(0, 10),
    expiryDate: flight?.std ? String(flight.std).slice(0, 10) : "",
    issuedBy: template?.name || "",
    notes: "",
    status: "DRAFT",
  });

  const [customFields, setCustomFields] = useState(() => {
    const init = {};
    (template?.fields || []).forEach((f) => {
      if (
        !["permitNo", "issuedDate", "expiryDate", "issuedBy"].includes(f.key)
      ) {
        init[f.key] = "";
      }
    });
    return init;
  });

  const [saving, setSaving] = useState(false);
  const [generatingPdf, setGeneratingPdf] = useState(false);

  /* ⭐ حالة عرض PermitHTMLPreview */
  const [showPreview, setShowPreview] = useState(false);

  /* ═══ التحقق من PDF ═══ */
  const pdfAttachment = useMemo(
    () =>
      (template?.attachments || []).find((a) => a.type === "application/pdf"),
    [template]
  );

  const hasPdfFields = useMemo(
    () => Array.isArray(template?.fields) && template.fields.length > 0,
    [template]
  );

  const canFillPdf = !!pdfAttachment && hasPdfFields;

  /* ═══ الحفظ ═══ */
  const handleSave = async () => {
    if (!manual.permitNo) return alert("⚠️ أدخل رقم التصريح");
    setSaving(true);
    try {
      await onSave({
        templateId: template?.id || "",
        permitType: template?.permitType || "OVERFLIGHT",
        country: template?.country || "",
        ...manual,
        customFields: {
          ...autoFilled,
          ...customFields,
        },
      });
    } finally {
      setSaving(false);
    }
  };

  /* ═══ تجهيز البيانات للتعبئة ═══ */
  const buildFillData = () => ({
    ...autoFilled,
    ...manual,
    ...customFields,
  });

  /* ═══ تعبئة PDF ═══ */
  const handleFillPDF = async (mode = "download") => {
    if (!canFillPdf) {
      return alert(
        "⚠️ لا يوجد PDF مرفق أو لا توجد حقول معرّفة. استخدم Field Mapper في المكتبة."
      );
    }

    setGeneratingPdf(true);
    try {
      const data = buildFillData();
      const pdfBytes = await fillPermitPDF(
        pdfAttachment.url,
        template.fields,
        data
      );

      if (mode === "download") {
        const fileName = `${template.country}-${
          manual.permitNo || "permit"
        }.pdf`;
        downloadPDF(pdfBytes, fileName);
        alert("✅ تم تحميل PDF معبأ");
      } else {
        openPDF(pdfBytes);
      }
    } catch (err) {
      console.error("PDF fill error:", err);
      alert("❌ فشل توليد PDF: " + err.message);
    } finally {
      setGeneratingPdf(false);
    }
  };

  /* ═══ Render Custom Field ═══ */
  const renderField = (field) => {
    if (field.type === "date") {
      return (
        <Input
          type="date"
          value={customFields[field.key] || ""}
          onChange={(e) =>
            setCustomFields({ ...customFields, [field.key]: e.target.value })
          }
        />
      );
    }
    if (field.type === "number") {
      return (
        <Input
          type="number"
          value={customFields[field.key] || ""}
          onChange={(e) =>
            setCustomFields({ ...customFields, [field.key]: e.target.value })
          }
        />
      );
    }
    if (field.type === "textarea") {
      return (
        <textarea
          value={customFields[field.key] || ""}
          onChange={(e) =>
            setCustomFields({ ...customFields, [field.key]: e.target.value })
          }
          rows="2"
          className="w-full px-3 py-2 rounded-lg text-sm border outline-none"
          style={{
            borderColor: "var(--border-default)",
            color: "var(--text-primary)",
            backgroundColor: "var(--bg-app)",
          }}
        />
      );
    }
    return (
      <Input
        value={customFields[field.key] || ""}
        onChange={(e) =>
          setCustomFields({ ...customFields, [field.key]: e.target.value })
        }
      />
    );
  };

  /* ═══ Permit Object للتمرير إلى PermitHTMLPreview ═══ */
  const previewPermit = {
    ...manual,
    ...autoFilled,
    ...customFields,
  };

  return (
    <>
      <div
        className="fixed inset-0 z-[85] flex items-center justify-center p-4"
        style={{ backgroundColor: "rgba(0,0,0,0.75)" }}
        onClick={onClose}
      >
        <div
          className="bg-white dark:bg-slate-800 rounded-2xl w-full max-w-4xl max-h-[95vh] flex flex-col"
          onClick={(e) => e.stopPropagation()}
        >
          {/* ═══ HEADER ═══ */}
          <div
            className="flex justify-between items-center p-4 border-b"
            style={{ borderColor: "var(--border-default)" }}
          >
            <div>
              <h2
                className="text-lg font-bold flex items-center gap-2"
                style={{ color: "var(--text-primary)" }}
              >
                <FileText
                  className="w-5 h-5"
                  style={{ color: "var(--brand-primary)" }}
                />
                Generate Permit — {template?.country}
              </h2>
              <p className="text-xs" style={{ color: "var(--text-muted)" }}>
                {template?.name} · {flight?.flightNo}
              </p>
            </div>
            <button
              onClick={onClose}
              className="p-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-700"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* ═══ BODY ═══ */}
          <div className="flex-1 overflow-y-auto p-4 space-y-4">
            {/* ═══ Auto-filled from Flight ═══ */}
            <div className="p-3 rounded-lg bg-emerald-500/10 border border-emerald-500/30">
              <h4
                className="text-sm font-bold mb-3 flex items-center gap-2"
                style={{ color: "var(--text-primary)" }}
              >
                <Plane className="w-4 h-4 text-emerald-500" />
                Auto-filled from Flight
              </h4>
              <div className="grid md:grid-cols-2 gap-3 text-xs">
                <div
                  className="p-2 rounded"
                  style={{ backgroundColor: "var(--bg-card)" }}
                >
                  <div style={{ color: "var(--text-muted)" }}>Flight No</div>
                  <div
                    className="font-bold font-mono"
                    style={{ color: "var(--text-primary)" }}
                  >
                    {autoFilled.flightNo || "—"}
                  </div>
                </div>
                <div
                  className="p-2 rounded"
                  style={{ backgroundColor: "var(--bg-card)" }}
                >
                  <div style={{ color: "var(--text-muted)" }}>Aircraft</div>
                  <div
                    className="font-bold font-mono"
                    style={{ color: "var(--text-primary)" }}
                  >
                    {autoFilled.aircraft || "—"}
                  </div>
                </div>
                <div
                  className="p-2 rounded"
                  style={{ backgroundColor: "var(--bg-card)" }}
                >
                  <div style={{ color: "var(--text-muted)" }}>Route</div>
                  <div
                    className="font-bold font-mono"
                    style={{ color: "var(--text-primary)" }}
                  >
                    {autoFilled.departure} → {autoFilled.arrival}
                  </div>
                </div>
                <div
                  className="p-2 rounded"
                  style={{ backgroundColor: "var(--bg-card)" }}
                >
                  <div style={{ color: "var(--text-muted)" }}>Date</div>
                  <div
                    className="font-bold"
                    style={{ color: "var(--text-primary)" }}
                  >
                    {autoFilled.date || "—"}
                  </div>
                </div>
                <div
                  className="p-2 rounded"
                  style={{ backgroundColor: "var(--bg-card)" }}
                >
                  <div style={{ color: "var(--text-muted)" }}>STD / STA</div>
                  <div
                    className="font-bold font-mono"
                    style={{ color: "var(--text-primary)" }}
                  >
                    {autoFilled.std || "—"} / {autoFilled.sta || "—"} UTC
                  </div>
                </div>
                <div
                  className="p-2 rounded"
                  style={{ backgroundColor: "var(--bg-card)" }}
                >
                  <div style={{ color: "var(--text-muted)" }}>Crew</div>
                  <div
                    className="font-bold text-[10px]"
                    style={{ color: "var(--text-primary)" }}
                  >
                    {autoFilled.crew || "—"}
                  </div>
                </div>
              </div>
            </div>

            {/* ═══ Manual Fields ═══ */}
            <div className="p-3 rounded-lg bg-sky-500/10 border border-sky-500/30">
              <h4
                className="text-sm font-bold mb-3 flex items-center gap-2"
                style={{ color: "var(--text-primary)" }}
              >
                <FileText className="w-4 h-4 text-sky-500" />
                Permit Data (Manual)
              </h4>
              <div className="grid md:grid-cols-2 gap-3">
                <Field label="Permit No *">
                  <Input
                    value={manual.permitNo}
                    onChange={(e) =>
                      setManual({ ...manual, permitNo: e.target.value })
                    }
                    placeholder="LBY-2026-001"
                  />
                </Field>
                <Field label="Status">
                  <Select
                    value={manual.status}
                    onChange={(e) =>
                      setManual({ ...manual, status: e.target.value })
                    }
                  >
                    <option value="DRAFT">DRAFT</option>
                    <option value="PENDING">PENDING</option>
                    <option value="FINAL">FINAL</option>
                    <option value="ACTIVE">ACTIVE</option>
                  </Select>
                </Field>
                <Field label="Issued Date">
                  <Input
                    type="date"
                    value={manual.issuedDate}
                    onChange={(e) =>
                      setManual({ ...manual, issuedDate: e.target.value })
                    }
                  />
                </Field>
                <Field label="Expiry Date">
                  <Input
                    type="date"
                    value={manual.expiryDate}
                    onChange={(e) =>
                      setManual({ ...manual, expiryDate: e.target.value })
                    }
                  />
                </Field>
                <Field label="Issued By">
                  <Input
                    value={manual.issuedBy}
                    onChange={(e) =>
                      setManual({ ...manual, issuedBy: e.target.value })
                    }
                    placeholder="Libyan CAA"
                  />
                </Field>
              </div>
            </div>

            {/* ═══ Custom Fields ═══ */}
            {template?.fields && template.fields.length > 0 && (
              <div className="p-3 rounded-lg bg-purple-500/10 border border-purple-500/30">
                <h4
                  className="text-sm font-bold mb-3"
                  style={{ color: "var(--text-primary)" }}
                >
                  📋 {template.name} — Additional Fields
                </h4>
                <div className="grid md:grid-cols-2 gap-3">
                  {template.fields
                    .filter(
                      (f) =>
                        ![
                          "permitNo",
                          "issuedDate",
                          "expiryDate",
                          "issuedBy",
                        ].includes(f.key)
                    )
                    .map((f) => (
                      <Field
                        key={f.key}
                        label={`${f.label}${f.required ? " *" : ""}`}
                      >
                        {renderField(f)}
                      </Field>
                    ))}
                </div>
              </div>
            )}

            {/* ═══ Notes ═══ */}
            <Field label="Notes">
              <textarea
                value={manual.notes}
                onChange={(e) =>
                  setManual({ ...manual, notes: e.target.value })
                }
                rows="2"
                className="w-full px-3 py-2 rounded-lg text-sm border outline-none"
                style={{
                  borderColor: "var(--border-default)",
                  color: "var(--text-primary)",
                  backgroundColor: "var(--bg-app)",
                }}
                placeholder="Additional notes..."
              />
            </Field>

            {/* ═══════════════════════════════════════════════════════
             * ⭐ PDF TEMPLATE — Fill & Download
             * ═══════════════════════════════════════════════════════ */}
            {canFillPdf && (
              <div className="p-3 rounded-lg bg-indigo-500/10 border-2 border-indigo-500/40">
                <h4
                  className="text-sm font-bold mb-2 flex items-center gap-2"
                  style={{ color: "var(--text-primary)" }}
                >
                  <FileText className="w-4 h-4 text-indigo-500" />
                  📄 PDF Template — تعبئة النموذج المرفق
                </h4>
                <p
                  className="text-[11px] mb-3"
                  style={{ color: "var(--text-muted)" }}
                >
                  سيتم تعبئة <b>{template.fields.length} حقل</b> على النموذج
                  المرفق: <b>{pdfAttachment.name}</b>
                </p>

                <div className="mb-3 flex flex-wrap gap-1">
                  {template.fields.slice(0, 8).map((f) => (
                    <span
                      key={f.key}
                      className="px-1.5 py-0.5 rounded bg-indigo-500/20 text-indigo-600 text-[9px] font-mono"
                    >
                      {f.key}
                    </span>
                  ))}
                  {template.fields.length > 8 && (
                    <span className="px-1.5 py-0.5 rounded bg-indigo-500/20 text-indigo-600 text-[9px]">
                      +{template.fields.length - 8}
                    </span>
                  )}
                </div>

                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={() => handleFillPDF("preview")}
                    disabled={generatingPdf}
                    className="flex-1 px-3 py-2.5 rounded-lg text-xs font-bold bg-indigo-500/15 text-indigo-600 hover:bg-indigo-500/25 disabled:opacity-50 flex items-center justify-center gap-2"
                  >
                    {generatingPdf ? (
                      <Loader2 className="w-4 h-4 animate-spin" />
                    ) : (
                      <Eye className="w-4 h-4" />
                    )}
                    معاينة PDF
                  </button>
                  <button
                    type="button"
                    onClick={() => handleFillPDF("download")}
                    disabled={generatingPdf}
                    className="flex-1 px-3 py-2.5 rounded-lg text-xs font-bold bg-indigo-600 text-white hover:bg-indigo-700 disabled:opacity-50 flex items-center justify-center gap-2"
                  >
                    {generatingPdf ? (
                      <Loader2 className="w-4 h-4 animate-spin" />
                    ) : (
                      <Download className="w-4 h-4" />
                    )}
                    تحميل PDF معبأ
                  </button>
                </div>
              </div>
            )}

            {/* ═══ Warning if no PDF ═══ */}
            {!canFillPdf && pdfAttachment && !hasPdfFields && (
              <div className="p-3 rounded-lg bg-amber-500/10 border border-amber-500/30">
                <div className="text-xs font-bold text-amber-600 mb-1">
                  ⚠️ PDF مرفق لكن بدون حقول معرّفة
                </div>
                <div
                  className="text-[11px]"
                  style={{ color: "var(--text-muted)" }}
                >
                  اذهب إلى Permits Library → Edit → اضغط "Map" لتحديد الحقول
                </div>
              </div>
            )}

            {/* ═══════════════════════════════════════════════════════
             * ⭐ HTML PRINT — معاينة النموذج الليبي/المغربي
             * ═══════════════════════════════════════════════════════ */}
            <div className="p-3 rounded-lg bg-emerald-500/10 border-2 border-emerald-500/40">
              <h4
                className="text-sm font-bold mb-2 flex items-center gap-2"
                style={{ color: "var(--text-primary)" }}
              >
                <Printer className="w-4 h-4 text-emerald-500" />
                🖨️ Print HTML — معاينة النموذج الرسمي
              </h4>
              <p
                className="text-[11px] mb-3"
                style={{ color: "var(--text-muted)" }}
              >
                يعرض النموذج الرسمي (Libya Flight Permission / Morocco Landing)
                جاهزاً للطباعة
              </p>
              <button
                type="button"
                onClick={() => setShowPreview(true)}
                className="w-full px-4 py-3 rounded-lg text-sm font-bold text-white flex items-center justify-center gap-2 hover:opacity-90 transition"
                style={{
                  background: "linear-gradient(135deg, #10b981, #059669)",
                  boxShadow: "0 4px 12px rgba(16, 185, 129, 0.3)",
                }}
              >
                <Printer className="w-5 h-5" />
                معاينة وطباعة النموذج
              </button>
            </div>
          </div>

          {/* ═══ FOOTER ═══ */}
          <div
            className="p-4 border-t flex justify-end gap-2"
            style={{ borderColor: "var(--border-default)" }}
          >
            <button
              onClick={onClose}
              className="px-4 py-2 rounded-lg text-sm font-bold border"
              style={{
                borderColor: "var(--border-default)",
                color: "var(--text-muted)",
              }}
            >
              Cancel
            </button>
            <button
              onClick={handleSave}
              disabled={saving}
              className="px-4 py-2 rounded-lg text-sm font-bold text-white flex items-center gap-2 disabled:opacity-50"
              style={{ background: "var(--brand-gradient)" }}
            >
              <Save className="w-4 h-4" />{" "}
              {saving ? "Saving..." : "Save Permit"}
            </button>
          </div>
        </div>
      </div>

      {/* ⭐ PermitHTMLPreview — يفتح عند الضغط على "Print HTML" */}
      {showPreview && (
        <PermitHTMLPreview
          template={template}
          flight={flight}
          crew={crew}
          settings={settings}
          permit={previewPermit}
          user={user}
          onClose={() => setShowPreview(false)}
        />
      )}
    </>
  );
}

export default PermitGenerateModal;
