/* ═══════════════════════════════════════════════════════════
 * AEROOPS — Main App v13.0
 * LiveClock + UserProfile + CAMO/Permits/Catering + SideNav
 * ═══════════════════════════════════════════════════════════ */
import React, { useState, useEffect, useRef } from "react";
import {
  Plane,
  LogOut,
  Moon,
  Sun,
  Menu,
  X,
  ChevronRight,
  ChevronDown,
  MoreHorizontal,
  BookOpen,
  User,
  ShieldCheck,
  FileSignature,
  UtensilsCrossed,
} from "lucide-react";

/* ═══════ API ═══════ */
import {
  usersAPI,
  crewAPI,
  fleetAPI,
  flightsAPI,
  settingsAPI,
  rolesAPI,
  auditAPI,
  rosterAPI,
  standbyAPI,
  leaveAPI,
  trainingAPI,
  loginHistoryAPI,
} from "./api";

/* ═══════ Config ═══════ */
import { setGlobalRoles, can as checkPerm } from "./config/permissions";
import { getGlobalTheme, DEFAULT_GLOBAL_THEME } from "./config/constants";

/* ═══════ Contexts ═══════ */
import { LangProvider, useT } from "./contexts/LangContext";
import { AuthProvider, useAuth } from "./contexts/AuthContext";

/* ═══════ Hooks ═══════ */
import { useLocalStorage } from "./hooks/useLocalStorage";

/* ═══════ Utils ═══════ */
import { logSafe, logLoginSafe } from "./utils/audit";
import { unlockAudio } from "./utils/sounds";

/* ═══════ UI Components ═══════ */
import { SyncBadge } from "./components/ui/SyncBadge";
import { LiveClock } from "./components/ui/LiveClock";
import { AlertsPanel } from "./components/AlertsPanel";
import { Login } from "./components/Login";
import { GenDecModal } from "./components/GenDecModal";
import { SoundNotifications } from "./components/SoundNotifications";
import { UserProfileModal } from "./components/UserProfileModal";

/* ═══════ Modules ═══════ */
import { Dashboard } from "./modules/Dashboard";
import { ScheduleBoard } from "./modules/ScheduleBoard";
import { FTLModule } from "./modules/FTLModule";
import { ReportsModule } from "./modules/ReportsModule";
import { Crew } from "./modules/Crew";
import { Fleet } from "./modules/Fleet";
import { SettingsModule } from "./modules/SettingsModule";
import { RosterModule } from "./modules/RosterModule";
import { StandbyModule } from "./modules/StandbyModule";
import { LeaveModule } from "./modules/LeaveModule";
import { TrainingModule } from "./modules/TrainingModule";
import { FlightFollowingModule } from "./modules/FlightFollowingModule";
import { ChartsModule } from "./modules/ChartsModule";
import { ManualsModule } from "./modules/ManualsModule";
import { CAMOModule } from "./modules/CAMOModule";
import { PermitsModule } from "./modules/PermitsModule";
import { CateringModule } from "./modules/CateringModule";
import { CrewPortal } from "./modules/CrewPortal";

/* ═══════ Icons ═══════ */
import {
  LayoutDashboard,
  Calendar,
  Clock,
  BarChart3,
  CalendarDays,
  Zap,
  Plane as PlaneIcon,
  GraduationCap,
  Navigation,
  Settings,
  Users,
} from "lucide-react";
import { CrewTableIcon } from "./crewIcons";

/* ═══════════════════════════════════════════════════════════
 * REPORTS SUBTABS
 * ═══════════════════════════════════════════════════════════ */
const REPORTS_SUBTABS = [
  {
    id: "crewHours",
    icon: BarChart3,
    label_en: "Crew Hours",
    label_ar: "ساعات الطاقم",
  },
  {
    id: "fullReport",
    icon: Users,
    label_en: "Full Report",
    label_ar: "تقرير شامل",
  },
  {
    id: "completedFlights",
    icon: Plane,
    label_en: "Completed Flights",
    label_ar: "الرحلات المنفذة",
  },
  {
    id: "dutyTime",
    icon: Clock,
    label_en: "Duty Time",
    label_ar: "ساعات الخدمة",
  },
];

/* ═══════════════════════════════════════════════════════════
 * ALL TABS
 * ═══════════════════════════════════════════════════════════ */
const ALL_TABS_CONFIG = [
  {
    id: "dashboard",
    icon: LayoutDashboard,
    label_en: "Dashboard",
    label_ar: "الرئيسية",
    perm: "schedule.view",
    position: "primary",
  },
  {
    id: "schedule",
    icon: Calendar,
    label_en: "Schedule",
    label_ar: "الجدول",
    perm: "schedule.view",
    position: "primary",
  },
  {
    id: "ftl",
    icon: Clock,
    label_en: "FTL",
    label_ar: "ساعات الطيران",
    perm: "ftl.view",
    position: "primary",
  },
  {
    id: "reports",
    icon: BarChart3,
    label_en: "Reports",
    label_ar: "التقارير",
    perm: "reports.view",
    position: "primary",
    hasSubTabs: true,
  },
  {
    id: "roster",
    icon: CalendarDays,
    label_en: "Roster",
    label_ar: "الجدول الشهري",
    perm: "roster.view",
    position: "more",
  },
  {
    id: "standby",
    icon: Zap,
    label_en: "Standby",
    label_ar: "الاحتياطي",
    perm: "standby.view",
    position: "more",
  },
  {
    id: "leave",
    icon: PlaneIcon,
    label_en: "Leave",
    label_ar: "الإجازات",
    perm: "leave.view",
    position: "more",
  },
  {
    id: "training",
    icon: GraduationCap,
    label_en: "Training",
    label_ar: "التدريب",
    perm: "training.view",
    position: "more",
  },
  {
    id: "tracking",
    icon: Navigation,
    label_en: "Following",
    label_ar: "متابعة الرحلات",
    perm: "tracking.view",
    position: "more",
  },
  {
    id: "charts",
    icon: BarChart3,
    label_en: "Charts",
    label_ar: "الرسوم",
    perm: "charts.view",
    position: "more",
  },
  {
    id: "fleet",
    icon: Plane,
    label_en: "Fleet",
    label_ar: "الأسطول",
    perm: "fleet.view",
    position: "more",
  },
  {
    id: "crew",
    icon: CrewTableIcon,
    label_en: "Crew",
    label_ar: "الطاقم",
    perm: "crew.view",
    position: "more",
  },
  {
    id: "camo",
    icon: ShieldCheck,
    label_en: "CAMO",
    label_ar: "إدارة الصلاحية",
    perm: "camo.view",
    position: "more",
  },
  {
    id: "permits",
    icon: FileSignature,
    label_en: "Permits",
    label_ar: "التصاريح",
    perm: "permits.view",
    position: "more",
  },
  {
    id: "catering",
    icon: UtensilsCrossed,
    label_en: "Catering",
    label_ar: "التموين",
    perm: "catering.view",
    position: "more",
  },
  {
    id: "manuals",
    icon: BookOpen,
    label_en: "Manuals",
    label_ar: "الأدلة والمراجع",
    perm: "schedule.view",
    position: "more",
  },
  {
    id: "settings",
    icon: Settings,
    label_en: "Settings",
    label_ar: "الإعدادات",
    perm: "settings.view",
    position: "more",
  },
];

/* ═══════════════════════════════════════════════════════════
 * APP INNER
 * ═══════════════════════════════════════════════════════════ */
function AppInner() {
  const t = useT();
  const { user, setUser, logout: authLogout } = useAuth();

  const [lang, setLang] = useLocalStorage("aeroops.lang", "en");
  const [tab, setTab] = useLocalStorage("aeroops.tab", "dashboard");
  const [darkMode, setDarkMode] = useLocalStorage("aeroops.darkMode", false);

  const [users, setUsers] = useState([]);
  const [crew, setCrew] = useState([]);
  const [fleet, setFleet] = useState([]);
  const [flights, setFlights] = useState([]);
  const [roles, setRoles] = useState([]);
  const [roster, setRoster] = useState([]);
  const [standby, setStandby] = useState([]);
  const [leave, setLeave] = useState([]);
  const [training, setTraining] = useState([]);
  const [auditLogs, setAuditLogs] = useState([]);
  const [loginHistory, setLoginHistory] = useState([]);

  const [settings, setSettings] = useState({
    id: null,
    companyName: "AeroOps",
    companyNameAr: "إيرو أوبس",
    operatorCode: "EACS",
    country: "",
    navLayout: "top",
    tabPreferences: null,
    logo: null,
    stamp: null,
    timeMode: "utc",
    globalTheme: DEFAULT_GLOBAL_THEME,
    portalTheme: DEFAULT_GLOBAL_THEME,
  });

  const [loading, setLoading] = useState(true);
  const [syncStatus, setSyncStatus] = useState("idle");
  const [genDec, setGenDec] = useState(null);
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [moreOpen, setMoreOpen] = useState(false);
  const moreRef = useRef(null);
  const [reportsOpen, setReportsOpen] = useState(false);
  const reportsRef = useRef(null);
  const [viewingProfile, setViewingProfile] = useState(null);

  /* ⭐ v13.0 — Nav Layout from settings + localStorage */
  const [navLayout, setNavLayout] = useState(() => {
    if (typeof window === "undefined") return "top";
    return localStorage.getItem("aeroops.navLayout") || "top";
  });

  /* ⭐ يستمع لتغيير الـ prefs من SettingsModule */
  useEffect(() => {
    const handler = () => {
      const saved = localStorage.getItem("aeroops.navLayout") || "top";
      setNavLayout(saved);
    };
    window.addEventListener("aeroops:prefsChanged", handler);
    return () => window.removeEventListener("aeroops:prefsChanged", handler);
  }, []);

  /* ⭐ sync من settings بعد التحميل */
  useEffect(() => {
    if (settings?.navLayout && settings.navLayout !== navLayout) {
      setNavLayout(settings.navLayout);
      localStorage.setItem("aeroops.navLayout", settings.navLayout);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [settings?.navLayout]);

  const isSideNav = navLayout === "side";

  useEffect(() => {
    document.documentElement.dir = t.dir;
    document.documentElement.lang = lang;
  }, [lang, t.dir]);

  useEffect(() => {
    if (darkMode) document.documentElement.classList.add("dark");
    else document.documentElement.classList.remove("dark");
  }, [darkMode]);

  useEffect(() => {
    const themeId = settings?.globalTheme || DEFAULT_GLOBAL_THEME;
    const theme = getGlobalTheme(themeId);
    const isDark = darkMode;
    const vars =
      isDark && Object.keys(theme.darkVars || {}).length > 0
        ? { ...theme.vars, ...theme.darkVars }
        : theme.vars;
    Object.entries(vars).forEach(([key, value]) => {
      document.documentElement.style.setProperty(key, value);
    });
    document.documentElement.setAttribute("data-theme", themeId);
  }, [settings?.globalTheme, darkMode]);

  useEffect(() => {
    setGlobalRoles(roles);
  }, [roles]);

  useEffect(() => {
    const handler = (e) => {
      if (moreRef.current && !moreRef.current.contains(e.target))
        setMoreOpen(false);
      if (reportsRef.current && !reportsRef.current.contains(e.target))
        setReportsOpen(false);
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);

  useEffect(() => {
    const handler = () => {
      unlockAudio();
      window.removeEventListener("click", handler);
      window.removeEventListener("touchstart", handler);
      window.removeEventListener("keydown", handler);
    };
    window.addEventListener("click", handler);
    window.addEventListener("touchstart", handler);
    window.addEventListener("keydown", handler);
    return () => {
      window.removeEventListener("click", handler);
      window.removeEventListener("touchstart", handler);
      window.removeEventListener("keydown", handler);
    };
  }, []);

  const loadData = async () => {
    setLoading(true);
    setSyncStatus("syncing");
    try {
      const [u, c, f, fl, s, r, ro, st, lv, tr, al, lh] = await Promise.all([
        usersAPI.list().catch(() => []),
        crewAPI.list().catch(() => []),
        fleetAPI.list().catch(() => []),
        flightsAPI.list().catch(() => []),
        settingsAPI.get().catch(() => null),
        rolesAPI.list().catch(() => []),
        rosterAPI.list().catch(() => []),
        standbyAPI.list().catch(() => []),
        leaveAPI.list().catch(() => []),
        trainingAPI.list().catch(() => []),
        auditAPI.list().catch(() => []),
        loginHistoryAPI.list().catch(() => []),
      ]);
      setUsers(u);
      setCrew(c);
      setFleet(f);
      setFlights(fl);
      if (s) setSettings(s);
      setRoles(r);
      setGlobalRoles(r);
      setRoster(ro);
      setStandby(st);
      setLeave(lv);
      setTraining(tr);
      setAuditLogs(al);
      setLoginHistory(lh);
      setSyncStatus("synced");
    } catch (e) {
      console.error("Load failed:", e);
      setSyncStatus("error");
    } finally {
      setLoading(false);
    }
  };

  const reloadFlights = async () => {
    try {
      const fl = await flightsAPI.list();
      setFlights(fl);
      return fl;
    } catch (e) {
      console.error("Reload flights failed:", e);
      throw e;
    }
  };

  useEffect(() => {
    loadData();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleLogin = (u) => {
    setUser(u);
  };

  const handleLogout = () => {
    if (user) {
      logLoginSafe(user, "LOGOUT", true);
      logSafe(user, "LOGOUT", "Auth", user.id, user.fullName, {});
    }
    if (typeof authLogout === "function") authLogout();
    else setUser(null);
  };

  if (!user) {
    return (
      <Login
        users={users}
        onLogin={handleLogin}
        settings={settings}
        loading={loading}
      />
    );
  }

  const prefs = (() => {
    if (
      settings.tabPreferences &&
      typeof settings.tabPreferences === "object" &&
      Object.keys(settings.tabPreferences).length > 0
    ) {
      return settings.tabPreferences;
    }
    try {
      const local = JSON.parse(
        localStorage.getItem("aeroops.tabPreferences") || "{}"
      );
      if (Object.keys(local).length > 0) return local;
    } catch {}
    return ALL_TABS_CONFIG.reduce((acc, t) => {
      acc[t.id] = t.position;
      return acc;
    }, {});
  })();

  const getTabsByPosition = (position) => {
    return ALL_TABS_CONFIG.filter((tab) => checkPerm(user, tab.perm)).filter(
      (tab) => (prefs[tab.id] || tab.position || "more") === position
    );
  };

  const primaryTabs = getTabsByPosition("primary");
  const moreTabs = getTabsByPosition("more");
  const hiddenTabs = getTabsByPosition("hidden");

  const isCrewMember = user?.role === "crewMember";
  const shouldShowCrewPortal =
    !!user?.crewId && (isCrewMember || checkPerm(user, "crew.portal"));

  const effectiveTab = shouldShowCrewPortal ? "dashboard" : tab;
  const baseTabId = effectiveTab.includes(".")
    ? effectiveTab.split(".")[0]
    : effectiveTab;

  const isReportsActive =
    effectiveTab === "reports" || effectiveTab.startsWith("reports.");

  const goTab = (id) => {
    setTab(id);
    setMoreOpen(false);
    setReportsOpen(false);
    setDrawerOpen(false);
  };

  const displayName = user.fullName || user.username || "User";
  const operatorCode = (settings.operatorCode || "EACS").toUpperCase();

  /* ═══ هل نعرض Header / SideNav? ═══ */
  const showChrome = !(shouldShowCrewPortal && effectiveTab === "dashboard");

  /* ═══ محتوى الـ main ═══ */
  const renderMain = () => (
    <div className={shouldShowCrewPortal ? "pb-0" : "p-2 md:p-3 pb-20 md:pb-3"}>
      {loading && users.length === 0 ? (
        <div
          className="flex flex-col items-center justify-center py-20"
          style={{ color: "var(--text-muted)" }}
        >
          <div
            className="w-10 h-10 border-4 border-t-transparent rounded-full animate-spin mb-4"
            style={{
              borderColor: "var(--brand-primary)",
              borderTopColor: "transparent",
            }}
          />
          <p>{t.loadingData}</p>
        </div>
      ) : (
        <>
          {shouldShowCrewPortal && !loading && crew.length > 0 && (
            <CrewPortal
              crew={crew}
              flights={flights}
              settings={settings}
              currentUser={user}
            />
          )}

          {!shouldShowCrewPortal &&
            baseTabId === "dashboard" &&
            (loading ? (
              <div className="flex justify-center items-center py-20">
                <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-[var(--brand-primary)]"></div>
              </div>
            ) : (
              <Dashboard
                flights={flights}
                crew={crew}
                fleet={fleet}
                users={users}
                roles={roles}
                leave={leave}
                roster={roster}
                standby={standby}
                training={training}
                setTab={goTab}
                loading={loading}
              />
            ))}

          {baseTabId === "schedule" && (
            <ScheduleBoard
              flights={flights}
              setFlights={setFlights}
              reloadFlights={reloadFlights}
              crew={crew}
              fleet={fleet}
              settings={settings}
              onGenDec={setGenDec}
              setSyncStatus={setSyncStatus}
            />
          )}
          {baseTabId === "ftl" && <FTLModule crew={crew} flights={flights} />}
          {baseTabId === "reports" && (
            <ReportsModule
              flights={flights}
              crew={crew}
              fleet={fleet}
              settings={settings}
              user={user}
              initialSubTab={
                tab.includes(".") ? tab.split(".")[1] : "crewHours"
              }
            />
          )}
          {baseTabId === "roster" && (
            <RosterModule
              crew={crew}
              roster={roster}
              setRoster={setRoster}
              setSyncStatus={setSyncStatus}
            />
          )}
          {baseTabId === "standby" && (
            <StandbyModule
              crew={crew}
              standby={standby}
              setStandby={setStandby}
              setSyncStatus={setSyncStatus}
            />
          )}
          {baseTabId === "leave" && (
            <LeaveModule
              crew={crew}
              leave={leave}
              setLeave={setLeave}
              setSyncStatus={setSyncStatus}
              currentUser={user}
            />
          )}
          {baseTabId === "training" && (
            <TrainingModule
              crew={crew}
              training={training}
              setTraining={setTraining}
              setSyncStatus={setSyncStatus}
            />
          )}
          {baseTabId === "tracking" && (
            <FlightFollowingModule flights={flights} fleet={fleet} />
          )}
          {baseTabId === "charts" && (
            <ChartsModule
              flights={flights}
              crew={crew}
              fleet={fleet}
              leave={leave}
            />
          )}
          {baseTabId === "fleet" && (
            <Fleet
              fleet={fleet}
              setFleet={setFleet}
              lang={lang}
              setSyncStatus={setSyncStatus}
            />
          )}
          {baseTabId === "crew" && (
            <Crew
              crew={crew}
              setCrew={setCrew}
              users={users}
              setUsers={setUsers}
              fleet={fleet}
              companyName={settings.companyName}
              setSyncStatus={setSyncStatus}
              settings={settings}
            />
          )}
          {baseTabId === "camo" && (
            <CAMOModule
              fleet={fleet}
              settings={settings}
              user={user}
              setSyncStatus={setSyncStatus}
            />
          )}
          {baseTabId === "permits" && (
            <PermitsModule
              flights={flights}
              fleet={fleet}
              settings={settings}
              user={user}
              setSyncStatus={setSyncStatus}
            />
          )}
          {baseTabId === "catering" && (
            <CateringModule
              flights={flights}
              settings={settings}
              user={user}
              setSyncStatus={setSyncStatus}
            />
          )}
          {baseTabId === "manuals" && (
            <ManualsModule
              settings={settings}
              companyName={settings.companyName}
              lang={lang}
            />
          )}
          {baseTabId === "settings" && (
            <SettingsModule
              settings={settings}
              setSettings={setSettings}
              lang={lang}
              setLang={setLang}
              users={users}
              setUsers={setUsers}
              roles={roles}
              setRoles={setRoles}
              loginHistory={loginHistory}
              setLoginHistory={setLoginHistory}
              auditLogs={auditLogs}
              setAuditLogs={setAuditLogs}
              crew={crew}
              setSyncStatus={setSyncStatus}
            />
          )}
        </>
      )}
    </div>
  );

  /* ═══ SideNav — يعمل فقط عند navLayout=side ═══ */
  const renderSideNav = () => {
    const allTabs = [...primaryTabs, ...moreTabs];
    return (
      <aside
        className="hidden md:flex fixed inset-y-0 start-0 z-40 w-64 flex-col shadow-xl border-e"
        style={{
          backgroundColor: "var(--bg-sidebar)",
          borderColor: "var(--border-default)",
        }}
      >
        {/* Logo + Company */}
        <div
          className="p-4 flex items-center gap-3 border-b flex-shrink-0"
          style={{ borderColor: "var(--border-default)" }}
        >
          {settings.logo ? (
            <img
              src={settings.logo}
              alt="logo"
              className="w-11 h-11 rounded-lg object-contain bg-white p-1"
            />
          ) : (
            <div
              className="w-11 h-11 rounded-lg flex items-center justify-center flex-shrink-0"
              style={{ background: "var(--brand-gradient)" }}
            >
              <Plane className="w-6 h-6 text-white" />
            </div>
          )}
          <div className="min-w-0 flex-1">
            <div
              className="font-black text-lg font-mono tracking-widest truncate"
              style={{ color: "var(--text-primary)" }}
            >
              {operatorCode}
            </div>
            <div
              className="text-[10px] truncate"
              style={{ color: "var(--text-muted)" }}
            >
              {lang === "ar" ? settings.companyNameAr : settings.companyName}
            </div>
          </div>
        </div>

        {/* Nav items */}
        <nav className="flex-1 overflow-y-auto p-2 space-y-0.5">
          {allTabs.map(({ id, icon: Icon, label_en, label_ar, hasSubTabs }) => {
            if (hasSubTabs) {
              return (
                <div key={id} className="mb-1">
                  <div
                    className="px-3 py-2 text-[10px] font-bold uppercase tracking-widest"
                    style={{ color: "var(--text-muted)" }}
                  >
                    {lang === "ar" ? label_ar : label_en}
                  </div>
                  {REPORTS_SUBTABS.map((subTab) => {
                    const SubIcon = subTab.icon;
                    const isSubActive = tab === `reports.${subTab.id}`;
                    return (
                      <button
                        key={subTab.id}
                        onClick={() => goTab(`reports.${subTab.id}`)}
                        className="w-full flex items-center gap-3 px-3 py-2 rounded-lg text-sm font-bold transition text-start"
                        style={
                          isSubActive
                            ? {
                                background: "var(--brand-gradient)",
                                color: "white",
                              }
                            : { color: "var(--text-muted)" }
                        }
                      >
                        <div
                          className="w-7 h-7 rounded-lg flex items-center justify-center flex-shrink-0"
                          style={{
                            backgroundColor: isSubActive
                              ? "rgba(255,255,255,0.2)"
                              : "var(--bg-app)",
                          }}
                        >
                          <SubIcon className="w-4 h-4" />
                        </div>
                        <span className="truncate">
                          {lang === "ar" ? subTab.label_ar : subTab.label_en}
                        </span>
                      </button>
                    );
                  })}
                </div>
              );
            }
            const isActive = tab === id;
            return (
              <button
                key={id}
                onClick={() => goTab(id)}
                className="w-full flex items-center gap-3 px-3 py-2 rounded-lg text-sm font-bold transition text-start"
                style={
                  isActive
                    ? { background: "var(--brand-gradient)", color: "white" }
                    : { color: "var(--text-muted)" }
                }
              >
                <div
                  className="w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0"
                  style={{
                    backgroundColor: isActive
                      ? "rgba(255,255,255,0.2)"
                      : "var(--bg-app)",
                  }}
                >
                  <Icon className="w-4 h-4" />
                </div>
                <span className="truncate">
                  {lang === "ar" ? label_ar : label_en}
                </span>
              </button>
            );
          })}
        </nav>

        {/* Footer — User + Clock + Actions */}
        <div
          className="p-3 border-t flex-shrink-0 space-y-2"
          style={{ borderColor: "var(--border-default)" }}
        >
          {/* LiveClock */}
          <div className="flex justify-center">
            <LiveClock />
          </div>

          {/* User row */}
          <button
            onClick={() => setViewingProfile(user)}
            className="w-full flex items-center gap-2 px-2 py-2 rounded-lg transition hover:bg-slate-100 dark:hover:bg-slate-700"
            title={lang === "ar" ? "عرض الملف الشخصي" : "View profile"}
          >
            <User
              className="w-4 h-4 flex-shrink-0"
              style={{ color: "var(--brand-primary)" }}
            />
            <span
              className="flex-1 text-xs font-bold text-start truncate"
              style={{ color: "var(--text-primary)" }}
            >
              {displayName}
            </span>
            <span
              className="px-1.5 py-0.5 rounded text-[10px] font-mono border"
              style={{
                backgroundColor: "var(--bg-card)",
                color: "var(--brand-primary)",
                borderColor: "var(--border-default)",
              }}
            >
              {operatorCode}
            </span>
          </button>

          {/* Actions */}
          <div className="flex items-center justify-between gap-1">
            <div className="flex items-center gap-1">
              <SyncBadge status={syncStatus} onRetry={loadData} />
              <AlertsPanel crew={crew} users={users} fleet={fleet} />
              <button
                onClick={() => setDarkMode(!darkMode)}
                className="p-1.5 rounded-lg transition"
                style={{
                  backgroundColor: "var(--bg-app)",
                  color: "var(--text-muted)",
                }}
              >
                {darkMode ? (
                  <Sun className="w-4 h-4" />
                ) : (
                  <Moon className="w-4 h-4" />
                )}
              </button>
            </div>
            <button
              onClick={handleLogout}
              className="p-1.5 rounded-lg bg-rose-500/15 text-rose-500 hover:bg-rose-500/25 transition"
              title="Logout"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        </div>
      </aside>
    );
  };

  /* ═══ Top Header (navLayout=top) ═══ */
  const renderTopHeader = () => (
    <header
      className="sticky top-0 z-40 shadow-md transition-colors duration-300"
      style={{
        backgroundColor: "var(--bg-sidebar)",
        borderBottom: "1px solid var(--border-default)",
      }}
    >
      {/* Top Status Bar */}
      <div
        className="px-4 py-1 flex items-center gap-3 border-b text-xs transition-colors duration-300 flex-wrap"
        style={{
          backgroundColor: "var(--bg-app)",
          borderColor: "var(--border-default)",
          color: "var(--text-muted)",
        }}
      >
        <div className="flex items-center gap-1.5 flex-shrink-0">
          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
          <span>System Online</span>
        </div>

        <span style={{ color: "var(--border-default)" }}>|</span>

        <button
          onClick={() => setViewingProfile(user)}
          className="flex items-center gap-1.5 flex-shrink-0 px-1.5 py-0.5 rounded-lg transition hover:bg-slate-100 dark:hover:bg-slate-700"
          title={lang === "ar" ? "عرض الملف الشخصي" : "View profile"}
        >
          <User
            className="w-3.5 h-3.5"
            style={{ color: "var(--brand-primary)" }}
          />
          <span className="font-bold" style={{ color: "var(--text-primary)" }}>
            {displayName}
          </span>
          <span
            className="px-1.5 py-0.5 rounded text-[10px] font-mono border"
            style={{
              backgroundColor: "var(--bg-card)",
              color: "var(--brand-primary)",
              borderColor: "var(--border-default)",
            }}
          >
            {operatorCode}
          </span>
        </button>

        <span style={{ color: "var(--border-default)" }}>|</span>

        <LiveClock />

        <span style={{ color: "var(--border-default)" }}>|</span>

        <button
          onClick={handleLogout}
          className="transition hover:opacity-80 flex-shrink-0"
          style={{ color: "var(--brand-primary)" }}
          title="Logout"
        >
          <LogOut className="w-4 h-4" />
        </button>
      </div>

      {/* Main Nav */}
      <div
        className="px-4 flex items-center gap-6"
        style={{ borderBottom: "3px solid var(--border-default)" }}
      >
        <div className="flex items-center gap-2 py-2">
          {settings.logo ? (
            <img
              src={settings.logo}
              alt="logo"
              className="w-8 h-8 rounded object-contain bg-white"
            />
          ) : (
            <div
              className="w-8 h-8 rounded flex items-center justify-center"
              style={{ background: "var(--brand-gradient)" }}
            >
              <Plane className="w-5 h-5 text-white" />
            </div>
          )}
          <span
            className="font-black text-lg tracking-wider"
            style={{ color: "var(--text-primary)" }}
          >
            {operatorCode}
          </span>
        </div>

        <nav className="flex items-center gap-1 flex-1">
          {primaryTabs.map(
            ({ id, icon: Icon, label_en, label_ar, hasSubTabs }) => {
              const isActive = hasSubTabs ? isReportsActive : tab === id;
              const label = lang === "ar" ? label_ar : label_en;

              if (hasSubTabs) {
                return (
                  <div key={id} className="relative" ref={reportsRef}>
                    <button
                      onClick={() => setReportsOpen(!reportsOpen)}
                      className={`flex items-center gap-2 px-4 py-3 text-sm font-bold transition-all border-b-2 ${
                        isActive
                          ? "border-[var(--brand-primary)]"
                          : "border-transparent"
                      }`}
                      style={{
                        color: isActive
                          ? "var(--brand-primary)"
                          : "var(--text-muted)",
                        backgroundColor: isActive
                          ? "var(--bg-app)"
                          : "transparent",
                      }}
                    >
                      <Icon className="w-4 h-4" /> {label}
                      <ChevronDown
                        className={`w-3 h-3 transition-transform ${
                          reportsOpen ? "rotate-180" : ""
                        }`}
                      />
                    </button>
                    {reportsOpen && (
                      <div
                        className="absolute top-full left-0 mt-1 w-56 rounded-lg shadow-2xl overflow-hidden z-50 border"
                        style={{
                          backgroundColor: "var(--bg-card)",
                          borderColor: "var(--border-default)",
                        }}
                      >
                        {REPORTS_SUBTABS.map((subTab) => {
                          const SubIcon = subTab.icon;
                          const isSubActive = tab === `reports.${subTab.id}`;
                          return (
                            <button
                              key={subTab.id}
                              onClick={() => goTab(`reports.${subTab.id}`)}
                              className="w-full flex items-center gap-3 px-4 py-2.5 text-xs font-semibold transition"
                              style={
                                isSubActive
                                  ? {
                                      background: "var(--brand-gradient)",
                                      color: "white",
                                    }
                                  : { color: "var(--text-muted)" }
                              }
                            >
                              <SubIcon className="w-4 h-4" />
                              {lang === "ar"
                                ? subTab.label_ar
                                : subTab.label_en}
                            </button>
                          );
                        })}
                      </div>
                    )}
                  </div>
                );
              }

              return (
                <button
                  key={id}
                  onClick={() => goTab(id)}
                  className={`flex items-center gap-2 px-4 py-3 text-sm font-bold transition-all border-b-2 ${
                    isActive
                      ? "border-[var(--brand-primary)]"
                      : "border-transparent"
                  }`}
                  style={{
                    color: isActive
                      ? "var(--brand-primary)"
                      : "var(--text-muted)",
                    backgroundColor: isActive ? "var(--bg-app)" : "transparent",
                  }}
                >
                  <Icon className="w-4 h-4" /> {label}
                </button>
              );
            }
          )}

          {moreTabs.length > 0 && (
            <div className="relative" ref={moreRef}>
              <button
                onClick={() => setMoreOpen(!moreOpen)}
                className="flex items-center gap-1 px-4 py-3 text-sm font-bold transition"
                style={{ color: "var(--text-muted)" }}
              >
                <MoreHorizontal className="w-4 h-4" />
                <span className="hidden lg:inline">
                  {lang === "ar" ? "المزيد" : "More"}
                </span>
                <ChevronDown
                  className={`w-3 h-3 transition-transform ${
                    moreOpen ? "rotate-180" : ""
                  }`}
                />
              </button>
              {moreOpen && (
                <div
                  className="absolute top-full right-0 mt-1 w-56 rounded-lg shadow-2xl overflow-hidden z-50 max-h-[70vh] overflow-y-auto border"
                  style={{
                    backgroundColor: "var(--bg-card)",
                    borderColor: "var(--border-default)",
                  }}
                >
                  {moreTabs.map(({ id, icon: Icon, label_en, label_ar }) => (
                    <button
                      key={id}
                      onClick={() => goTab(id)}
                      className="w-full flex items-center gap-3 px-4 py-2.5 text-xs font-semibold transition"
                      style={
                        tab === id
                          ? {
                              background: "var(--brand-gradient)",
                              color: "white",
                            }
                          : { color: "var(--text-muted)" }
                      }
                    >
                      <Icon className="w-4 h-4" />
                      {lang === "ar" ? label_ar : label_en}
                    </button>
                  ))}
                </div>
              )}
            </div>
          )}
        </nav>

        <div className="flex items-center gap-2 py-2">
          <SyncBadge status={syncStatus} onRetry={loadData} />
          <AlertsPanel crew={crew} users={users} fleet={fleet} />
          <button
            onClick={() => setDarkMode(!darkMode)}
            className="p-2 rounded-lg transition"
            style={{
              backgroundColor: "var(--bg-app)",
              color: "var(--text-muted)",
            }}
          >
            {darkMode ? (
              <Sun className="w-4 h-4" />
            ) : (
              <Moon className="w-4 h-4" />
            )}
          </button>
        </div>
      </div>
    </header>
  );

  return (
    <div
      className="min-h-screen theme-transition"
      style={{ backgroundColor: "var(--bg-app)", color: "var(--text-primary)" }}
      dir={t.dir}
    >
      <SoundNotifications />

      {/* ═══ CHROME — Header OR SideNav ═══ */}
      {showChrome && !isSideNav && renderTopHeader()}
      {showChrome && isSideNav && renderSideNav()}

      {/* ═══ MAIN CONTENT ═══ */}
      <main
        className={`min-w-0 overflow-x-hidden ${
          showChrome && isSideNav ? "md:ms-64" : ""
        }`}
      >
        {renderMain()}
      </main>

      {/* ═══ DRAWER (Mobile) ═══ */}
      {drawerOpen && !shouldShowCrewPortal && (
        <>
          <div
            className="md:hidden fixed inset-0 bg-black/60 z-40 backdrop-blur-sm"
            onClick={() => setDrawerOpen(false)}
          />
          <aside
            className="md:hidden fixed inset-y-0 start-0 z-50 w-[85%] max-w-sm flex flex-col shadow-2xl"
            style={{
              backgroundColor: "var(--bg-card)",
              color: "var(--text-primary)",
            }}
          >
            <div
              className="p-4 flex items-center gap-3 border-b"
              style={{ borderColor: "var(--border-default)" }}
            >
              {settings.logo ? (
                <img
                  src={settings.logo}
                  alt="logo"
                  className="w-12 h-12 rounded-2xl object-contain bg-white p-1"
                />
              ) : (
                <div
                  className="w-12 h-12 rounded-2xl flex items-center justify-center"
                  style={{ background: "var(--brand-gradient)" }}
                >
                  <Plane className="w-6 h-6 text-white" />
                </div>
              )}
              <div className="flex-1 min-w-0">
                <div
                  className="font-black text-xl font-mono tracking-widest"
                  style={{ color: "var(--text-primary)" }}
                >
                  {operatorCode}
                </div>
              </div>
              <button
                onClick={() => setDrawerOpen(false)}
                className="w-10 h-10 rounded-xl flex items-center justify-center"
                style={{ backgroundColor: "var(--bg-app)" }}
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <nav className="flex-1 overflow-y-auto p-3 space-y-1">
              {primaryTabs.map(
                ({ id, icon: Icon, label_en, label_ar, hasSubTabs }) => {
                  if (hasSubTabs) {
                    return (
                      <div key={id}>
                        <div
                          className="px-4 py-2 text-[10px] font-bold uppercase tracking-widest"
                          style={{ color: "var(--text-muted)" }}
                        >
                          {lang === "ar" ? label_ar : label_en}
                        </div>
                        {REPORTS_SUBTABS.map((subTab) => {
                          const SubIcon = subTab.icon;
                          const isSubActive = tab === `reports.${subTab.id}`;
                          return (
                            <button
                              key={subTab.id}
                              onClick={() => goTab(`reports.${subTab.id}`)}
                              className="w-full flex items-center gap-4 px-4 py-2.5 rounded-2xl text-sm font-bold text-start transition"
                              style={
                                isSubActive
                                  ? {
                                      background: "var(--brand-gradient)",
                                      color: "white",
                                    }
                                  : { color: "var(--text-muted)" }
                              }
                            >
                              <div
                                className="w-8 h-8 rounded-xl flex items-center justify-center"
                                style={{
                                  backgroundColor: isSubActive
                                    ? "rgba(255,255,255,0.2)"
                                    : "var(--bg-app)",
                                }}
                              >
                                <SubIcon className="w-4 h-4" />
                              </div>
                              <span className="flex-1 truncate">
                                {lang === "ar"
                                  ? subTab.label_ar
                                  : subTab.label_en}
                              </span>
                            </button>
                          );
                        })}
                      </div>
                    );
                  }
                  const isActive = tab === id;
                  return (
                    <button
                      key={id}
                      onClick={() => goTab(id)}
                      className="w-full flex items-center gap-4 px-4 py-3 rounded-2xl text-sm font-bold text-start transition"
                      style={
                        isActive
                          ? {
                              background: "var(--brand-gradient)",
                              color: "white",
                            }
                          : { color: "var(--text-muted)" }
                      }
                    >
                      <div
                        className="w-9 h-9 rounded-xl flex items-center justify-center"
                        style={{
                          backgroundColor: isActive
                            ? "rgba(255,255,255,0.2)"
                            : "var(--bg-app)",
                        }}
                      >
                        <Icon className="w-4 h-4" />
                      </div>
                      <span className="flex-1 truncate">
                        {lang === "ar" ? label_ar : label_en}
                      </span>
                    </button>
                  );
                }
              )}

              {moreTabs.length > 0 && (
                <div
                  className="px-4 pt-3 pb-1 text-[10px] font-bold uppercase tracking-widest"
                  style={{ color: "var(--text-muted)" }}
                >
                  {lang === "ar" ? "المزيد" : "More"}
                </div>
              )}

              {moreTabs.map(({ id, icon: Icon, label_en, label_ar }) => {
                const isActive = tab === id;
                return (
                  <button
                    key={id}
                    onClick={() => goTab(id)}
                    className="w-full flex items-center gap-4 px-4 py-3 rounded-2xl text-sm font-bold text-start transition"
                    style={
                      isActive
                        ? {
                            background: "var(--brand-gradient)",
                            color: "white",
                          }
                        : { color: "var(--text-muted)" }
                    }
                  >
                    <div
                      className="w-9 h-9 rounded-xl flex items-center justify-center"
                      style={{
                        backgroundColor: isActive
                          ? "rgba(255,255,255,0.2)"
                          : "var(--bg-app)",
                      }}
                    >
                      <Icon className="w-4 h-4" />
                    </div>
                    <span className="flex-1 truncate">
                      {lang === "ar" ? label_ar : label_en}
                    </span>
                  </button>
                );
              })}
            </nav>

            <div
              className="p-3 border-t space-y-2"
              style={{ borderColor: "var(--border-default)" }}
            >
              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={() => setLang("ar")}
                  className="px-3 py-3 rounded-xl font-bold text-sm transition"
                  style={
                    lang === "ar"
                      ? { background: "var(--brand-gradient)", color: "white" }
                      : {
                          backgroundColor: "var(--bg-app)",
                          color: "var(--text-muted)",
                        }
                  }
                >
                  العربية
                </button>
                <button
                  onClick={() => setLang("en")}
                  className="px-3 py-3 rounded-xl font-bold text-sm transition"
                  style={
                    lang === "en"
                      ? { background: "var(--brand-gradient)", color: "white" }
                      : {
                          backgroundColor: "var(--bg-app)",
                          color: "var(--text-muted)",
                        }
                  }
                >
                  English
                </button>
              </div>
              <button
                onClick={handleLogout}
                className="w-full flex items-center justify-center gap-2 px-4 py-3.5 rounded-2xl bg-rose-500/20 hover:bg-rose-500/30 text-rose-500 font-bold"
              >
                <LogOut className="w-5 h-5" /> {t.logout}
              </button>
            </div>
          </aside>
        </>
      )}

      {/* ═══ MODALS ═══ */}
      {genDec && (
        <GenDecModal
          flight={genDec}
          crew={crew}
          settings={settings}
          onClose={() => setGenDec(null)}
        />
      )}

      {viewingProfile && (
        <UserProfileModal
          user={viewingProfile}
          crew={crew}
          settings={settings}
          onClose={() => setViewingProfile(null)}
        />
      )}
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════
 * ROOT APP
 * ═══════════════════════════════════════════════════════════ */
export default function App() {
  const [lang] = useLocalStorage("aeroops.lang", "en");
  return (
    <LangProvider lang={lang}>
      <AuthProvider>
        <AppInner />
      </AuthProvider>
    </LangProvider>
  );
}
