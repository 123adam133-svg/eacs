/* ═══════════════════════════════════════════════════════════
 * LIVE CLOCK — Inline (Single Line, Theme-aware)
 * Shows UTC + Local Time
 * ═══════════════════════════════════════════════════════════ */
import React, { useState, useEffect } from "react";
import { Clock, Globe } from "lucide-react";

export function LiveClock() {
  const [now, setNow] = useState(new Date());

  useEffect(() => {
    const id = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(id);
  }, []);

  const pad = (n) => String(n).padStart(2, "0");

  const utcTime = `${pad(now.getUTCHours())}:${pad(now.getUTCMinutes())}:${pad(
    now.getUTCSeconds()
  )}`;

  const localTime = `${pad(now.getHours())}:${pad(now.getMinutes())}:${pad(
    now.getSeconds()
  )}`;

  const getLocalTZ = () => {
    try {
      return Intl.DateTimeFormat()
        .resolvedOptions()
        .timeZone.split("/")
        .pop()
        .replace(/_/g, " ");
    } catch {
      return "Local";
    }
  };

  const localTZ = getLocalTZ();
  const isUTCOnly = Math.abs(now.getTimezoneOffset()) === 0;

  return (
    <div className="flex items-center gap-2 text-xs font-mono font-bold">
      {/* ═══ Local Time ═══ */}
      <div className="flex items-center gap-1">
        <Clock
          className="w-3.5 h-3.5"
          style={{ color: "var(--brand-primary)" }}
        />
        <span className="tabular-nums" style={{ color: "var(--text-primary)" }}>
          {localTime}
        </span>
        <span
          className="text-[10px] font-normal hidden md:inline"
          style={{ color: "var(--text-muted)" }}
        >
          {localTZ}
        </span>
      </div>

      {/* ═══ Separator + UTC (if not already in UTC) ═══ */}
      {!isUTCOnly && (
        <>
          <span style={{ color: "var(--border-default)" }}>·</span>
          <div className="flex items-center gap-1">
            <Globe
              className="w-3.5 h-3.5"
              style={{ color: "var(--brand-secondary)" }}
            />
            <span
              className="tabular-nums"
              style={{ color: "var(--text-primary)" }}
            >
              {utcTime}
            </span>
            <span
              className="text-[10px] font-normal"
              style={{ color: "var(--text-muted)" }}
            >
              UTC
            </span>
          </div>
        </>
      )}

      {/* ═══ If user in UTC, just show single UTC label ═══ */}
      {isUTCOnly && (
        <span
          className="text-[10px] font-normal"
          style={{ color: "var(--text-muted)" }}
        >
          UTC
        </span>
      )}
    </div>
  );
}

export default LiveClock;
