/* ═══════════════════════════════════════════════════════════
 * SCHEDULE BOARD — Multi-Sector + 24H Time Input
 * v7.7 — Fixed ft.icon Component in TYPE column + Select
 * ═══════════════════════════════════════════════════════════ */
import React, { useState, useMemo } from "react";
import {
  Plus,
  Trash2,
  Search,
  Save,
  Stamp,
  FileX,
  ShieldAlert,
  Table,
  CalendarDays,
  List,
  Calendar,
  ChevronLeft,
  ChevronRight,
  Globe,
  Filter,
  MoreHorizontal,
  PlaneTakeoff,
} from "lucide-react";
import { useT, useAuth } from "../contexts";
import { Field } from "../components/ui/Field";
import { Input } from "../components/ui/Input";
import { Select } from "../components/ui/Select";
import { Modal } from "../components/ui/Modal";
import { AirportInput } from "../components/AirportInput";
import { FlightContextMenu } from "../components/FlightContextMenu";
import { FlightNotesModal } from "../components/FlightNotesModal";
import { CompleteFlightModal } from "../components/CompleteFlightModal";
import { GenDecMultiModal } from "../components/GenDecMultiModal";
import { BulkEditLegsModal } from "../components/BulkEditLegsModal";
import { CalendarView } from "./CalendarView";
import { TimelineView } from "./TimelineView";
import { flightsAPI, sendFlightEmail, checkExpiryAlerts } from "../api";
import { logSafe } from "../utils/audit";
import { can as checkPerm } from "../config/permissions";
import { alertSuccess, alertError } from "../utils/sounds";
import {
  fmtTime,
  fmtDateParts,
  todayISO,
  safeArray,
  safeObject,
} from "../utils/helpers";
import {
  getAllowedRoles,
  getPositionOptions,
  FLIGHT_TYPES,
  getFlightType,
} from "../config/constants";
import { printGenDec } from "../utils/gendecHTML";

/* ═══════════════════════════════════════════════════════════
 * HELPERS
 * ═══════════════════════════════════════════════════════════ */
function getCrewAssignedAircrafts(member) {
  if (!member) return [];
  const raw = member.assignedAircraft;
  if (Array.isArray(raw)) return raw.map(String).filter(Boolean);
  if (typeof raw === "string" && raw.trim()) {
    try {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) return parsed.map(String).filter(Boolean);
    } catch {
      return raw
        .split(",")
        .map((s) => s.trim())
        .filter(Boolean);
    }
  }
  return [];
}

function getMemberAllRoles(member) {
  if (!member) return [];
  const roles = new Set();
  if (member.role) roles.add(member.role);
  let sec = member.secondaryRoles;
  if (Array.isArray(sec)) {
    sec.forEach((r) => r && roles.add(r));
  } else if (typeof sec === "string" && sec.trim()) {
    try {
      const parsed = JSON.parse(sec);
      if (Array.isArray(parsed)) parsed.forEach((r) => r && roles.add(r));
    } catch {
      sec.split(",").forEach((r) => r && roles.add(r.trim()));
    }
  }
  return Array.from(roles);
}

function isCrewQualifiedForAircraft(member, aircraftReg) {
  if (!member) return false;
  if (!aircraftReg || !String(aircraftReg).trim()) return true;
  const primaryRole = String(member.role || "")
    .toLowerCase()
    .trim();
  if (primaryRole === "flightdispatcher" || primaryRole === "dispatcher")
    return true;
  const assigned = getCrewAssignedAircrafts(member).map((a) =>
    String(a).trim().toUpperCase()
  );
  if (assigned.length === 0) return false;
  return assigned.includes(String(aircraftReg).trim().toUpperCase());
}

const STATUS_LIST = [
  "SCHEDULED",
  "BOARDING",
  "DEPARTED",
  "IN_FLIGHT",
  "ARRIVED",
  "DELAYED",
  "CANCELLED",
];

export const computeAutoStatus = (flight) => {
  const actual = flight.actual || {};
  const hasStd = actual.std && String(actual.std).trim().length > 0;
  const hasSta = actual.sta && String(actual.sta).trim().length > 0;
  const hasCancel =
    actual.cancelled === true ||
    (actual.reason && String(actual.reason).trim().length > 0);
  if (hasCancel) return "CANCELLED";
  if (hasSta) return "ARRIVED";
  if (hasStd) return "DEPARTED";
  return flight.status || "SCHEDULED";
};

function normalizeLegForEdit(leg, fallbackDate) {
  const date = leg.date
    ? leg.date
    : leg.std
    ? String(leg.std).slice(0, 10)
    : fallbackDate;
  const std = leg.std ? String(leg.std).slice(11, 16) : "12:00";
  const sta = leg.sta ? String(leg.sta).slice(11, 16) : "13:30";
  return { ...leg, date, std, sta };
}

/* ⭐ v7.7 — عرض أيقونة نوع الرحلة (Component أو Emoji) */
function FlightTypeIcon({ ft, size = "w-3.5 h-3.5" }) {
  if (!ft) return null;
  if (typeof ft.icon === "function") {
    const Icon = ft.icon;
    return <Icon className={size} />;
  }
  if (typeof ft.icon === "string") {
    return <span className="text-[11px] leading-none">{ft.icon}</span>;
  }
  return null;
}

export function ScheduleBoard({
  flights,
  setFlights,
  reloadFlights,
  crew,
  fleet,
  settings,
  onGenDec,
  setSyncStatus,
}) {
  const t = useT();
  const { user } = useAuth();

  const POSITION_OPTIONS = useMemo(
    () => getPositionOptions(settings),
    [settings]
  );
  const ALL_COLUMN_POSITIONS = useMemo(
    () => POSITION_OPTIONS.map((p) => p.key),
    [POSITION_OPTIONS]
  );
  const POSITION_LABELS = useMemo(() => {
    const map = {};
    POSITION_OPTIONS.forEach((p) => {
      map[p.key] = {
        short: p.short || p.key.toUpperCase(),
        full: p.en || p.key,
      };
    });
    return map;
  }, [POSITION_OPTIONS]);

  const canCreate = checkPerm(user, "schedule.create");
  const canEdit = checkPerm(user, "schedule.edit");
  const canDelete = checkPerm(user, "schedule.delete");
  const canAssignCrew = checkPerm(user, "schedule.assign_crew");

  /* ═══ State ═══ */
  const [q, setQ] = useState("");
  const [editing, setEditing] = useState(null);
  const [draft, setDraft] = useState({});
  const [viewMode, setViewMode] = useState("table");
  const [showFilters, setShowFilters] = useState(false);
  const [selectedDate, setSelectedDate] = useState(todayISO());
  const [timeMode, setTimeMode] = useState("UTC");
  const [rangeDays, setRangeDays] = useState(1);
  const [statusFilter, setStatusFilter] = useState("");
  const [acftFilter, setAcftFilter] = useState("");
  const [typeFilter, setTypeFilter] = useState("");

  const [selectedIds, setSelectedIds] = useState([]);
  const [contextMenu, setContextMenu] = useState(null);
  const [completeFlight, setCompleteFlight] = useState(null);
  const [notesModal, setNotesModal] = useState(null);

  // ⭐ v7.6 — Modals جديدة
  const [genDecMultiFlights, setGenDecMultiFlights] = useState(null);
  const [bulkEditLegsFlights, setBulkEditLegsFlights] = useState(null);

  /* ═══ Helpers ═══ */
  const now = new Date();
  const getFlightTime = (f) => (f.std ? new Date(f.std) : null);

  const isCompleted = (f) => {
    const a = f.actual || {};
    const hasStd = a.std && String(a.std).trim().length > 0;
    const hasSta = a.sta && String(a.sta).trim().length > 0;
    const isCancelled = a.cancelled === true;
    return hasStd && hasSta && !isCancelled;
  };

  const isUpcoming = (f) => {
    const ft = getFlightTime(f);
    return ft ? ft.getTime() > now.getTime() - 30 * 60 * 1000 : false;
  };

  const isPast = (f) => {
    if (isCompleted(f)) return false;
    const ft = getFlightTime(f);
    return ft ? ft.getTime() <= now.getTime() - 30 * 60 * 1000 : false;
  };

  const getDateRange = () => {
    const start = new Date(selectedDate + "T00:00:00Z");
    const end = new Date(start);
    end.setUTCDate(end.getUTCDate() + rangeDays);
    return { start, end };
  };

  const isInRange = (f) => {
    const ft = getFlightTime(f);
    if (!ft) return false;
    const { start, end } = getDateRange();
    return ft >= start && ft < end;
  };

  const shiftDate = (days) => {
    const d = new Date(selectedDate + "T00:00:00Z");
    d.setUTCDate(d.getUTCDate() + days);
    setSelectedDate(d.toISOString().slice(0, 10));
  };
  const goToday = () => setSelectedDate(todayISO());

  /* ═══ Filtering ═══ */
  const filtered = flights
    .filter((f) => {
      if (!isInRange(f)) return false;
      const matchesSearch =
        !q ||
        (f.flightNo + f.dep + f.arr + (f.acft || ""))
          .toLowerCase()
          .includes(q.toLowerCase());
      if (!matchesSearch) return false;
      if (statusFilter && f.status !== statusFilter) return false;
      if (acftFilter && f.acft !== acftFilter) return false;
      if (typeFilter && f.flightType !== typeFilter) return false;
      return true;
    })
    .sort((a, b) => {
      const ta = getFlightTime(a)?.getTime() || 0;
      const tb = getFlightTime(b)?.getTime() || 0;
      return ta - tb;
    });

  /* ═══ Counters ═══ */
  const counters = {
    all: flights.filter(isInRange).length,
    upcoming: flights.filter((f) => isInRange(f) && isUpcoming(f)).length,
    past: flights.filter((f) => isInRange(f) && isPast(f)).length,
    completed: flights.filter((f) => isInRange(f) && isCompleted(f)).length,
  };

  /* ⭐ الأعمدة النشطة */
  const positionsToShow = useMemo(() => {
    const active = ALL_COLUMN_POSITIONS.filter((pos) =>
      filtered.some((f) =>
        safeArray(f.crewSlots).some((s) => s.position === pos && s.crewId)
      )
    );
    return active.length > 0 ? active : ALL_COLUMN_POSITIONS;
  }, [filtered, ALL_COLUMN_POSITIONS]);

  /* ═══ Crew helpers ═══ */
  const crewByPosDetailed = (f, pos) => {
    const slots = safeArray(f.crewSlots).filter((s) => s.position === pos);
    const seen = new Set();
    return slots
      .map((s) => crew.find((x) => x.id === s.crewId))
      .filter((m) => {
        if (!m || seen.has(m.id)) return false;
        seen.add(m.id);
        return true;
      });
  };

  const getShortCode = (member) => {
    if (!member) return "—";
    if (member.empNo) return String(member.empNo).slice(-5);
    const nameParts = (member.fullName || "").trim().split(/\s+/);
    if (nameParts.length === 1) return nameParts[0].slice(0, 3).toUpperCase();
    const first = nameParts[0][0] || "";
    const last = nameParts[nameParts.length - 1].slice(0, 3) || "";
    return `${first}.${last}`.toUpperCase();
  };

  const getShortCodeWithColor = (member, positionKey) => {
    if (!member) return null;
    const code = getShortCode(member);
    const colorMap = {
      captain: "bg-sky-500/20 text-sky-400 border-sky-500/50",
      firstOfficer: "bg-emerald-500/20 text-emerald-400 border-emerald-500/50",
      observer: "bg-indigo-500/20 text-indigo-400 border-indigo-500/50",
      tri: "bg-cyan-500/20 text-cyan-400 border-cyan-500/50",
      flightAttendant: "bg-amber-500/20 text-amber-400 border-amber-500/50",
      fa1: "bg-amber-500/20 text-amber-400 border-amber-500/50",
      fa2: "bg-amber-500/20 text-amber-400 border-amber-500/50",
      engineer: "bg-purple-500/20 text-purple-400 border-purple-500/50",
      security: "bg-rose-500/20 text-rose-400 border-rose-500/50",
      loadmaster: "bg-teal-500/20 text-teal-400 border-teal-500/50",
      flightDispatcher: "bg-violet-500/20 text-violet-400 border-violet-500/50",
    };
    const key = positionKey || member.role;
    return {
      code,
      color: colorMap[key] || "bg-white/10 text-white border-white/20",
    };
  };

  /* ═══ Selection ═══ */
  const toggleSelect = (id) => {
    setSelectedIds((prev) =>
      prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]
    );
  };

  const toggleSelectAll = () => {
    if (selectedIds.length === filtered.length) setSelectedIds([]);
    else setSelectedIds(filtered.map((f) => f.id));
  };

  /* ═══ CRUD ═══ */
  const openNew = () => {
    if (!canCreate) return alert("⚠️ ليس لديك صلاحية إنشاء رحلات");
    setDraft({
      flightNo: "",
      dep: "",
      arr: "",
      altn: "",
      altn2: "",
      date: todayISO(),
      std: "12:00",
      sta: "13:30",
      acft: "",
      status: "SCHEDULED",
      flightType: "SCHEDULED",
      notes: "",
      permits: "",
      services: "",
      pax: 0,
      cargo: 0,
      crewSlots: [],
      legs: [],
    });
    setEditing("new");
  };

  const openEdit = (f) => {
    if (!canEdit) return alert("⚠️ ليس لديك صلاحية تعديل الرحلات");
    const mainDate = f.std ? String(f.std).slice(0, 10) : todayISO();
    let legs = [];
    if (Array.isArray(f.legs)) {
      legs = f.legs.map((l) => normalizeLegForEdit(l, mainDate));
    } else if (typeof f.legs === "string" && f.legs.trim()) {
      try {
        const parsed = JSON.parse(f.legs);
        if (Array.isArray(parsed))
          legs = parsed.map((l) => normalizeLegForEdit(l, mainDate));
      } catch {
        legs = [];
      }
    }
    setDraft({
      ...f,
      date: mainDate,
      std: f.std ? String(f.std).slice(11, 16) : "12:00",
      sta: f.sta ? String(f.sta).slice(11, 16) : "13:30",
      flightType: f.flightType || "SCHEDULED",
      notes: f.notes || "",
      permits: f.permits || "",
      services: f.services || "",
      crewSlots: safeArray(f.crewSlots).filter((s) => s.crewId && s.position),
      actual: safeObject(f.actual),
      legs,
    });
    setEditing(f.id);
  };

  const save = async () => {
    if (editing === "new" && !canCreate) return;
    if (editing !== "new" && !canEdit) return;
    if (!draft.flightNo || !draft.date)
      return alert("⚠️ رقم الرحلة والتاريخ مطلوبان");

    const stdIso = draft.date + "T" + draft.std + ":00.000Z";
    const staIso = draft.date + "T" + draft.sta + ":00.000Z";
    const legsIso = (draft.legs || []).map((l) => ({
      ...l,
      std: (l.date || draft.date) + "T" + (l.std || "12:00") + ":00.000Z",
      sta: (l.date || draft.date) + "T" + (l.sta || "13:30") + ":00.000Z",
    }));

    if (draft.acft && safeArray(draft.crewSlots).length > 0) {
      const unqualified = safeArray(draft.crewSlots).filter((slot) => {
        if (!slot.crewId) return false;
        const member = crew.find((c) => String(c.id) === String(slot.crewId));
        return member && !isCrewQualifiedForAircraft(member, draft.acft);
      });
      if (unqualified.length > 0) {
        const names = unqualified
          .map(
            (slot) =>
              crew.find((c) => String(c.id) === String(slot.crewId))
                ?.fullName || slot.crewId
          )
          .join(", ");
        return alert(`⚠️ الأعضاء غير مؤهلين:\n${names}`);
      }
    }

    const autoStatus = computeAutoStatus({
      ...draft,
      std: stdIso,
      sta: staIso,
    });
    const finalDraft = {
      ...draft,
      std: stdIso,
      sta: staIso,
      legs: legsIso,
      status: autoStatus,
    };

    setSyncStatus?.("syncing");
    try {
      if (editing === "new") {
        const created = await flightsAPI.create(finalDraft);
        setFlights((prev) => [...prev, { ...finalDraft, id: created.id }]);
        logSafe(user, "CREATE", "Flight", created.id, finalDraft.flightNo, {});
      } else {
        await flightsAPI.update(editing, finalDraft);
        setFlights((prev) =>
          prev.map((f) =>
            f.id === editing ? { ...finalDraft, id: editing } : f
          )
        );
        logSafe(user, "UPDATE", "Flight", editing, finalDraft.flightNo, {});
      }
      setEditing(null);
      setSyncStatus?.("synced");
      alertSuccess();
    } catch (e) {
      alert("Save failed: " + e.message);
      setSyncStatus?.("error");
      alertError();
    }
  };

  const remove = async (id) => {
    if (!canDelete) return;
    if (!confirm(t.confirmDelete)) return;
    try {
      await flightsAPI.remove(id);
      setFlights((prev) => prev.filter((f) => f.id !== id));
      setSelectedIds((prev) => prev.filter((x) => x !== id));
      alertSuccess();
    } catch (e) {
      alert("Delete failed: " + e.message);
      alertError();
    }
  };

  const saveNotesAndPermits = async (flightId, data) => {
    if (!canEdit) throw new Error("No permission");
    const flight = flights.find((f) => f.id === flightId);
    if (!flight) return;
    try {
      await flightsAPI.update(flightId, {
        ...flight,
        notes: data.notes || "",
        permits: data.permits || "",
        services: data.services || "",
      });
      setFlights((prev) =>
        prev.map((f) =>
          f.id === flightId
            ? {
                ...f,
                notes: data.notes || "",
                permits: data.permits || "",
                services: data.services || "",
              }
            : f
        )
      );
      alertSuccess();
    } catch (e) {
      alertError();
      throw e;
    }
  };

  /* ⭐ v7.6 — فتح GenDec Multi Modal */
  const handleOpenGenDecMulti = () => {
    if (selectedIds.length === 0) return alert("⚠️ لم يتم تحديد أي رحلة");
    if (!canEdit) return;
    const selectedFlights = flights.filter((f) => selectedIds.includes(f.id));
    if (selectedFlights.length === 0) return;
    setGenDecMultiFlights(selectedFlights);
  };

  /* ⭐ v7.6 — فتح Bulk Edit Legs Modal */
  const handleOpenBulkEditLegs = () => {
    if (selectedIds.length === 0) return alert("⚠️ لم يتم تحديد أي رحلة");
    if (!canEdit) return;
    const selectedFlights = flights.filter((f) => selectedIds.includes(f.id));
    if (selectedFlights.length === 0) return;
    const totalLegs = selectedFlights.reduce(
      (acc, f) => acc + (Array.isArray(f.legs) ? f.legs.length : 0),
      0
    );
    if (totalLegs === 0) {
      alert("⚠️ الرحلات المحددة لا تحتوي على قطاعات إضافية (legs)");
      return;
    }
    setBulkEditLegsFlights(selectedFlights);
  };

  /* ⭐ v7.6 — حفظ التعديل الجماعي للـ legs */
  const saveBulkEditLegs = async (changes) => {
    if (!canEdit) throw new Error("No permission");
    if (!bulkEditLegsFlights) return;

    setSyncStatus?.("syncing");
    try {
      for (const f of bulkEditLegsFlights) {
        const legs = Array.isArray(f.legs) ? f.legs : [];
        if (legs.length === 0) continue;

        const updatedLegs = legs.map((leg) => {
          const newLeg = { ...leg };
          if (changes.date) {
            newLeg.date = changes.date;
            if (newLeg.std)
              newLeg.std =
                changes.date +
                "T" +
                String(newLeg.std).slice(11, 16) +
                ":00.000Z";
            if (newLeg.sta)
              newLeg.sta =
                changes.date +
                "T" +
                String(newLeg.sta).slice(11, 16) +
                ":00.000Z";
          }
          if (changes.std) {
            const legDate =
              newLeg.date || (f.std ? String(f.std).slice(0, 10) : "");
            newLeg.std = legDate + "T" + changes.std + ":00.000Z";
            newLeg.date = legDate;
          }
          if (changes.sta) {
            const legDate =
              newLeg.date || (f.std ? String(f.std).slice(0, 10) : "");
            newLeg.sta = legDate + "T" + changes.sta + ":00.000Z";
          }
          if (changes.acft) newLeg.acft = changes.acft;
          return newLeg;
        });

        await flightsAPI.update(f.id, { ...f, legs: updatedLegs });
      }

      setFlights((prev) =>
        prev.map((f) => {
          if (!bulkEditLegsFlights.some((bf) => bf.id === f.id)) return f;
          const legs = Array.isArray(f.legs) ? f.legs : [];
          const updatedLegs = legs.map((leg) => {
            const newLeg = { ...leg };
            if (changes.date) {
              newLeg.date = changes.date;
              if (newLeg.std)
                newLeg.std =
                  changes.date +
                  "T" +
                  String(newLeg.std).slice(11, 16) +
                  ":00.000Z";
              if (newLeg.sta)
                newLeg.sta =
                  changes.date +
                  "T" +
                  String(newLeg.sta).slice(11, 16) +
                  ":00.000Z";
            }
            if (changes.std) {
              const legDate =
                newLeg.date || (f.std ? String(f.std).slice(0, 10) : "");
              newLeg.std = legDate + "T" + changes.std + ":00.000Z";
              newLeg.date = legDate;
            }
            if (changes.sta) {
              const legDate =
                newLeg.date || (f.std ? String(f.std).slice(0, 10) : "");
              newLeg.sta = legDate + "T" + changes.sta + ":00.000Z";
            }
            if (changes.acft) newLeg.acft = changes.acft;
            return newLeg;
          });
          return { ...f, legs: updatedLegs };
        })
      );

      setBulkEditLegsFlights(null);
      setSelectedIds([]);
      setSyncStatus?.("synced");
      alertSuccess();
    } catch (e) {
      alert("Bulk edit failed: " + e.message);
      setSyncStatus?.("error");
      alertError();
      throw e;
    }
  };

  const bulkAction = async (action) => {
    if (selectedIds.length === 0)
      return alert("⚠️ الرجاء تحديد رحلة واحدة على الأقل");
    const selectedFlights = flights.filter((f) => selectedIds.includes(f.id));

    if (action === "delete") {
      if (!canDelete) return;
      if (!confirm(`${t.delete} ${selectedFlights.length}?`)) return;
      try {
        for (const f of selectedFlights) await flightsAPI.remove(f.id);
        setFlights((prev) => prev.filter((f) => !selectedIds.includes(f.id)));
        setSelectedIds([]);
        alertSuccess();
      } catch (e) {
        alertError();
      }
      return;
    }

    if (action === "complete") {
      if (!canEdit) return;
      for (const f of selectedFlights) {
        try {
          const autoStatus = computeAutoStatus({
            ...f,
            actual: f.actual || {},
          });
          await flightsAPI.update(f.id, { ...f, status: autoStatus });
        } catch (e) {
          console.error(e);
        }
      }
      setFlights((prev) =>
        prev.map((f) =>
          selectedIds.includes(f.id)
            ? { ...f, status: computeAutoStatus(f) }
            : f
        )
      );
      setSelectedIds([]);
      alertSuccess();
      return;
    }
  };

  /* ⭐ v7.2 — إضافة قطاع جديد */
  const addLeg = () => {
    const currentLegs = draft.legs || [];
    const lastLeg =
      currentLegs.length > 0
        ? currentLegs[currentLegs.length - 1]
        : { arr: draft.arr, sta: draft.sta, date: draft.date };

    setDraft({
      ...draft,
      legs: [
        ...currentLegs,
        {
          date: lastLeg.date || draft.date,
          dep: lastLeg.arr || "",
          arr: "",
          std: lastLeg.sta || "12:00",
          sta: "13:30",
          acft: draft.acft || "",
        },
      ],
    });
  };

  const updateLeg = (idx, patch) => {
    const newLegs = [...draft.legs];
    newLegs[idx] = { ...newLegs[idx], ...patch };
    setDraft({ ...draft, legs: newLegs });
  };

  const removeLeg = (idx) => {
    setDraft({ ...draft, legs: draft.legs.filter((_, i) => i !== idx) });
  };

  /* ⭐ Crew Slots */
  const addSlot = () => {
    if (!canAssignCrew && !canEdit) return;
    const usedPositions = safeArray(draft.crewSlots)
      .map((s) => s.position)
      .filter(Boolean);
    const firstAvailable = POSITION_OPTIONS.find(
      (p) => !usedPositions.includes(p.key)
    );
    if (!firstAvailable) return alert("⚠️ كل الوظائف معيّنة بالفعل");
    setDraft({
      ...draft,
      crewSlots: [
        ...safeArray(draft.crewSlots),
        { crewId: "", position: firstAvailable.key },
      ],
    });
  };

  const updateSlot = (i, patch) => {
    const list = [...safeArray(draft.crewSlots)];
    list[i] = { ...list[i], ...patch };
    if (patch.position && list[i].crewId) {
      const member = crew.find((c) => c.id === list[i].crewId);
      const allowed = getAllowedRoles(patch.position);
      const memberRoles = getMemberAllRoles(member);
      const hasMatch = memberRoles.some((r) => allowed.includes(r));
      if (member && !hasMatch) list[i].crewId = "";
    }
    setDraft({ ...draft, crewSlots: list });
  };

  const removeSlot = (i) =>
    setDraft({
      ...draft,
      crewSlots: safeArray(draft.crewSlots).filter((_, idx) => idx !== i),
    });

  /* ⭐ Complete Flight */
  const saveCompleteFlight = async (updatedFlight) => {
    if (!canEdit) throw new Error("No permission");
    const autoStatus = computeAutoStatus(updatedFlight);
    const finalFlight = {
      ...updatedFlight,
      status: autoStatus,
      actual: { ...(updatedFlight.actual || {}) },
    };
    setSyncStatus?.("syncing");
    try {
      const apiResponse = await flightsAPI.update(finalFlight.id, finalFlight);
      const savedFlight = {
        ...finalFlight,
        ...(apiResponse || {}),
        id: finalFlight.id,
        actual: { ...(apiResponse?.actual || {}), ...finalFlight.actual },
      };
      setFlights((prev) =>
        prev.map((f) => (f.id === savedFlight.id ? savedFlight : f))
      );
      setSyncStatus?.("synced");
      alertSuccess();
      if (typeof reloadFlights === "function") {
        setTimeout(() => {
          reloadFlights().catch((e) =>
            console.warn("reloadFlights failed:", e)
          );
        }, 400);
      }
    } catch (e) {
      setSyncStatus?.("error");
      alertError();
      throw e;
    }
  };

  /* ⭐ Manual email */
  const handleSendFlightEmail = async (flight) => {
    if (!flight) return;
    if (!confirm(`إرسال تفاصيل الرحلة ${flight.flightNo} إلى الطاقم؟`)) return;
    try {
      setSyncStatus?.("syncing");
      const result = await sendFlightEmail(flight);
      if (result && result.ok !== false)
        alert(`✅ تم إرسال ${result.sent ?? "?"} من ${result.total ?? "?"}`);
      else throw new Error(result?.error || "فشل");
      setSyncStatus?.("synced");
    } catch (e) {
      alert("❌ فشل: " + e.message);
      setSyncStatus?.("error");
    }
  };

  const handleSendExpiryAlerts = async () => {
    if (!confirm("إرسال تنبيهات الوثائق لكل الطاقم؟")) return;
    try {
      setSyncStatus?.("syncing");
      const result = await checkExpiryAlerts();
      if (result && result.ok !== false)
        alert(`✅ تم إرسال ${result.sent ?? "?"} تنبيه`);
      setSyncStatus?.("synced");
    } catch (e) {
      alert("❌ فشل: " + e.message);
      setSyncStatus?.("error");
    }
  };

  /* ⭐ Context Menu */
  const handleContextMenu = (e, flight) => {
    e.preventDefault();
    const hasAnyPerm = canEdit || canDelete;
    if (!hasAnyPerm) return;
    if (selectedIds.includes(flight.id) && selectedIds.length > 0) {
      setContextMenu({
        bulk: true,
        ids: selectedIds,
        x: e.clientX,
        y: e.clientY,
      });
    } else {
      setContextMenu({ flight, x: e.clientX, y: e.clientY });
    }
  };

  const handleContextAction = (action, flight) => {
    if (action === "open_notes_modal") setNotesModal(flight);
    else if (action === "edit") openEdit(flight);
    else if (action === "delete") remove(flight.id);
    else if (action === "complete_flight") setCompleteFlight(flight);
    else if (action === "gendec") onGenDec(flight);
    else if (action === "print_gendec_stamped")
      printGenDec(flight, crew, settings, { showStamp: true });
    else if (action === "print_gendec_nostamp")
      printGenDec(flight, crew, settings, { showStamp: false });
    else if (action === "send_flight_email") handleSendFlightEmail(flight);
    else if (action === "send_expiry_alerts") handleSendExpiryAlerts();
    else if (action === "bulk_complete") bulkAction("complete");
    else if (action === "bulk_gendec") handleOpenGenDecMulti();
    else if (action === "bulk_delete") bulkAction("delete");
    else if (action === "bulk_edit_legs") handleOpenBulkEditLegs();
  };

  /* ⭐ Date Label */
  const selectedDateObj = new Date(selectedDate + "T00:00:00Z");
  const months = [
    "Jan",
    "Feb",
    "Mar",
    "Apr",
    "May",
    "Jun",
    "Jul",
    "Aug",
    "Sep",
    "Oct",
    "Nov",
    "Dec",
  ];
  const dateLabel = `${selectedDateObj.getUTCDate()} ${
    months[selectedDateObj.getUTCMonth()]
  } ${selectedDateObj.getUTCFullYear()}`;

  const aircraftHasCrewAssigned =
    !draft.acft || crew.some((c) => isCrewQualifiedForAircraft(c, draft.acft));

  /* ⭐ v7.2 — تجهيز صفوف الجدول */
  const rowsToDisplay = useMemo(() => {
    const rows = [];
    filtered.forEach((f) => {
      rows.push({
        key: f.id + "-main",
        flight: f,
        isMain: true,
        legIdx: -1,
        dep: f.dep,
        arr: f.arr,
        std: f.std,
        sta: f.sta,
        acft: f.acft,
      });
      let legs = [];
      if (Array.isArray(f.legs)) legs = f.legs;
      else if (typeof f.legs === "string" && f.legs.trim()) {
        try {
          const p = JSON.parse(f.legs);
          if (Array.isArray(p)) legs = p;
        } catch {}
      }
      legs.forEach((leg, idx) => {
        rows.push({
          key: f.id + "-leg-" + idx,
          flight: f,
          isMain: false,
          legIdx: idx,
          dep: leg.dep || "",
          arr: leg.arr || "",
          std: leg.std || "",
          sta: leg.sta || "",
          acft: leg.acft || f.acft || "",
        });
      });
    });
    return rows;
  }, [filtered]);

  return (
    <div className="space-y-3 fade-in">
      {/* ═══ TOOLBAR ═══ */}
      <div
        className="rounded-lg overflow-hidden mb-3 shadow-sm border theme-transition"
        style={{
          backgroundColor: "var(--bg-card)",
          borderColor: "var(--border-default)",
        }}
      >
        <div className="flex flex-wrap items-center gap-3 p-2">
          <div
            className="flex rounded-md p-1 border shadow-inner"
            style={{
              backgroundColor: "var(--bg-app)",
              borderColor: "var(--border-default)",
            }}
          >
            <button
              onClick={() => setViewMode("table")}
              className={`flex items-center gap-2 px-3 py-1.5 rounded text-xs font-bold transition ${
                viewMode === "table" ? "shadow-sm" : ""
              }`}
              style={
                viewMode === "table"
                  ? {
                      backgroundColor: "var(--bg-card)",
                      color: "var(--brand-primary)",
                    }
                  : { color: "var(--text-muted)" }
              }
            >
              <Table className="w-4 h-4" /> TABLE
            </button>
            <button
              onClick={() => setViewMode("calendar")}
              className={`flex items-center gap-2 px-3 py-1.5 rounded text-xs font-bold transition ${
                viewMode === "calendar" ? "shadow-sm" : ""
              }`}
              style={
                viewMode === "calendar"
                  ? {
                      backgroundColor: "var(--bg-card)",
                      color: "var(--brand-primary)",
                    }
                  : { color: "var(--text-muted)" }
              }
            >
              <CalendarDays className="w-4 h-4" /> CALENDAR
            </button>
            <button
              onClick={() => setViewMode("timeline")}
              className={`flex items-center gap-2 px-3 py-1.5 rounded text-xs font-bold transition ${
                viewMode === "timeline" ? "shadow-sm" : ""
              }`}
              style={
                viewMode === "timeline"
                  ? {
                      backgroundColor: "var(--bg-card)",
                      color: "var(--brand-primary)",
                    }
                  : { color: "var(--text-muted)" }
              }
            >
              <List className="w-4 h-4" /> TIMELINE
            </button>
          </div>

          <div
            className="flex items-center rounded-md border shadow-sm"
            style={{
              backgroundColor: "var(--bg-card)",
              borderColor: "var(--border-default)",
            }}
          >
            <button
              onClick={() => shiftDate(-rangeDays)}
              className="px-2 py-1.5 border-r hover:opacity-80"
              style={{
                color: "var(--text-muted)",
                borderColor: "var(--border-default)",
              }}
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <button
              onClick={goToday}
              className="px-3 py-1.5 text-xs font-bold hover:opacity-80"
              style={{ color: "var(--text-primary)" }}
            >
              TODAY
            </button>
            <button
              onClick={() => shiftDate(rangeDays)}
              className="px-2 py-1.5 border-l hover:opacity-80"
              style={{
                color: "var(--text-muted)",
                borderColor: "var(--border-default)",
              }}
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>

          <div
            className="flex items-center rounded-md border px-2 py-1 shadow-sm"
            style={{
              backgroundColor: "var(--bg-card)",
              borderColor: "var(--border-default)",
            }}
          >
            <Calendar
              className="w-4 h-4 mr-2"
              style={{ color: "var(--text-muted)" }}
            />
            <input
              type="date"
              value={selectedDate}
              onChange={(e) => setSelectedDate(e.target.value)}
              className="bg-transparent text-xs font-bold outline-none"
              style={{ color: "var(--text-primary)" }}
            />
          </div>

          <button
            onClick={() => setTimeMode((m) => (m === "UTC" ? "LOCAL" : "UTC"))}
            className="flex items-center gap-1 px-3 py-1.5 rounded-md border shadow-sm text-xs font-bold hover:bg-slate-50 dark:hover:bg-slate-800"
            style={{
              backgroundColor: "var(--bg-card)",
              borderColor: "var(--border-default)",
              color: "var(--text-primary)",
            }}
          >
            <Globe
              className="w-3.5 h-3.5"
              style={{ color: "var(--text-muted)" }}
            />{" "}
            {timeMode}
          </button>

          <select
            value={rangeDays}
            onChange={(e) => setRangeDays(+e.target.value)}
            className="px-2 py-1.5 rounded-md border shadow-sm text-xs font-bold outline-none"
            style={{
              backgroundColor: "var(--bg-card)",
              borderColor: "var(--border-default)",
              color: "var(--text-primary)",
            }}
          >
            <option value={1}>1 day</option>
            <option value={3}>3 days</option>
            <option value={7}>7 days</option>
            <option value={14}>14 days</option>
            <option value={30}>30 days</option>
          </select>

          <select
            value={acftFilter}
            onChange={(e) => setAcftFilter(e.target.value)}
            className="px-2 py-1.5 rounded-md border shadow-sm text-xs font-bold outline-none max-w-[120px]"
            style={{
              backgroundColor: "var(--bg-card)",
              borderColor: "var(--border-default)",
              color: "var(--text-primary)",
            }}
          >
            <option value="">All Aircraft</option>
            {fleet.map((a) => (
              <option key={a.id} value={a.reg}>
                {a.reg}
              </option>
            ))}
          </select>

          <div className="flex items-center gap-2 ml-auto">
            {/* ⭐ v7.6 — مؤشر بسيط فقط */}
            {selectedIds.length > 0 && (
              <div
                className="flex items-center gap-1 px-2 py-1.5 rounded-md text-[11px] font-bold border"
                style={{
                  backgroundColor: "var(--bg-app)",
                  color: "var(--brand-primary)",
                  borderColor: "var(--border-default)",
                }}
              >
                {selectedIds.length} ✓ {t.selected || "محدد"}
              </div>
            )}

            <button
              onClick={() => setShowFilters(!showFilters)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-bold transition border"
              style={{
                backgroundColor: "var(--bg-app)",
                color: "var(--brand-primary)",
                borderColor: "var(--border-default)",
              }}
            >
              <Filter className="w-3.5 h-3.5" /> FILTER
            </button>

            {canCreate && (
              <button
                onClick={openNew}
                className="flex items-center gap-1.5 px-4 py-1.5 text-white rounded-md text-xs font-bold shadow-sm transition"
                style={{ background: "var(--brand-gradient)" }}
              >
                <Plus className="w-4 h-4" /> ADD FLIGHT
              </button>
            )}
            <button
              className="p-1.5 rounded-md"
              style={{ color: "var(--text-muted)" }}
            >
              <MoreHorizontal className="w-5 h-5" />
            </button>
          </div>
        </div>

        {showFilters && (
          <div
            className="p-2 grid grid-cols-2 md:grid-cols-4 gap-2 border-t"
            style={{
              backgroundColor: "var(--bg-app)",
              borderColor: "var(--border-default)",
            }}
          >
            <div className="relative">
              <Search
                className="w-3.5 h-3.5 absolute top-1/2 -translate-y-1/2 left-2"
                style={{ color: "var(--text-muted)" }}
              />
              <input
                value={q}
                onChange={(e) => setQ(e.target.value)}
                placeholder="Search flights..."
                className="w-full pl-8 pr-2 py-1.5 text-xs rounded border outline-none"
                style={{
                  backgroundColor: "var(--bg-card)",
                  borderColor: "var(--border-default)",
                  color: "var(--text-primary)",
                }}
              />
            </div>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="w-full px-2 py-1.5 text-xs rounded border outline-none"
              style={{
                backgroundColor: "var(--bg-card)",
                borderColor: "var(--border-default)",
                color: "var(--text-primary)",
              }}
            >
              <option value="">All Statuses</option>
              {STATUS_LIST.map((s) => (
                <option key={s}>{s}</option>
              ))}
            </select>
            <div className="flex items-end md:col-span-2">
              <button
                onClick={() => {
                  setQ("");
                  setStatusFilter("");
                  setAcftFilter("");
                  setTypeFilter("");
                }}
                className="w-full px-3 py-1.5 rounded text-xs font-bold bg-rose-100 text-rose-700 hover:bg-rose-200 transition"
              >
                Clear Filters
              </button>
            </div>
          </div>
        )}

        <div
          className="px-3 py-1.5 flex flex-wrap items-center gap-3 text-[10px] border-t"
          style={{
            color: "var(--text-muted)",
            borderColor: "var(--border-default)",
          }}
        >
          <span className="flex items-center gap-1">
            <span className="w-2.5 h-2.5 rounded-full bg-blue-500" /> Upcoming (
            {counters.upcoming})
          </span>
          <span className="flex items-center gap-1">
            <span className="w-3 h-3 rounded-full bg-emerald-500 ring-2 ring-emerald-300 flex items-center justify-center">
              <span className="text-white text-[6px] font-bold">✓</span>
            </span>
            Completed ({counters.completed})
          </span>
          <span className="flex items-center gap-1">
            <span className="w-2.5 h-2.5 rounded-full bg-slate-400" /> Past (
            {counters.past})
          </span>
          <span
            className="ml-auto font-bold"
            style={{ color: "var(--text-primary)" }}
          >
            Showing {rowsToDisplay.length} / {counters.all}
          </span>
        </div>
      </div>

      {/* ═══ TABLE VIEW ═══ */}
      {viewMode === "table" && (
        <div
          className="overflow-x-auto rounded-lg border shadow-sm"
          style={{
            backgroundColor: "var(--bg-card)",
            borderColor: "var(--border-default)",
          }}
        >
          <table
            className="w-full text-xs"
            style={{ fontFamily: "ui-monospace, monospace" }}
          >
            <thead
              className="text-[11px] uppercase tracking-wider"
              style={{
                backgroundColor: "var(--bg-sidebar)",
                color: "var(--text-muted)",
              }}
            >
              <tr>
                <th
                  className="px-2 py-2 border-r w-8"
                  style={{ borderColor: "var(--border-default)" }}
                ></th>
                <th
                  className="px-2 py-2 border-r w-8 text-center"
                  style={{ borderColor: "var(--border-default)" }}
                >
                  <input
                    type="checkbox"
                    className="w-3.5 h-3.5 cursor-pointer"
                    checked={
                      filtered.length > 0 &&
                      selectedIds.length === filtered.length
                    }
                    onChange={toggleSelectAll}
                  />
                </th>
                <th
                  className="px-2 py-2 border-r text-start font-bold"
                  style={{ borderColor: "var(--border-default)" }}
                >
                  {t.flightNo}
                </th>
                <th
                  className="px-2 py-2 border-r text-center font-bold"
                  style={{ borderColor: "var(--border-default)" }}
                >
                  TYPE
                </th>
                <th
                  className="px-2 py-2 border-r text-center font-bold"
                  style={{ borderColor: "var(--border-default)" }}
                >
                  DAY
                </th>
                <th
                  className="px-2 py-2 border-r text-start font-bold"
                  style={{ borderColor: "var(--border-default)" }}
                >
                  DATE
                </th>
                <th
                  className="px-2 py-2 border-r text-center font-bold"
                  style={{ borderColor: "var(--border-default)" }}
                >
                  STD
                </th>
                <th
                  className="px-2 py-2 border-r text-start font-bold"
                  style={{ borderColor: "var(--border-default)" }}
                >
                  ADEP
                </th>
                <th
                  className="px-2 py-2 border-r text-start font-bold"
                  style={{ borderColor: "var(--border-default)" }}
                >
                  ADES
                </th>
                <th
                  className="px-2 py-2 border-r text-center font-bold"
                  style={{ borderColor: "var(--border-default)" }}
                >
                  STA
                </th>
                <th
                  className="px-2 py-2 border-r text-center font-bold"
                  style={{ borderColor: "var(--border-default)" }}
                >
                  ACFT
                </th>
                {positionsToShow.map((pos) => (
                  <th
                    key={pos}
                    className="px-2 py-2 border-r text-center font-bold"
                    style={{ borderColor: "var(--border-default)" }}
                  >
                    {POSITION_LABELS[pos]?.short || pos.toUpperCase()}
                  </th>
                ))}
                <th className="px-2 py-2 text-start font-bold">NOTES</th>
                <th
                  className="px-2 py-2 border-r text-center font-bold w-20"
                  style={{ borderColor: "var(--border-default)" }}
                >
                  GD
                </th>
              </tr>
            </thead>
            <tbody>
              {rowsToDisplay.length === 0 ? (
                <tr>
                  <td
                    colSpan={13 + positionsToShow.length}
                    className="p-10 text-center text-sm"
                    style={{ color: "var(--text-muted)" }}
                  >
                    <div className="flex flex-col items-center gap-2">
                      <span className="text-3xl">📭</span>
                      <span>
                        {t.noFlights} — {dateLabel}
                      </span>
                    </div>
                  </td>
                </tr>
              ) : (
                rowsToDisplay.map((row) => {
                  const f = row.flight;
                  const past = isPast(f);
                  const completed = isCompleted(f);
                  const { day, date } = fmtDateParts(row.std, timeMode);
                  const isSelected = selectedIds.includes(f.id);
                  const ft = getFlightType(f.flightType);
                  const isLeg = !row.isMain;

                  return (
                    <tr
                      key={row.key}
                      onContextMenu={(e) => handleContextMenu(e, f)}
                      className={`cursor-context-menu transition-colors border-b ${
                        isSelected
                          ? "bg-blue-50 dark:bg-blue-900/20"
                          : isLeg
                          ? "bg-slate-50/70 dark:bg-slate-900/20"
                          : "hover:bg-slate-50 dark:hover:bg-slate-800"
                      }`}
                      style={{ borderColor: "var(--border-default)" }}
                    >
                      <td
                        className="px-2 py-1.5 border-r"
                        style={{ borderColor: "var(--border-default)" }}
                      >
                        <div className="flex items-center justify-center">
                          {isLeg ? (
                            <span
                              className="text-[10px] font-bold"
                              style={{ color: "var(--brand-primary)" }}
                            >
                              ↳{row.legIdx + 1}
                            </span>
                          ) : completed ? (
                            <span className="w-3.5 h-3.5 rounded-full bg-emerald-500 ring-2 ring-emerald-300 flex items-center justify-center shadow-sm">
                              <span className="text-white text-[7px] font-bold">
                                ✓
                              </span>
                            </span>
                          ) : past ? (
                            <span className="w-2.5 h-2.5 rounded-full bg-slate-400" />
                          ) : (
                            <span className="w-2.5 h-2.5 rounded-full bg-blue-500" />
                          )}
                        </div>
                      </td>
                      <td
                        className="px-2 py-1.5 border-r text-center"
                        style={{ borderColor: "var(--border-default)" }}
                      >
                        <input
                          type="checkbox"
                          checked={isSelected}
                          onChange={() => toggleSelect(f.id)}
                          className="w-3.5 h-3.5 cursor-pointer"
                        />
                      </td>
                      <td
                        className="px-2 py-1.5 border-r text-center font-bold"
                        style={{
                          borderColor: "var(--border-default)",
                          color: "var(--text-primary)",
                        }}
                      >
                        {f.flightNo}
                        {completed && (
                          <span className="ms-1 text-[9px] text-emerald-500">
                            ✓
                          </span>
                        )}
                      </td>
                      <td
                        className="px-2 py-1.5 border-r text-center"
                        style={{ borderColor: "var(--border-default)" }}
                      >
                        <span
                          className="inline-flex items-center justify-center gap-1 px-1.5 py-0.5 rounded-full text-[10px] font-bold border"
                          style={{
                            backgroundColor: "var(--bg-app)",
                            color: "var(--brand-primary)",
                            borderColor: "var(--border-default)",
                          }}
                        >
                          {/* ⭐ v7.7 — أيقونة آمنة */}
                          <FlightTypeIcon ft={ft} size="w-3 h-3" />
                          <span className="hidden md:inline">{ft.key}</span>
                        </span>
                      </td>
                      <td
                        className="px-2 py-1.5 border-r text-center"
                        style={{
                          borderColor: "var(--border-default)",
                          color: "var(--text-muted)",
                        }}
                      >
                        {day}
                      </td>
                      <td
                        className="px-2 py-1.5 border-r whitespace-nowrap"
                        style={{
                          borderColor: "var(--border-default)",
                          color: "var(--text-muted)",
                        }}
                      >
                        {date}
                      </td>
                      <td
                        className="px-2 py-1.5 border-r text-center font-mono font-bold"
                        style={{
                          borderColor: "var(--border-default)",
                          color: "var(--text-primary)",
                        }}
                      >
                        {fmtTime(row.std, timeMode)}
                      </td>
                      <td
                        className="px-2 py-1.5 border-r font-mono font-bold"
                        style={{
                          borderColor: "var(--border-default)",
                          color: "var(--brand-primary)",
                        }}
                      >
                        {row.dep}
                      </td>
                      <td
                        className="px-2 py-1.5 border-r text-center"
                        style={{ borderColor: "var(--border-default)" }}
                      >
                        <span
                          className={`inline-block px-1.5 py-0.5 rounded text-[11px] font-bold ${
                            row.arr === "HLWF"
                              ? "bg-rose-100 text-rose-700 border border-rose-300"
                              : ""
                          }`}
                          style={{
                            color:
                              row.arr === "HLWF"
                                ? undefined
                                : "var(--brand-primary)",
                          }}
                        >
                          {row.arr}
                        </span>
                      </td>
                      <td
                        className="px-2 py-1.5 border-r text-center font-mono"
                        style={{
                          borderColor: "var(--border-default)",
                          color: "var(--text-muted)",
                        }}
                      >
                        {fmtTime(row.sta, timeMode)}
                      </td>
                      <td
                        className="px-2 py-1.5 border-r text-center font-mono font-bold"
                        style={{
                          borderColor: "var(--border-default)",
                          backgroundColor: "rgba(245, 158, 11, 0.1)",
                          color: "var(--text-primary)",
                        }}
                      >
                        {row.acft}
                      </td>
                      {positionsToShow.map((pos) => {
                        const members = crewByPosDetailed(f, pos);
                        return (
                          <td
                            key={pos}
                            className="px-2 py-1.5 border-r text-center"
                            style={{ borderColor: "var(--border-default)" }}
                          >
                            {members.length > 0 ? (
                              <div className="flex flex-col items-center gap-0.5">
                                {members.map((m, idx) => {
                                  const sc = getShortCodeWithColor(m, pos);
                                  return (
                                    <span
                                      key={idx}
                                      className={`px-1.5 py-0.5 rounded text-[9px] font-bold border ${sc.color}`}
                                      title={`${m.fullName} (${m.role}${
                                        pos !== m.role ? ` @ ${pos}` : ""
                                      })`}
                                    >
                                      {sc.code}
                                    </span>
                                  );
                                })}
                              </div>
                            ) : (
                              <span
                                style={{
                                  color: "var(--text-muted)",
                                  opacity: 0.4,
                                }}
                              >
                                —
                              </span>
                            )}
                          </td>
                        );
                      })}
                      <td className="px-2 py-1.5 min-w-[180px]">
                        <div className="flex items-center gap-1">
                          {f.notes ? (
                            <span
                              className="text-[10px] truncate max-w-[120px]"
                              style={{ color: "var(--text-muted)" }}
                              title={f.notes}
                            >
                              {f.notes}
                            </span>
                          ) : (
                            <span
                              className="text-[10px] italic"
                              style={{
                                color: "var(--text-muted)",
                                opacity: 0.5,
                              }}
                            >
                              —
                            </span>
                          )}
                          {f.permits && (
                            <span className="text-[9px] px-1 rounded bg-amber-100 text-amber-700 border border-amber-300">
                              P
                            </span>
                          )}
                          {f.services && (
                            <span className="text-[9px] px-1 rounded bg-purple-100 text-purple-700 border border-purple-300">
                              S
                            </span>
                          )}
                        </div>
                      </td>
                      <td
                        className="px-2 py-1.5 border-r"
                        style={{ borderColor: "var(--border-default)" }}
                      >
                        <div className="flex items-center justify-center gap-1">
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              printGenDec(f, crew, settings, {
                                showStamp: true,
                              });
                            }}
                            className="p-1.5 rounded bg-emerald-50 text-emerald-600 hover:bg-emerald-100 transition border border-emerald-200"
                            title="With stamp"
                          >
                            <Stamp className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              printGenDec(f, crew, settings, {
                                showStamp: false,
                              });
                            }}
                            className="p-1.5 rounded bg-slate-100 text-slate-600 hover:bg-slate-200 transition border border-slate-300"
                            title="Without stamp"
                          >
                            <FileX className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      )}

      {/* ═══ CALENDAR VIEW ═══ */}
      {viewMode === "calendar" && (
        <CalendarView
          flights={flights}
          selectedDate={selectedDate}
          setSelectedDate={setSelectedDate}
          timeMode={timeMode}
          isPast={isPast}
          crew={crew}
          onSelectFlight={(flight) => setNotesModal(flight)}
        />
      )}

      {/* ═══ TIMELINE VIEW ═══ */}
      {viewMode === "timeline" && (
        <TimelineView flights={filtered} timeMode={timeMode} isPast={isPast} />
      )}

      {/* ═══ Context Menu ═══ */}
      {contextMenu && (
        <FlightContextMenu
          flight={
            contextMenu.bulk
              ? { bulk: true, ids: contextMenu.ids }
              : contextMenu.flight
          }
          x={contextMenu.x}
          y={contextMenu.y}
          user={user}
          onClose={() => setContextMenu(null)}
          onAction={handleContextAction}
        />
      )}

      {/* Modals */}
      {notesModal && (
        <FlightNotesModal
          flight={notesModal}
          onClose={() => setNotesModal(null)}
          onSave={saveNotesAndPermits}
        />
      )}

      {completeFlight && (
        <CompleteFlightModal
          flight={completeFlight}
          fleet={fleet}
          onClose={() => setCompleteFlight(null)}
          onSave={saveCompleteFlight}
        />
      )}

      {/* ⭐ v7.6 — GenDec Multi Modal (Pagination) */}
      {genDecMultiFlights && (
        <GenDecMultiModal
          flights={genDecMultiFlights}
          crew={crew}
          settings={settings}
          onClose={() => setGenDecMultiFlights(null)}
        />
      )}

      {/* ⭐ v7.6 — Bulk Edit Legs Modal */}
      {bulkEditLegsFlights && (
        <BulkEditLegsModal
          flights={bulkEditLegsFlights}
          fleet={fleet}
          onClose={() => setBulkEditLegsFlights(null)}
          onSave={saveBulkEditLegs}
        />
      )}

      {/* ═══ Edit Modal ═══ */}
      <Modal
        open={!!editing}
        title={editing === "new" ? t.addFlight : t.editFlight}
        onClose={() => setEditing(null)}
        wide
        footer={
          <>
            <button
              onClick={() => setEditing(null)}
              className="px-4 py-2 rounded-lg text-sm font-bold border"
              style={{
                borderColor: "var(--border-default)",
                color: "var(--text-muted)",
              }}
            >
              {t.cancel}
            </button>
            <button
              onClick={save}
              className="px-4 py-2 rounded-lg text-sm font-bold text-white flex items-center gap-2 shadow-sm"
              style={{ background: "var(--brand-gradient)" }}
            >
              <Save className="w-4 h-4" /> {t.save}
            </button>
          </>
        }
      >
        <div className="space-y-4">
          <div className="grid md:grid-cols-3 gap-3">
            <Field label={t.flightNo}>
              <Input
                value={draft.flightNo || ""}
                onChange={(e) =>
                  setDraft({ ...draft, flightNo: e.target.value })
                }
                placeholder=""
                autoComplete="off"
              />
            </Field>
            <Field label={t.flightType}>
              <Select
                value={draft.flightType || "SCHEDULED"}
                onChange={(e) =>
                  setDraft({ ...draft, flightType: e.target.value })
                }
              >
                {FLIGHT_TYPES.map((ft) => (
                  <option key={ft.key} value={ft.key}>
                    {t[ft.key.toLowerCase()] || ft.ar || ft.key}
                  </option>
                ))}
              </Select>
            </Field>
            <Field label="Date">
              <Input
                type="date"
                value={draft.date || ""}
                onChange={(e) => setDraft({ ...draft, date: e.target.value })}
              />
            </Field>
          </div>

          <div
            className="p-3 rounded-xl border"
            style={{
              backgroundColor: "var(--bg-app)",
              borderColor: "var(--border-default)",
            }}
          >
            <h4
              className="text-xs font-bold mb-2 flex items-center gap-2"
              style={{ color: "var(--text-primary)" }}
            >
              <PlaneTakeoff className="w-4 h-4" /> Sector 1 (Main)
            </h4>
            <div className="grid md:grid-cols-4 gap-3">
              <Field label={t.dep}>
                <AirportInput
                  value={draft.dep || ""}
                  onChange={(v) => setDraft({ ...draft, dep: v })}
                />
              </Field>
              <Field label={t.arr}>
                <AirportInput
                  value={draft.arr || ""}
                  onChange={(v) => setDraft({ ...draft, arr: v })}
                />
              </Field>
              <Field label="STD (24h)">
                <Input
                  type="time"
                  value={draft.std || ""}
                  onChange={(e) => setDraft({ ...draft, std: e.target.value })}
                />
              </Field>
              <Field label="STA (24h)">
                <Input
                  type="time"
                  value={draft.sta || ""}
                  onChange={(e) => setDraft({ ...draft, sta: e.target.value })}
                />
              </Field>
            </div>
          </div>

          {(draft.legs || []).map((leg, idx) => (
            <div
              key={idx}
              className="p-3 rounded-xl border relative"
              style={{
                backgroundColor: "var(--bg-app)",
                borderColor: "var(--border-default)",
              }}
            >
              <div className="flex justify-between items-center mb-2">
                <h4
                  className="text-xs font-bold flex items-center gap-2"
                  style={{ color: "var(--text-primary)" }}
                >
                  <PlaneTakeoff className="w-4 h-4" /> Sector {idx + 2}
                </h4>
                <button
                  onClick={() => removeLeg(idx)}
                  className="p-1 text-rose-500 hover:bg-rose-50 rounded"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
              <div className="grid md:grid-cols-5 gap-3">
                <Field label={t.dep}>
                  <AirportInput
                    value={leg.dep || ""}
                    onChange={(v) => updateLeg(idx, { dep: v })}
                  />
                </Field>
                <Field label={t.arr}>
                  <AirportInput
                    value={leg.arr || ""}
                    onChange={(v) => updateLeg(idx, { arr: v })}
                  />
                </Field>
                <Field label="Date">
                  <Input
                    type="date"
                    value={leg.date || draft.date || ""}
                    onChange={(e) => updateLeg(idx, { date: e.target.value })}
                  />
                </Field>
                <Field label="STD (24h)">
                  <Input
                    type="time"
                    value={leg.std || ""}
                    onChange={(e) => updateLeg(idx, { std: e.target.value })}
                  />
                </Field>
                <Field label="STA (24h)">
                  <Input
                    type="time"
                    value={leg.sta || ""}
                    onChange={(e) => updateLeg(idx, { sta: e.target.value })}
                  />
                </Field>
              </div>
            </div>
          ))}

          <button
            onClick={addLeg}
            className="w-full py-2 rounded-lg border-2 border-dashed text-xs font-bold flex items-center justify-center gap-2 transition hover:bg-blue-50"
            style={{
              borderColor: "var(--border-default)",
              color: "var(--brand-primary)",
            }}
          >
            <Plus className="w-4 h-4" /> Add Another Sector (Leg)
          </button>

          <div className="grid md:grid-cols-3 gap-3">
            <Field label={t.acft}>
              <Select
                value={draft.acft || ""}
                onChange={(e) => setDraft({ ...draft, acft: e.target.value })}
              >
                <option value="">—</option>
                {fleet.map((a) => (
                  <option key={a.id} value={a.reg}>
                    {a.reg} ({a.type})
                  </option>
                ))}
              </Select>
            </Field>
            <Field label={t.altn}>
              <AirportInput
                value={draft.altn || ""}
                onChange={(v) => setDraft({ ...draft, altn: v })}
              />
            </Field>
            <Field label={t.altn2}>
              <AirportInput
                value={draft.altn2 || ""}
                onChange={(v) => setDraft({ ...draft, altn2: v })}
              />
            </Field>
          </div>

          <div className="grid md:grid-cols-3 gap-3">
            <Field label={`${t.freeNotes || "Notes"}`}>
              <textarea
                value={draft.notes || ""}
                onChange={(e) => setDraft({ ...draft, notes: e.target.value })}
                rows="2"
                className="w-full px-3 py-2 rounded-lg text-sm border outline-none focus:ring-2 focus:ring-blue-400"
                style={{
                  borderColor: "var(--border-default)",
                  color: "var(--text-primary)",
                  backgroundColor: "var(--bg-card)",
                }}
              />
            </Field>
            <Field label={`${t.permits || "Permits"}`}>
              <textarea
                value={draft.permits || ""}
                onChange={(e) =>
                  setDraft({ ...draft, permits: e.target.value })
                }
                rows="2"
                className="w-full px-3 py-2 rounded-lg text-sm border outline-none focus:ring-2 focus:ring-blue-400"
                style={{
                  borderColor: "var(--border-default)",
                  color: "var(--text-primary)",
                  backgroundColor: "var(--bg-card)",
                }}
              />
            </Field>
            <Field label={`${t.handling || "Services"}`}>
              <textarea
                value={draft.services || ""}
                onChange={(e) =>
                  setDraft({ ...draft, services: e.target.value })
                }
                rows="2"
                className="w-full px-3 py-2 rounded-lg text-sm border outline-none focus:ring-2 focus:ring-blue-400"
                style={{
                  borderColor: "var(--border-default)",
                  color: "var(--text-primary)",
                  backgroundColor: "var(--bg-card)",
                }}
              />
            </Field>
          </div>

          {canAssignCrew || canEdit ? (
            <section>
              <div className="flex justify-between items-center mb-3">
                <h4
                  className="text-sm font-bold"
                  style={{ color: "var(--text-primary)" }}
                >
                  {t.crewMembers}
                </h4>
                <button
                  onClick={addSlot}
                  className="flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-bold text-white shadow-sm transition"
                  style={{ background: "var(--brand-gradient)" }}
                >
                  <Plus className="w-3.5 h-3.5" /> {t.addPosition}
                </button>
              </div>
              {draft.acft && !aircraftHasCrewAssigned && (
                <div className="p-3 rounded-lg mb-3 text-xs flex items-start gap-2 bg-amber-50 border border-amber-300 text-amber-700">
                  <ShieldAlert className="w-4 h-4 flex-shrink-0 mt-0.5" />
                  <div className="flex-1">
                    <div className="font-bold mb-0.5">
                      {t.noCrewForAircraft ||
                        "لا يوجد طاقم معيَّن على هذه الطائرة"}
                    </div>
                    <div className="text-[10px] opacity-80">
                      {t.noCrewForAircraftHint ||
                        `يرجى تعيين أعضاء الطاقم للطائرة ${draft.acft} من صفحة Crew → Edit → Aircraft`}
                    </div>
                  </div>
                </div>
              )}
              {safeArray(draft.crewSlots).map((slot, i) => {
                const usedPositions = safeArray(draft.crewSlots)
                  .filter((_, idx) => idx !== i)
                  .map((s) => s.position)
                  .filter(Boolean);
                const allowedRoles = getAllowedRoles(slot.position);
                const availableCrew = crew.filter((c) => {
                  if (c.status !== "active") return false;
                  if (draft.acft && !isCrewQualifiedForAircraft(c, draft.acft))
                    return false;
                  if (allowedRoles.length > 0) {
                    const memberRoles = getMemberAllRoles(c);
                    if (!memberRoles.some((r) => allowedRoles.includes(r)))
                      return false;
                  }
                  return true;
                });
                const availablePositions = POSITION_OPTIONS.filter(
                  (p) =>
                    !usedPositions.includes(p.key) || p.key === slot.position
                );
                return (
                  <div
                    key={i}
                    className="grid grid-cols-12 gap-2 items-center p-2 rounded-lg mb-2 border"
                    style={{
                      backgroundColor: "var(--bg-app)",
                      borderColor: "var(--border-default)",
                    }}
                  >
                    <div className="col-span-4">
                      <Select
                        value={slot.position || ""}
                        onChange={(e) =>
                          updateSlot(i, { position: e.target.value })
                        }
                      >
                        {availablePositions.map((p) => (
                          <option key={p.key} value={p.key}>
                            {p.short || p.key}
                          </option>
                        ))}
                      </Select>
                    </div>
                    <div className="col-span-7">
                      <Select
                        value={slot.crewId || ""}
                        onChange={(e) =>
                          updateSlot(i, { crewId: e.target.value })
                        }
                      >
                        <option value="">
                          {availableCrew.length === 0
                            ? t.noAvailableCrew || "لا يوجد طاقم متاح"
                            : t.selectCrew}
                        </option>
                        {availableCrew.map((c) => {
                          const memberAircrafts = getCrewAssignedAircrafts(c);
                          const otherSlot = safeArray(draft.crewSlots).find(
                            (s, idx) => idx !== i && s.crewId === c.id
                          );
                          const alreadyAssigned = otherSlot
                            ? ` (⚠️ ${otherSlot.position})`
                            : "";
                          return (
                            <option key={c.id} value={c.id}>
                              {c.fullName}
                              {memberAircrafts.length > 0
                                ? ` — ${memberAircrafts.join(", ")}`
                                : ""}
                              {alreadyAssigned}
                            </option>
                          );
                        })}
                      </Select>
                    </div>
                    <div className="col-span-1 text-end">
                      <button
                        type="button"
                        onClick={() => removeSlot(i)}
                        className="p-1.5 rounded-lg bg-rose-500/20 text-rose-400 hover:bg-rose-500/30 transition"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                );
              })}
            </section>
          ) : null}
        </div>
      </Modal>
    </div>
  );
}

export default ScheduleBoard;
