/* ═══════════════════════════════════════════════════════════
 * SETTINGS MODULE — Theme-aware (CSS Variables) + Modern Design
 * v9.0 — FINAL: Country + CAMO/Permits/Catering + navLayout fix
 * ═══════════════════════════════════════════════════════════ */
import React, { useState, useEffect, useRef } from "react";
import {
  Camera,
  Upload,
  Save,
  Lock,
  Plane,
  Settings as SettingsIcon,
  Users as UsersIcon,
  Key,
  Shield,
  FileText,
  MessageCircle,
  Volume2,
  VolumeX,
  Bell,
  BellOff,
  Hash,
  Layout,
  PanelLeft,
  LayoutDashboard,
  Calendar,
  Clock,
  BarChart3,
  CalendarDays,
  Zap,
  Plane as PlaneIcon,
  GraduationCap,
  Navigation,
  Users,
  Sparkles,
  Image as ImageIcon,
  Mail,
  ListChecks,
  Palette,
  Globe,
  Check,
  ShieldCheck,
  FileSignature,
  UtensilsCrossed,
} from "lucide-react";
import { useT, useAuth } from "../contexts";
import { Field } from "../components/ui/Field";
import { Input } from "../components/ui/Input";
import { Select } from "../components/ui/Select";
import { settingsAPI, uploadFile } from "../api";
import { can as checkPerm } from "../config/permissions";
import { SOUND_TYPES, testSound } from "../utils/sounds";
import { useSounds } from "../hooks/useSounds";
import {
  GLOBAL_THEMES,
  DEFAULT_GLOBAL_THEME,
  DEFAULT_PORTAL_THEME,
} from "../config/constants";

/* ⭐ Modules */
import { UsersModule } from "./UsersModule";
import { RolesModule } from "./RolesModule";
import { LoginHistoryModule } from "./LoginHistoryModule";
import { AuditLogModule } from "./AuditLogModule";
import { WhatsAppModule } from "./WhatsAppModule";
import { EmailModule } from "./EmailModule";
import { PositionsSettingsTab } from "./PositionsSettingsTab";

/* ═══ Tabs ═══ */
const TABS = [
  {
    id: "general",
    icon: SettingsIcon,
    label_en: "General",
    label_ar: "عام",
    perm: "settings.general_view",
  },
  {
    id: "positions",
    icon: ListChecks,
    label_en: "Positions",
    label_ar: "الوظائف",
    perm: "settings.positions_view",
  },
  {
    id: "appearance",
    icon: Layout,
    label_en: "Appearance",
    label_ar: "المظهر",
    perm: "settings.appearance_view",
  },
  {
    id: "sounds",
    icon: Volume2,
    label_en: "Sounds",
    label_ar: "الأصوات",
    perm: "settings.sounds_view",
  },
  {
    id: "email",
    icon: Mail,
    label_en: "Email",
    label_ar: "البريد الإلكتروني",
    perm: "email.view",
  },
  {
    id: "users",
    icon: UsersIcon,
    label_en: "Users",
    label_ar: "المستخدمون",
    perm: "users.view",
  },
  {
    id: "roles",
    icon: Key,
    label_en: "Roles",
    label_ar: "الأدوار",
    perm: "users.view",
  },
  {
    id: "login-history",
    icon: Shield,
    label_en: "Login History",
    label_ar: "سجل الدخول",
    perm: "security.login_history",
  },
  {
    id: "audit-log",
    icon: FileText,
    label_en: "Audit Log",
    label_ar: "سجل النشاطات",
    perm: "security.audit_log",
  },
  {
    id: "whatsapp",
    icon: MessageCircle,
    label_en: "WhatsApp",
    label_ar: "واتساب",
    perm: "whatsapp.view",
  },
];

/* ═══ ALL TABS CONFIG ═══ */
const ALL_TABS_CONFIG = [
  {
    id: "dashboard",
    icon: LayoutDashboard,
    label_en: "Dashboard",
    label_ar: "الرئيسية",
    perm: "schedule.view",
  },
  {
    id: "schedule",
    icon: Calendar,
    label_en: "Schedule",
    label_ar: "الجدول",
    perm: "schedule.view",
  },
  {
    id: "ftl",
    icon: Clock,
    label_en: "FTL",
    label_ar: "ساعات الطيران",
    perm: "ftl.view",
  },
  {
    id: "reports",
    icon: BarChart3,
    label_en: "Reports",
    label_ar: "التقارير",
    perm: "reports.view",
  },
  {
    id: "roster",
    icon: CalendarDays,
    label_en: "Roster",
    label_ar: "الجدول الشهري",
    perm: "roster.view",
  },
  {
    id: "standby",
    icon: Zap,
    label_en: "Standby",
    label_ar: "الاحتياطي",
    perm: "standby.view",
  },
  {
    id: "leave",
    icon: PlaneIcon,
    label_en: "Leave",
    label_ar: "الإجازات",
    perm: "leave.view",
  },
  {
    id: "training",
    icon: GraduationCap,
    label_en: "Training",
    label_ar: "التدريب",
    perm: "training.view",
  },
  {
    id: "tracking",
    icon: Navigation,
    label_en: "Flight Following",
    label_ar: "متابعة الرحلات",
    perm: "tracking.view",
  },
  {
    id: "charts",
    icon: BarChart3,
    label_en: "Charts",
    label_ar: "الرسوم البيانية",
    perm: "charts.view",
  },
  {
    id: "fleet",
    icon: Plane,
    label_en: "Fleet",
    label_ar: "الأسطول",
    perm: "fleet.view",
  },
  {
    id: "crew",
    icon: Users,
    label_en: "Crew",
    label_ar: "الطاقم",
    perm: "crew.view",
  },
  {
    id: "camo",
    icon: ShieldCheck,
    label_en: "CAMO",
    label_ar: "إدارة الصلاحية",
    perm: "camo.view",
  },
  {
    id: "permits",
    icon: FileSignature,
    label_en: "Permits",
    label_ar: "التصاريح",
    perm: "permits.view",
  },
  {
    id: "catering",
    icon: UtensilsCrossed,
    label_en: "Catering",
    label_ar: "التموين",
    perm: "catering.view",
  },
  {
    id: "settings",
    icon: SettingsIcon,
    label_en: "Settings",
    label_ar: "الإعدادات",
    perm: "settings.view",
  },
];

/* ═══ DEFAULT TAB PREFERENCES ═══ */
const DEFAULT_TAB_PREFERENCES = {
  dashboard: "primary",
  schedule: "primary",
  ftl: "primary",
  reports: "primary",
  roster: "more",
  standby: "more",
  leave: "more",
  training: "more",
  tracking: "more",
  charts: "more",
  fleet: "more",
  crew: "more",
  camo: "more",
  permits: "more",
  catering: "more",
  settings: "more",
};

function logoToDisplayUrl(url) {
  if (!url) return "";
  if (url.startsWith("data:")) return url;
  const match = url.match(/[?&]id=([^&]+)/);
  if (match) return `https://lh3.googleusercontent.com/d/${match[1]}`;
  const pathMatch = url.match(/\/d\/([^/]+)/);
  if (pathMatch) return `https://lh3.googleusercontent.com/d/${pathMatch[1]}`;
  return url;
}

/* ═══════════════════════════════════════════════════════════
 * MAIN MODULE
 * ═══════════════════════════════════════════════════════════ */
export function SettingsModule({
  settings,
  setSettings,
  lang,
  setLang,
  users = [],
  setUsers,
  roles = [],
  setRoles,
  loginHistory = [],
  setLoginHistory,
  auditLogs = [],
  setAuditLogs,
  crew = [],
  setSyncStatus,
}) {
  const t = useT();
  const { user } = useAuth();
  const langCode = document.documentElement.lang || "en";
  const [activeTab, setActiveTab] = useState("general");

  const visibleTabs = TABS.filter((tab) => checkPerm(user, tab.perm));

  useEffect(() => {
    if (!visibleTabs.find((tab) => tab.id === activeTab)) {
      setActiveTab(visibleTabs[0]?.id || "general");
    }
  }, [user]);

  return (
    <div className="space-y-4 fade-in">
      {/* Header */}
      <div
        className="rounded-xl p-4 text-white shadow-md-theme"
        style={{ background: "var(--brand-gradient)" }}
      >
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 bg-white/20 rounded-lg flex items-center justify-center backdrop-blur-sm">
            <SettingsIcon className="w-7 h-7" />
          </div>
          <div>
            <h2 className="text-xl font-bold">
              {t.settingsTitle || "Settings"}
            </h2>
            <div className="text-xs opacity-80">
              {visibleTabs.length} {langCode === "ar" ? "أقسام" : "sections"}
            </div>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div
        className="rounded-xl p-2 flex flex-wrap gap-1"
        style={{
          backgroundColor: "var(--bg-card)",
          border: "1px solid var(--border-default)",
          boxShadow: "var(--shadow-sm)",
        }}
      >
        {visibleTabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className="flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-bold transition"
              style={
                isActive
                  ? {
                      background: "var(--brand-gradient)",
                      color: "white",
                      boxShadow: "var(--shadow-sm)",
                    }
                  : { color: "var(--text-muted)" }
              }
              onMouseEnter={(e) => {
                if (!isActive)
                  e.currentTarget.style.backgroundColor = "var(--bg-app)";
              }}
              onMouseLeave={(e) => {
                if (!isActive) e.currentTarget.style.backgroundColor = "";
              }}
            >
              <Icon className="w-4 h-4" />
              {langCode === "ar" ? tab.label_ar : tab.label_en}
            </button>
          );
        })}
      </div>

      {/* Content */}
      <div>
        {activeTab === "general" && (
          <GeneralTab
            settings={settings}
            setSettings={setSettings}
            lang={lang}
            setLang={setLang}
            user={user}
            t={t}
          />
        )}
        {activeTab === "positions" && (
          <PositionsSettingsTab
            settings={settings}
            setSettings={setSettings}
            t={t}
            lang={langCode}
            setSyncStatus={setSyncStatus}
          />
        )}
        {activeTab === "appearance" && (
          <AppearanceTab
            settings={settings}
            setSettings={setSettings}
            lang={lang}
            user={user}
            t={t}
          />
        )}
        {activeTab === "sounds" && <SoundsTab lang={lang} t={t} user={user} />}
        {activeTab === "email" && (
          <EmailModule
            crew={crew}
            users={users}
            setSyncStatus={setSyncStatus}
          />
        )}
        {activeTab === "users" && (
          <UsersModule
            users={users}
            setUsers={setUsers}
            roles={roles}
            lang={langCode}
            setSyncStatus={setSyncStatus}
          />
        )}
        {activeTab === "roles" && (
          <RolesModule
            roles={roles}
            setRoles={setRoles}
            setSyncStatus={setSyncStatus}
          />
        )}
        {activeTab === "login-history" && (
          <LoginHistoryModule
            loginHistory={loginHistory}
            setLoginHistory={setLoginHistory}
            currentUser={user}
          />
        )}
        {activeTab === "audit-log" && (
          <AuditLogModule auditLogs={auditLogs} setAuditLogs={setAuditLogs} />
        )}
        {activeTab === "whatsapp" && (
          <WhatsAppModule
            crew={crew}
            users={users}
            setSyncStatus={setSyncStatus}
          />
        )}
      </div>
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════
 * GENERAL TAB
 * ═══════════════════════════════════════════════════════════ */
function GeneralTab({ settings, setSettings, lang, setLang, user, t }) {
  const [draft, setDraft] = useState(settings || {});
  const [saving, setSaving] = useState(false);

  const [uploadingLogo, setUploadingLogo] = useState(false);
  const [logoError, setLogoError] = useState(false);
  const logoRef = useRef();

  const [uploadingStamp, setUploadingStamp] = useState(false);
  const [stampError, setStampError] = useState(false);
  const stampRef = useRef();

  useEffect(() => {
    setDraft(settings || {});
    setLogoError(false);
    setStampError(false);
  }, [settings]);

  const editable = checkPerm(user, "settings.general_edit");
  const canUploadLogo = checkPerm(user, "settings.logo_upload");
  const canRemoveLogo = checkPerm(user, "settings.logo_remove");
  const canViewStamp = checkPerm(user, "settings.view_stamp");
  const canEditStamp = checkPerm(user, "settings.edit_stamp");

  const uploadLogo = async (e) => {
    const f = e.target.files?.[0];
    if (!f) return;
    if (f.size > 2 * 1024 * 1024) {
      alert("⚠️ الحد الأقصى 2 MB");
      if (logoRef.current) logoRef.current.value = "";
      return;
    }
    if (!f.type.startsWith("image/")) {
      alert("⚠️ الرجاء اختيار صورة");
      if (logoRef.current) logoRef.current.value = "";
      return;
    }
    setUploadingLogo(true);
    try {
      const r = await uploadFile(f, "logos");
      if (!r || !r.fileUrl) throw new Error("لم يُرجع رابط الملف");
      const updated = { ...draft, logo: r.fileUrl };
      setDraft(updated);
      setLogoError(false);
      await settingsAPI.save({ logo: r.fileUrl });
      const fresh = await settingsAPI.get();
      setSettings(fresh || updated);
      alert("✅ " + (t.logoUploaded || "تم رفع الشعار"));
    } catch (err) {
      alert("❌ " + (t.failedUpload || "فشل الرفع") + "\n\n" + err.message);
    } finally {
      setUploadingLogo(false);
      if (logoRef.current) logoRef.current.value = "";
    }
  };

  const uploadStamp = async (e) => {
    const f = e.target.files?.[0];
    if (!f) return;
    if (f.size > 2 * 1024 * 1024) {
      alert("⚠️ الحد الأقصى 2 MB");
      if (stampRef.current) stampRef.current.value = "";
      return;
    }
    if (!f.type.startsWith("image/")) {
      alert("⚠️ الرجاء اختيار صورة");
      if (stampRef.current) stampRef.current.value = "";
      return;
    }
    setUploadingStamp(true);
    try {
      const r = await uploadFile(f, "stamps");
      if (!r || !r.fileUrl) throw new Error("لم يُرجع رابط الملف");
      const updated = { ...draft, stamp: r.fileUrl };
      setDraft(updated);
      setStampError(false);
      await settingsAPI.save({ stamp: r.fileUrl });
      const fresh = await settingsAPI.get();
      setSettings(fresh || updated);
      alert("✅ تم رفع الختم");
    } catch (err) {
      alert("❌ فشل رفع الختم\n\n" + err.message);
    } finally {
      setUploadingStamp(false);
      if (stampRef.current) stampRef.current.value = "";
    }
  };

  const save = async () => {
    setSaving(true);
    try {
      await settingsAPI.save(draft);
      const fresh = await settingsAPI.get();
      setSettings(fresh || draft);
      alert("✅ " + (t.settingsSaved || "تم الحفظ"));
    } catch (e) {
      alert("❌ " + (t.failedSave || "فشل الحفظ") + ": " + e.message);
    } finally {
      setSaving(false);
    }
  };

  const removeLogo = async () => {
    if (!canRemoveLogo) return;
    if (!confirm("إزالة الشعار؟")) return;
    const updated = { ...draft, logo: "" };
    setDraft(updated);
    setLogoError(false);
    try {
      await settingsAPI.save({ logo: "" });
      const fresh = await settingsAPI.get();
      setSettings(fresh || updated);
    } catch (e) {
      console.error(e);
    }
  };

  const removeStamp = async () => {
    if (!canEditStamp) return;
    if (!confirm("إزالة الختم؟")) return;
    const updated = { ...draft, stamp: "" };
    setDraft(updated);
    setStampError(false);
    try {
      await settingsAPI.save({ stamp: "" });
      const fresh = await settingsAPI.get();
      setSettings(fresh || updated);
    } catch (e) {
      console.error(e);
    }
  };

  const sectionStyle = {
    backgroundColor: "var(--bg-card)",
    border: "1px solid var(--border-default)",
    boxShadow: "var(--shadow-sm)",
  };

  return (
    <div className="max-w-2xl space-y-4">
      {!editable && (
        <div className="p-3 rounded-lg bg-amber-500/15 border border-amber-500/40 text-amber-500 text-sm flex items-center gap-2">
          <Lock className="w-4 h-4" /> {t.readOnly || "عرض فقط"}
        </div>
      )}

      {/* Logo + Stamp */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <section className="p-4 rounded-2xl" style={sectionStyle}>
          <h4
            className="text-sm font-bold mb-3 flex items-center gap-2"
            style={{ color: "var(--text-primary)" }}
          >
            <Camera className="w-4 h-4" /> {t.companyLogo || "شعار الشركة"}
          </h4>
          <div className="flex flex-col items-center gap-3">
            <div
              className="w-24 h-24 rounded-xl overflow-hidden border-2 border-dashed flex items-center justify-center flex-shrink-0"
              style={{
                backgroundColor: "var(--bg-app)",
                borderColor: "var(--border-default)",
              }}
            >
              {draft.logo && !logoError ? (
                <img
                  src={logoToDisplayUrl(draft.logo)}
                  alt="logo"
                  className="w-full h-full object-contain p-1"
                  onError={() => setLogoError(true)}
                />
              ) : (
                <Plane
                  className="w-8 h-8"
                  style={{ color: "var(--text-muted)", opacity: 0.4 }}
                />
              )}
            </div>
            <div className="flex gap-2 flex-wrap justify-center">
              <button
                type="button"
                disabled={!canUploadLogo || uploadingLogo}
                onClick={() => logoRef.current?.click()}
                className="px-3 py-2 rounded-lg text-white text-xs flex items-center gap-2 disabled:opacity-50 transition"
                style={{
                  background: "var(--brand-gradient)",
                  boxShadow: "var(--shadow-sm)",
                }}
              >
                <Upload className="w-4 h-4" />{" "}
                {uploadingLogo ? "…" : "رفع الشعار"}
              </button>
              {draft.logo && canRemoveLogo && (
                <button
                  type="button"
                  onClick={removeLogo}
                  className="px-3 py-2 rounded-lg bg-rose-500/15 text-rose-500 text-xs hover:bg-rose-500/25 transition"
                >
                  إزالة
                </button>
              )}
            </div>
            <p className="text-[10px]" style={{ color: "var(--text-muted)" }}>
              PNG/JPG · max 2 MB
            </p>
          </div>
          <input
            ref={logoRef}
            type="file"
            accept="image/*"
            onChange={uploadLogo}
            className="hidden"
          />
        </section>

        <section className="p-4 rounded-2xl" style={sectionStyle}>
          <h4
            className="text-sm font-bold mb-3 flex items-center gap-2"
            style={{ color: "var(--text-primary)" }}
          >
            <ImageIcon className="w-4 h-4" /> {t.stamp || "الختم / Stamp"}
          </h4>
          <div className="flex flex-col items-center gap-3">
            <div
              className="w-24 h-24 rounded-xl overflow-hidden border-2 border-dashed flex items-center justify-center flex-shrink-0"
              style={{
                backgroundColor: "var(--bg-app)",
                borderColor: "var(--border-default)",
              }}
            >
              {!canViewStamp ? (
                <Lock
                  className="w-8 h-8"
                  style={{ color: "var(--text-muted)" }}
                  title="ليس لديك صلاحية رؤية الختم"
                />
              ) : draft.stamp && !stampError ? (
                <img
                  src={logoToDisplayUrl(draft.stamp)}
                  alt="stamp"
                  className="w-full h-full object-contain p-1"
                  onError={() => setStampError(true)}
                />
              ) : (
                <ImageIcon
                  className="w-8 h-8"
                  style={{ color: "var(--text-muted)", opacity: 0.4 }}
                />
              )}
            </div>
            <div className="flex gap-2 flex-wrap justify-center">
              <button
                type="button"
                disabled={!canEditStamp || uploadingStamp}
                onClick={() => stampRef.current?.click()}
                className="px-3 py-2 rounded-lg text-white text-xs flex items-center gap-2 disabled:opacity-50 transition"
                style={{
                  background: "var(--brand-gradient)",
                  boxShadow: "var(--shadow-sm)",
                }}
              >
                <Upload className="w-4 h-4" />{" "}
                {uploadingStamp ? "…" : "رفع الختم"}
              </button>
              {draft.stamp && canEditStamp && (
                <button
                  type="button"
                  onClick={removeStamp}
                  className="px-3 py-2 rounded-lg bg-rose-500/15 text-rose-500 text-xs hover:bg-rose-500/25 transition"
                >
                  إزالة
                </button>
              )}
            </div>
            <p className="text-[10px]" style={{ color: "var(--text-muted)" }}>
              PNG/JPG · max 2 MB
            </p>
          </div>
          <input
            ref={stampRef}
            type="file"
            accept="image/*"
            onChange={uploadStamp}
            className="hidden"
          />
        </section>
      </div>

      {/* Company Info + Country + Language */}
      <section className="p-4 rounded-2xl space-y-3" style={sectionStyle}>
        <Field label={t.companyName || "Company Name (EN)"}>
          <Input
            disabled={!editable}
            value={draft.companyName || ""}
            onChange={(e) =>
              setDraft({ ...draft, companyName: e.target.value })
            }
          />
        </Field>
        <Field label={t.companyNameAr || "Company Name (AR)"}>
          <Input
            disabled={!editable}
            value={draft.companyNameAr || ""}
            onChange={(e) =>
              setDraft({ ...draft, companyNameAr: e.target.value })
            }
          />
        </Field>
        <Field label={t.operatorCode || "Operator Code"}>
          <div className="relative">
            <div className="absolute inset-y-0 left-3 flex items-center pointer-events-none">
              <Hash
                className="w-4 h-4"
                style={{ color: "var(--brand-primary)" }}
              />
            </div>
            <Input
              disabled={!editable}
              value={draft.operatorCode || ""}
              onChange={(e) =>
                setDraft({
                  ...draft,
                  operatorCode: e.target.value
                    .toUpperCase()
                    .replace(/[^A-Z0-9]/g, "")
                    .slice(0, 8),
                })
              }
              placeholder="EACS"
              maxLength={8}
              className="pl-9 font-mono font-bold tracking-widest"
              style={{
                letterSpacing: "2px",
                fontSize: "15px",
                color: "var(--brand-primary)",
              }}
            />
          </div>
        </Field>

        {/* ⭐ v9.0 — Country */}
        <Field label={t.country || "الدولة"}>
          <Input
            disabled={!editable}
            value={draft.country || ""}
            onChange={(e) => setDraft({ ...draft, country: e.target.value })}
            placeholder="Libya / ليبيا"
          />
        </Field>

        <Field label={t.language || "اللغة"}>
          <Select value={lang} onChange={(e) => setLang(e.target.value)}>
            <option value="ar">{t.arabic || "العربية"}</option>
            <option value="en">{t.english || "English"}</option>
          </Select>
        </Field>
      </section>

      <button
        disabled={!editable || saving}
        onClick={save}
        className="w-full px-4 py-3 disabled:opacity-50 text-white rounded-xl text-sm flex items-center justify-center gap-2 font-bold transition hover:-translate-y-0.5"
        style={{
          background: "var(--brand-gradient)",
          boxShadow: "var(--shadow-md)",
        }}
      >
        <Save className="w-4 h-4" />{" "}
        {saving ? "…" : t.saveChanges || "حفظ التغييرات"}
      </button>
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════
 * SOUNDS TAB
 * ═══════════════════════════════════════════════════════════ */
function SoundsTab({ lang, t, user }) {
  const {
    soundsEnabled,
    setSoundsEnabled,
    soundsVolume,
    setSoundsVolume,
    alertSoundsEnabled,
    setAlertSoundsEnabled,
  } = useSounds();

  const canEdit = checkPerm(user, "settings.sounds_edit");

  const cardStyle = {
    backgroundColor: "var(--bg-card)",
    border: "1px solid var(--border-default)",
    boxShadow: "var(--shadow-sm)",
  };
  const innerStyle = {
    backgroundColor: "var(--bg-app)",
    border: "1px solid var(--border-default)",
  };

  return (
    <div className="max-w-2xl space-y-4">
      {!canEdit && (
        <div className="p-3 rounded-lg bg-amber-500/15 border border-amber-500/40 text-amber-500 text-sm flex items-center gap-2">
          <Lock className="w-4 h-4" /> {t.readOnly || "عرض فقط"}
        </div>
      )}

      <div
        className="rounded-2xl text-white shadow-md-theme flex items-center gap-3 p-4"
        style={{ background: "var(--brand-gradient)" }}
      >
        <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center backdrop-blur-sm">
          <Volume2 className="w-7 h-7" />
        </div>
        <div>
          <h3 className="text-lg font-bold">
            {lang === "ar" ? "الأصوات" : "Sounds"}
          </h3>
          <div className="text-xs opacity-80">
            {lang === "ar"
              ? "إعدادات الصوت والتنبيهات"
              : "Sound & alert settings"}
          </div>
        </div>
      </div>

      <section className="space-y-4 p-4 rounded-2xl" style={cardStyle}>
        <div
          className="flex items-center gap-2 pb-2"
          style={{ borderBottom: "1px solid var(--border-default)" }}
        >
          <Volume2
            className="w-5 h-5"
            style={{ color: "var(--brand-primary)" }}
          />
          <h3
            className="text-base font-bold"
            style={{ color: "var(--text-primary)" }}
          >
            {t.soundsTitle || (lang === "ar" ? "الأصوات" : "Sounds")}
          </h3>
        </div>

        <div
          className="flex items-center justify-between p-3 rounded-xl"
          style={innerStyle}
        >
          <div className="flex items-center gap-3">
            <div
              className="w-10 h-10 rounded-xl flex items-center justify-center"
              style={{
                backgroundColor: soundsEnabled
                  ? "rgba(34, 197, 94, 0.15)"
                  : "var(--bg-card)",
              }}
            >
              {soundsEnabled ? (
                <Volume2 className="w-5 h-5 text-emerald-500" />
              ) : (
                <VolumeX
                  className="w-5 h-5"
                  style={{ color: "var(--text-muted)" }}
                />
              )}
            </div>
            <div
              className="font-bold text-sm"
              style={{ color: "var(--text-primary)" }}
            >
              {t.enableSounds ||
                (lang === "ar" ? "تشغيل الأصوات" : "Enable Sounds")}
            </div>
          </div>
          <button
            onClick={() => setSoundsEnabled(!soundsEnabled)}
            disabled={!canEdit}
            className="relative w-14 h-8 rounded-full transition disabled:opacity-50"
            style={{
              backgroundColor: soundsEnabled
                ? "var(--brand-primary)"
                : "var(--border-default)",
            }}
          >
            <span
              className="absolute top-1 w-6 h-6 bg-white rounded-full shadow-md transition-transform"
              style={{
                transform: soundsEnabled
                  ? "translateX(28px)"
                  : "translateX(4px)",
              }}
            />
          </button>
        </div>

        <div
          className="flex items-center justify-between p-3 rounded-xl"
          style={innerStyle}
        >
          <div className="flex items-center gap-3">
            <div
              className="w-10 h-10 rounded-xl flex items-center justify-center"
              style={{
                backgroundColor: alertSoundsEnabled
                  ? "rgba(245, 158, 11, 0.15)"
                  : "var(--bg-card)",
              }}
            >
              {alertSoundsEnabled ? (
                <Bell className="w-5 h-5 text-amber-500" />
              ) : (
                <BellOff
                  className="w-5 h-5"
                  style={{ color: "var(--text-muted)" }}
                />
              )}
            </div>
            <div
              className="font-bold text-sm"
              style={{ color: "var(--text-primary)" }}
            >
              {t.enableAlertSounds ||
                (lang === "ar" ? "أصوات التنبيه" : "Alert Sounds")}
            </div>
          </div>
          <button
            onClick={() => setAlertSoundsEnabled(!alertSoundsEnabled)}
            disabled={!canEdit}
            className="relative w-14 h-8 rounded-full transition disabled:opacity-50"
            style={{
              backgroundColor: alertSoundsEnabled
                ? "#f59e0b"
                : "var(--border-default)",
            }}
          >
            <span
              className="absolute top-1 w-6 h-6 bg-white rounded-full shadow-md transition-transform"
              style={{
                transform: alertSoundsEnabled
                  ? "translateX(28px)"
                  : "translateX(4px)",
              }}
            />
          </button>
        </div>

        {soundsEnabled && (
          <>
            <div className="p-3 rounded-xl" style={innerStyle}>
              <div className="flex items-center justify-between mb-2">
                <div
                  className="text-xs font-bold"
                  style={{ color: "var(--text-muted)" }}
                >
                  {t.volume || (lang === "ar" ? "مستوى الصوت" : "Volume")}
                </div>
                <div
                  className="text-xs font-mono font-bold"
                  style={{ color: "var(--brand-primary)" }}
                >
                  {Math.round(soundsVolume * 100)}%
                </div>
              </div>
              <input
                type="range"
                min="0"
                max="1"
                step="0.05"
                value={soundsVolume}
                onChange={(e) => setSoundsVolume(parseFloat(e.target.value))}
                disabled={!canEdit}
                className="w-full disabled:opacity-50"
              />
            </div>

            <div className="p-3 rounded-xl" style={innerStyle}>
              <div
                className="text-xs font-bold mb-2"
                style={{ color: "var(--text-muted)" }}
              >
                {t.testSounds ||
                  (lang === "ar" ? "اختبر الأصوات" : "Test Sounds")}
              </div>
              <div className="grid grid-cols-3 gap-2">
                {SOUND_TYPES.map((s) => (
                  <button
                    key={s.key}
                    onClick={() => s.play()}
                    className="flex flex-col items-center gap-1 p-3 rounded-xl transition active:scale-95"
                    style={{
                      backgroundColor: "var(--bg-card)",
                      border: "1px solid var(--border-default)",
                    }}
                  >
                    <span className="text-2xl">{s.icon}</span>
                    <span
                      className="text-[10px] font-bold"
                      style={{ color: "var(--text-primary)" }}
                    >
                      {lang === "ar" ? s.label_ar : s.label_en}
                    </span>
                  </button>
                ))}
              </div>
            </div>

            <button
              onClick={() => testSound()}
              className="w-full px-4 py-3 rounded-xl text-white font-bold text-sm flex items-center justify-center gap-2 transition active:scale-95"
              style={{
                background: "var(--brand-gradient)",
                boxShadow: "var(--shadow-md)",
              }}
            >
              <Volume2 className="w-5 h-5" />{" "}
              {t.testNotification ||
                (lang === "ar" ? "🔊 اختبر الإشعار" : "🔊 Test Notification")}
            </button>
          </>
        )}
      </section>
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════
 * APPEARANCE TAB
 * ═══════════════════════════════════════════════════════════ */
function AppearanceTab({ settings, setSettings, lang, user, t }) {
  const [draft, setDraft] = useState(settings || {});
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    setDraft(settings || {});
  }, [settings]);

  const editable = checkPerm(user, "settings.appearance_edit");
  const canChangeGlobalTheme = checkPerm(user, "settings.global_theme");
  const canChangePortalTheme = checkPerm(user, "settings.portal_theme");
  const canChangeNavLayout = checkPerm(user, "settings.nav_layout");
  const canChangeTabPrefs = checkPerm(user, "settings.tab_prefs");

  const prefs = { ...DEFAULT_TAB_PREFERENCES, ...(draft.tabPreferences || {}) };
  const getTabPosition = (id) =>
    prefs[id] || DEFAULT_TAB_PREFERENCES[id] || "more";
  const setTabPosition = (id, position) => {
    setDraft({
      ...draft,
      tabPreferences: { ...(draft.tabPreferences || {}), [id]: position },
    });
  };

  const save = async () => {
    setSaving(true);
    try {
      const payload = {
        ...settings,
        ...draft,
        globalTheme: draft.globalTheme || DEFAULT_GLOBAL_THEME,
        portalTheme: draft.portalTheme || DEFAULT_PORTAL_THEME,
      };
      await settingsAPI.save(payload);
      const fresh = await settingsAPI.get();
      setSettings(fresh || payload);
      localStorage.setItem(
        "aeroops.tabPreferences",
        JSON.stringify(draft.tabPreferences || {})
      );
      localStorage.setItem("aeroops.navLayout", draft.navLayout || "top");
      window.dispatchEvent(new Event("aeroops:prefsChanged"));
      alert("✅ " + (t.settingsSaved || "تم الحفظ"));
    } catch (e) {
      alert("❌ " + (t.failedSave || "فشل الحفظ") + ": " + e.message);
    } finally {
      setSaving(false);
    }
  };

  const resetToDefault = () => {
    setDraft({
      ...draft,
      tabPreferences: { ...DEFAULT_TAB_PREFERENCES },
      navLayout: "top",
      globalTheme: DEFAULT_GLOBAL_THEME,
      portalTheme: DEFAULT_PORTAL_THEME,
    });
  };

  const cardStyle = {
    backgroundColor: "var(--bg-card)",
    border: "1px solid var(--border-default)",
    boxShadow: "var(--shadow-sm)",
  };

  return (
    <div className="max-w-3xl space-y-4">
      {!editable && (
        <div className="p-3 rounded-lg bg-amber-500/15 border border-amber-500/40 text-amber-500 text-sm flex items-center gap-2">
          <Lock className="w-4 h-4" /> {t.readOnly || "عرض فقط"}
        </div>
      )}

      {/* System Theme */}
      <section className="p-4 rounded-2xl" style={cardStyle}>
        <h4
          className="text-sm font-bold mb-2 flex items-center gap-2"
          style={{ color: "var(--text-primary)" }}
        >
          <Globe className="w-4 h-4" />
          {lang === "ar" ? "ثيم المنظومة (كامل)" : "System Theme (Global)"}
          {!canChangeGlobalTheme && (
            <Lock
              className="w-3.5 h-3.5"
              style={{ color: "var(--text-muted)" }}
              title="ليس لديك صلاحية تغيير ثيم المنظومة"
            />
          )}
        </h4>
        <p className="text-xs mb-4" style={{ color: "var(--text-muted)" }}>
          {lang === "ar"
            ? "اختر لون المنظومة العام — يُطبّق على Header, Sidebar, Cards, Buttons"
            : "Choose the overall system color — applies to header, sidebar, cards, buttons"}
        </p>

        <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
          {Object.values(GLOBAL_THEMES).map((themeObj) => {
            const isSelected =
              (draft.globalTheme || DEFAULT_GLOBAL_THEME) === themeObj.id;
            return (
              <button
                key={themeObj.id}
                type="button"
                disabled={!canChangeGlobalTheme}
                onClick={() => setDraft({ ...draft, globalTheme: themeObj.id })}
                className="relative p-3 rounded-xl border-2 transition text-start disabled:opacity-60"
                style={{
                  borderColor: isSelected
                    ? "var(--brand-primary)"
                    : "var(--border-default)",
                  boxShadow: isSelected
                    ? `0 0 0 3px var(--brand-accent)`
                    : "none",
                  backgroundColor: "var(--bg-card)",
                }}
              >
                <div
                  className="w-full h-20 rounded-lg mb-2 relative overflow-hidden"
                  style={{
                    backgroundColor: themeObj.vars["--bg-app"],
                    border: `1px solid ${themeObj.vars["--border-default"]}`,
                  }}
                >
                  <div
                    className="h-4 w-full"
                    style={{ background: themeObj.vars["--brand-gradient"] }}
                  />
                  <div className="p-1.5 flex gap-1">
                    <div
                      className="flex-1 h-8 rounded"
                      style={{
                        backgroundColor: themeObj.vars["--bg-card"],
                        border: `1px solid ${themeObj.vars["--border-default"]}`,
                      }}
                    />
                    <div
                      className="flex-1 h-8 rounded"
                      style={{
                        backgroundColor: themeObj.vars["--brand-primary"],
                      }}
                    />
                    <div
                      className="flex-1 h-8 rounded"
                      style={{
                        backgroundColor: themeObj.vars["--brand-secondary"],
                      }}
                    />
                  </div>
                </div>
                <div className="flex items-center justify-between">
                  <div
                    className="text-xs font-bold"
                    style={{ color: "var(--text-primary)" }}
                  >
                    {lang === "ar" ? themeObj.nameAr : themeObj.name}
                  </div>
                  {isSelected && (
                    <div
                      className="w-5 h-5 rounded-full flex items-center justify-center"
                      style={{ backgroundColor: "var(--brand-primary)" }}
                    >
                      <Check className="w-3 h-3 text-white" />
                    </div>
                  )}
                </div>
              </button>
            );
          })}
        </div>
      </section>

      {/* Portal Theme */}
      <section className="p-4 rounded-2xl" style={cardStyle}>
        <h4
          className="text-sm font-bold mb-2 flex items-center gap-2"
          style={{ color: "var(--text-primary)" }}
        >
          <Palette className="w-4 h-4" />
          {lang === "ar" ? "ثيم بورتال الطاقم" : "Crew Portal Theme"}
          {!canChangePortalTheme && (
            <Lock
              className="w-3.5 h-3.5"
              style={{ color: "var(--text-muted)" }}
              title="ليس لديك صلاحية تغيير ثيم البورتال"
            />
          )}
        </h4>
        <p className="text-xs mb-4" style={{ color: "var(--text-muted)" }}>
          {lang === "ar"
            ? "يمكن أن يختلف عن ثيم المنظومة — يُطبّق على CrewPortal فقط"
            : "Can differ from system theme — applies to CrewPortal only"}
        </p>

        <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
          {Object.values(GLOBAL_THEMES).map((themeObj) => {
            const isSelected =
              (draft.portalTheme || DEFAULT_PORTAL_THEME) === themeObj.id;
            return (
              <button
                key={themeObj.id}
                type="button"
                disabled={!canChangePortalTheme}
                onClick={() => setDraft({ ...draft, portalTheme: themeObj.id })}
                className="relative p-3 rounded-xl border-2 transition text-start disabled:opacity-60"
                style={{
                  borderColor: isSelected ? "#f59e0b" : "var(--border-default)",
                  boxShadow: isSelected
                    ? `0 0 0 3px rgba(245, 158, 11, 0.3)`
                    : "none",
                  backgroundColor: "var(--bg-card)",
                }}
              >
                <div
                  className="w-full h-16 rounded-lg mb-2"
                  style={{
                    backgroundColor: themeObj.vars["--bg-app"],
                    border: `1px solid ${themeObj.vars["--border-default"]}`,
                  }}
                >
                  <div
                    className="h-3 w-full rounded-t-lg"
                    style={{ background: themeObj.vars["--brand-gradient"] }}
                  />
                </div>
                <div className="flex items-center justify-between">
                  <div
                    className="text-xs font-bold"
                    style={{ color: "var(--text-primary)" }}
                  >
                    {lang === "ar" ? themeObj.nameAr : themeObj.name}
                  </div>
                  {isSelected && (
                    <div className="w-5 h-5 rounded-full bg-amber-500 flex items-center justify-center">
                      <Check className="w-3 h-3 text-white" />
                    </div>
                  )}
                </div>
              </button>
            );
          })}
        </div>

        <div className="mt-3 p-2 rounded text-[10px] bg-blue-500/10 border border-blue-500/40 text-blue-400">
          ℹ️{" "}
          {lang === "ar"
            ? "يُطبّق على جميع أعضاء الطاقم بعد الحفظ + F5"
            : "Applies to all crew members after saving + F5"}
        </div>
      </section>

      {/* Navigation Layout */}
      <section className="p-4 rounded-2xl" style={cardStyle}>
        <h4
          className="text-sm font-bold mb-4 flex items-center gap-2"
          style={{ color: "var(--text-primary)" }}
        >
          <Layout className="w-4 h-4" />
          {lang === "ar" ? "تخطيط التنقل" : "Navigation Layout"}
          {!canChangeNavLayout && (
            <Lock
              className="w-3.5 h-3.5"
              style={{ color: "var(--text-muted)" }}
              title="ليس لديك صلاحية تغيير تخطيط التنقل"
            />
          )}
        </h4>

        <div className="grid grid-cols-2 gap-3">
          {[
            {
              id: "top",
              icon: Layout,
              label: lang === "ar" ? "أفقي (أعلى)" : "Top Nav",
            },
            {
              id: "side",
              icon: PanelLeft,
              label: lang === "ar" ? "جانبي" : "Sidebar",
            },
          ].map((opt) => {
            const Icon = opt.icon;
            const isActive = (draft.navLayout || "top") === opt.id;
            return (
              <button
                key={opt.id}
                type="button"
                disabled={!canChangeNavLayout}
                onClick={() => setDraft({ ...draft, navLayout: opt.id })}
                className="p-4 rounded-xl border-2 transition flex flex-col items-center gap-3 disabled:opacity-60"
                style={{
                  borderColor: isActive
                    ? "var(--brand-primary)"
                    : "var(--border-default)",
                  backgroundColor: isActive
                    ? "var(--bg-app)"
                    : "var(--bg-card)",
                }}
              >
                <Icon
                  className="w-8 h-8"
                  style={{
                    color: isActive
                      ? "var(--brand-primary)"
                      : "var(--text-muted)",
                  }}
                />
                <div
                  className="text-sm font-bold"
                  style={{
                    color: isActive
                      ? "var(--brand-primary)"
                      : "var(--text-muted)",
                  }}
                >
                  {opt.label}
                </div>
              </button>
            );
          })}
        </div>
      </section>

      {/* Tab Preferences */}
      <section className="p-4 rounded-2xl" style={cardStyle}>
        <h4
          className="text-sm font-bold mb-2 flex items-center gap-2"
          style={{ color: "var(--text-primary)" }}
        >
          <Sparkles className="w-4 h-4" />
          {lang === "ar" ? "تخصيص التبويبات" : "Tab Preferences"}
          {!canChangeTabPrefs && (
            <Lock
              className="w-3.5 h-3.5"
              style={{ color: "var(--text-muted)" }}
              title="ليس لديك صلاحية تخصيص التبويبات"
            />
          )}
        </h4>
        <p className="text-xs mb-4" style={{ color: "var(--text-muted)" }}>
          {lang === "ar"
            ? "اختر أي تبويب يظهر في الشريط الأساسي، أو تحت قائمة More، أو مخفي"
            : "Choose which tab appears in the main bar, under More, or hidden"}
        </p>

        <div
          className="hidden md:grid grid-cols-12 gap-2 px-3 py-2 text-xs font-bold"
          style={{
            color: "var(--text-muted)",
            borderBottom: "1px solid var(--border-default)",
          }}
        >
          <div className="col-span-6">{lang === "ar" ? "التبويب" : "Tab"}</div>
          <div className="col-span-2 text-center">
            {lang === "ar" ? "أساسي" : "Primary"}
          </div>
          <div className="col-span-2 text-center">More</div>
          <div className="col-span-2 text-center">
            {lang === "ar" ? "مخفي" : "Hidden"}
          </div>
        </div>

        <div className="space-y-1 mt-1">
          {ALL_TABS_CONFIG.map((tab) => {
            const Icon = tab.icon;
            const label = lang === "ar" ? tab.label_ar : tab.label_en;
            const position = getTabPosition(tab.id);
            return (
              <div
                key={tab.id}
                className="grid grid-cols-12 gap-2 items-center px-3 py-2 rounded-lg transition"
                onMouseEnter={(e) => {
                  e.currentTarget.style.backgroundColor = "var(--bg-app)";
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.backgroundColor = "transparent";
                }}
              >
                <div className="col-span-12 md:col-span-6 flex items-center gap-2 mb-2 md:mb-0">
                  <div
                    className="w-7 h-7 rounded-lg flex items-center justify-center flex-shrink-0"
                    style={{ backgroundColor: "var(--bg-app)" }}
                  >
                    <Icon
                      className="w-4 h-4"
                      style={{ color: "var(--text-muted)" }}
                    />
                  </div>
                  <span
                    className="text-sm font-semibold"
                    style={{ color: "var(--text-primary)" }}
                  >
                    {label}
                  </span>
                </div>
                {[
                  { v: "primary", color: "var(--brand-primary)" },
                  { v: "more", color: "var(--brand-secondary)" },
                  { v: "hidden", color: "var(--text-muted)" },
                ].map((opt) => (
                  <div
                    key={opt.v}
                    className="col-span-4 md:col-span-2 flex justify-center"
                  >
                    <button
                      type="button"
                      disabled={!canChangeTabPrefs}
                      onClick={() => setTabPosition(tab.id, opt.v)}
                      className="w-8 h-8 rounded-full border-2 flex items-center justify-center transition disabled:opacity-60"
                      style={{
                        borderColor:
                          position === opt.v
                            ? opt.color
                            : "var(--border-default)",
                        backgroundColor:
                          position === opt.v ? opt.color : "transparent",
                      }}
                    >
                      {position === opt.v && (
                        <div className="w-3 h-3 rounded-full bg-white" />
                      )}
                    </button>
                  </div>
                ))}
              </div>
            );
          })}
        </div>
        <div
          className="flex gap-2 mt-4 pt-4"
          style={{ borderTop: "1px solid var(--border-default)" }}
        >
          <button
            type="button"
            disabled={!canChangeTabPrefs}
            onClick={resetToDefault}
            className="px-3 py-2 rounded-lg text-sm font-bold transition disabled:opacity-60"
            style={{
              backgroundColor: "var(--bg-app)",
              color: "var(--text-primary)",
              border: "1px solid var(--border-default)",
            }}
          >
            {lang === "ar" ? "استعادة الافتراضي" : "Reset to Default"}
          </button>
        </div>
      </section>

      <button
        disabled={!editable || saving}
        onClick={save}
        className="w-full px-4 py-3 disabled:opacity-50 text-white rounded-xl text-sm flex items-center justify-center gap-2 font-bold transition hover:-translate-y-0.5"
        style={{
          background: "var(--brand-gradient)",
          boxShadow: "var(--shadow-md)",
        }}
      >
        <Save className="w-4 h-4" />{" "}
        {saving ? "…" : t.saveChanges || "حفظ التغييرات"}
      </button>
    </div>
  );
}

export default SettingsModule;
