/* ═══════════════════════════════════════════════════════════
 * CAMO MODULE — Continuous Airworthiness Management
 * v1.0 — 5 tabs: Aircraft / Checks / Components / Documents / MEL
 * ═══════════════════════════════════════════════════════════ */
import React, { useState, useEffect, useMemo } from "react";
import {
  Plus,
  Edit,
  Trash2,
  Search,
  Save,
  ShieldCheck,
  Plane,
  AlertTriangle,
  Wrench,
  FileText,
  Eye,
  Calendar,
  Users,
  Check,
  X,
  CheckCircle2,
  Clock,
  Activity,
} from "lucide-react";
import { useT, useAuth } from "../contexts";
import { Field } from "../components/ui/Field";
import { Input } from "../components/ui/Input";
import { Select } from "../components/ui/Select";
import { Modal } from "../components/ui/Modal";
import { camoAPI, melAPI } from "../api";
import { can as checkPerm } from "../config/permissions";
import { fmtDate, daysUntil } from "../utils/helpers";

/* ═══ Helpers ═══ */
const cardStyle = {
  backgroundColor: "var(--bg-card)",
  border: "1px solid var(--border-default)",
  boxShadow: "var(--shadow-sm)",
};
const innerBoxStyle = {
  backgroundColor: "var(--bg-app)",
  border: "1px solid var(--border-default)",
};

const STATUS_COLORS = {
  AIRWORTHY: {
    bg: "bg-emerald-500/15",
    text: "text-emerald-500",
    label: "🟢 AIRWORTHY",
  },
  "DUE SOON": {
    bg: "bg-amber-500/15",
    text: "text-amber-500",
    label: "🟡 DUE SOON",
  },
  OVERDUE: { bg: "bg-rose-500/15", text: "text-rose-500", label: "🔴 OVERDUE" },
  GROUNDED: {
    bg: "bg-slate-500/15",
    text: "text-slate-400",
    label: "⛔ GROUNDED",
  },
};

const MEL_STATUS_COLORS = {
  OPEN: { bg: "bg-amber-500/15", text: "text-amber-500", label: "⚠️ OPEN" },
  CLOSED: {
    bg: "bg-emerald-500/15",
    text: "text-emerald-500",
    label: "✅ CLOSED",
  },
  DEFERRED: {
    bg: "bg-orange-500/15",
    text: "text-orange-500",
    label: "⏸️ DEFERRED",
  },
};

const CATEGORY_DAYS = { A: 1, B: 3, C: 10, D: 120 };

const getCheckStatus = (nextCheckDate) => {
  if (!nextCheckDate) return "AIRWORTHY";
  const days = daysUntil(nextCheckDate);
  if (days === null) return "AIRWORTHY";
  if (days < 0) return "OVERDUE";
  if (days <= 30) return "DUE SOON";
  return "AIRWORTHY";
};

/* ═══ MAIN COMPONENT ═══ */
export function CAMOModule({ fleet, settings, user, setSyncStatus }) {
  const t = useT();
  const [activeTab, setActiveTab] = useState("aircraft");
  const [camoList, setCamoList] = useState([]);
  const [melList, setMelList] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");

  const [editingAircraft, setEditingAircraft] = useState(null);
  const [draftAircraft, setDraftAircraft] = useState({});

  const [editingMel, setEditingMel] = useState(null);
  const [draftMel, setDraftMel] = useState({});

  const canEdit = checkPerm(user, "camo.edit");
  const canMelEdit = checkPerm(user, "mel.edit");

  const loadData = async () => {
    setLoading(true);
    setSyncStatus?.("syncing");
    try {
      const [camo, mel] = await Promise.all([
        camoAPI.list().catch(() => []),
        melAPI.list().catch(() => []),
      ]);
      setCamoList(camo);
      setMelList(mel);
      setSyncStatus?.("synced");
    } catch (e) {
      console.error("CAMO load failed:", e);
      setSyncStatus?.("error");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  /* ═══ Aircraft CRUD ═══ */
  const openNewAircraft = () => {
    if (!canEdit) return alert("⚠️ ليس لديك صلاحية");
    setDraftAircraft({
      reg: "",
      type: "",
      tah: 0,
      tac: 0,
      lastCheckDate: "",
      lastCheckType: "A",
      nextCheckDate: "",
      nextCheckType: "A",
      coaExpiry: "",
      insuranceExpiry: "",
      noiseCertExpiry: "",
      engine1Hours: 0,
      engine1Cycles: 0,
      engine2Hours: 0,
      engine2Cycles: 0,
      apuHours: 0,
      apuCycles: 0,
      llpHours: 0,
      llpCycles: 0,
      notes: "",
      status: "AIRWORTHY",
    });
    setEditingAircraft("new");
  };

  const openEditAircraft = (a) => {
    if (!canEdit) return alert("⚠️ ليس لديك صلاحية");
    setDraftAircraft({ ...a });
    setEditingAircraft(a.id);
  };

  const saveAircraft = async () => {
    if (!draftAircraft.reg) return alert("⚠️ أدخل رقم التسجيل");
    setSyncStatus?.("syncing");
    try {
      if (editingAircraft === "new") {
        const created = await camoAPI.create(draftAircraft);
        setCamoList([...camoList, { ...draftAircraft, id: created.id }]);
      } else {
        await camoAPI.update(editingAircraft, draftAircraft);
        setCamoList(
          camoList.map((a) =>
            a.id === editingAircraft
              ? { ...draftAircraft, id: editingAircraft }
              : a
          )
        );
      }
      setEditingAircraft(null);
      setSyncStatus?.("synced");
    } catch (e) {
      alert("فشل: " + e.message);
      setSyncStatus?.("error");
    }
  };

  const removeAircraft = async (id) => {
    if (!canEdit) return alert("⚠️ ليس لديك صلاحية");
    if (!confirm("حذف هذه الطائرة من CAMO؟")) return;
    try {
      await camoAPI.remove(id);
      setCamoList(camoList.filter((a) => a.id !== id));
    } catch (e) {
      alert("فشل: " + e.message);
    }
  };

  /* ═══ MEL CRUD ═══ */
  const openNewMel = () => {
    if (!canMelEdit) return alert("⚠️ ليس لديك صلاحية");
    setDraftMel({
      reg: "",
      melRef: "",
      item: "",
      status: "OPEN",
      category: "C",
      openedDate: new Date().toISOString().slice(0, 10),
      dueDate: "",
      closedDate: "",
      restrictions: "",
      remarks: "",
    });
    setEditingMel("new");
  };

  const openEditMel = (m) => {
    if (!canMelEdit) return alert("⚠️ ليس لديك صلاحية");
    setDraftMel({ ...m });
    setEditingMel(m.id);
  };

  const saveMel = async () => {
    if (!draftMel.reg || !draftMel.melRef) {
      return alert("⚠️ أدخل Reg + MEL Ref");
    }
    // Auto-compute dueDate from category
    if (
      draftMel.status === "OPEN" &&
      draftMel.openedDate &&
      draftMel.category
    ) {
      const opened = new Date(draftMel.openedDate);
      const days = CATEGORY_DAYS[draftMel.category] || 10;
      opened.setDate(opened.getDate() + days);
      draftMel.dueDate = opened.toISOString().slice(0, 10);
    }
    setSyncStatus?.("syncing");
    try {
      if (editingMel === "new") {
        const created = await melAPI.create(draftMel);
        setMelList([...melList, { ...draftMel, id: created.id }]);
      } else {
        await melAPI.update(editingMel, draftMel);
        setMelList(
          melList.map((m) =>
            m.id === editingMel ? { ...draftMel, id: editingMel } : m
          )
        );
      }
      setEditingMel(null);
      setSyncStatus?.("synced");
    } catch (e) {
      alert("فشل: " + e.message);
      setSyncStatus?.("error");
    }
  };

  const closeMel = async (id) => {
    if (!canMelEdit) return alert("⚠️ ليس لديك صلاحية");
    const m = melList.find((x) => x.id === id);
    if (!m) return;
    if (!confirm(`إغلاق MEL ${m.melRef}؟`)) return;
    try {
      const updated = {
        ...m,
        status: "CLOSED",
        closedDate: new Date().toISOString().slice(0, 10),
      };
      await melAPI.update(id, updated);
      setMelList(melList.map((x) => (x.id === id ? updated : x)));
    } catch (e) {
      alert("فشل: " + e.message);
    }
  };

  const removeMel = async (id) => {
    if (!canMelEdit) return alert("⚠️ ليس لديك صلاحية");
    if (!confirm("حذف هذا MEL؟")) return;
    try {
      await melAPI.remove(id);
      setMelList(melList.filter((m) => m.id !== id));
    } catch (e) {
      alert("فشل: " + e.message);
    }
  };

  /* ═══ Filtering ═══ */
  const filteredCamo = useMemo(() => {
    if (!search) return camoList;
    const q = search.toLowerCase();
    return camoList.filter((a) => (a.reg + a.type).toLowerCase().includes(q));
  }, [camoList, search]);

  const filteredMel = useMemo(() => {
    let list = melList;
    if (search) {
      const q = search.toLowerCase();
      list = list.filter((m) =>
        (m.reg + m.melRef + m.item).toLowerCase().includes(q)
      );
    }
    return list;
  }, [melList, search]);

  const counters = {
    total: camoList.length,
    airworthy: camoList.filter(
      (a) => getCheckStatus(a.nextCheckDate) === "AIRWORTHY"
    ).length,
    dueSoon: camoList.filter(
      (a) => getCheckStatus(a.nextCheckDate) === "DUE SOON"
    ).length,
    overdue: camoList.filter(
      (a) => getCheckStatus(a.nextCheckDate) === "OVERDUE"
    ).length,
    openMel: melList.filter((m) => m.status === "OPEN").length,
  };

  /* ═══ RENDER ═══ */
  return (
    <div className="space-y-4 fade-in">
      {/* Header */}
      <div className="rounded-xl p-3" style={cardStyle}>
        <div className="flex flex-wrap gap-2 items-center justify-between mb-3">
          <div className="flex items-center gap-3">
            <div
              className="w-10 h-10 rounded-lg flex items-center justify-center shadow-md"
              style={{ background: "var(--brand-gradient)" }}
            >
              <ShieldCheck className="w-6 h-6 text-white" />
            </div>
            <div>
              <h2
                className="text-lg font-bold"
                style={{ color: "var(--text-primary)" }}
              >
                CAMO — Continuous Airworthiness
              </h2>
              <p className="text-xs" style={{ color: "var(--text-muted)" }}>
                {counters.total} aircraft · {counters.openMel} open MEL items
              </p>
            </div>
          </div>
        </div>

        {/* Tabs */}
        <div
          className="flex flex-wrap gap-1 border-b"
          style={{ borderColor: "var(--border-default)" }}
        >
          {[
            { id: "aircraft", label: "Aircraft", icon: Plane },
            { id: "checks", label: "Checks", icon: Calendar },
            { id: "components", label: "Components", icon: Wrench },
            { id: "documents", label: "Documents", icon: FileText },
            { id: "mel", label: "MEL", icon: AlertTriangle },
          ].map((tab) => {
            const Icon = tab.icon;
            const active = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className="flex items-center gap-1.5 px-3 py-2 text-xs font-bold border-b-2 transition"
                style={{
                  borderColor: active ? "var(--brand-primary)" : "transparent",
                  color: active ? "var(--brand-primary)" : "var(--text-muted)",
                  backgroundColor: active ? "var(--bg-app)" : "transparent",
                }}
              >
                <Icon className="w-4 h-4" />
                {tab.label}
              </button>
            );
          })}
        </div>

        {/* Search + Add */}
        <div className="flex flex-wrap gap-2 items-center mt-3">
          <div className="relative flex-1 min-w-[200px]">
            <Search
              className="w-4 h-4 absolute top-1/2 -translate-y-1/2 start-3"
              style={{ color: "var(--text-muted)" }}
            />
            <Input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search…"
              className="ps-9"
            />
          </div>
          {activeTab === "aircraft" && canEdit && (
            <button
              onClick={openNewAircraft}
              className="flex items-center gap-1.5 px-4 py-2 rounded-lg text-sm font-bold text-white"
              style={{ background: "var(--brand-gradient)" }}
            >
              <Plus className="w-4 h-4" /> Add Aircraft
            </button>
          )}
          {activeTab === "mel" && canMelEdit && (
            <button
              onClick={openNewMel}
              className="flex items-center gap-1.5 px-4 py-2 rounded-lg text-sm font-bold text-white"
              style={{ background: "var(--brand-gradient)" }}
            >
              <Plus className="w-4 h-4" /> Add MEL
            </button>
          )}
        </div>

        {/* Counters */}
        <div
          className="flex flex-wrap gap-3 mt-3 pt-3 border-t text-[11px]"
          style={{ borderColor: "var(--border-default)" }}
        >
          <span>
            🟢 Airworthy: <b>{counters.airworthy}</b>
          </span>
          <span>
            🟡 Due Soon: <b>{counters.dueSoon}</b>
          </span>
          <span>
            🔴 Overdue: <b>{counters.overdue}</b>
          </span>
          <span>
            ⚠️ Open MEL: <b>{counters.openMel}</b>
          </span>
        </div>
      </div>

      {/* ═══ TAB: AIRCRAFT ═══ */}
      {activeTab === "aircraft" && (
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredCamo.map((a) => {
            const status = getCheckStatus(a.nextCheckDate);
            const sc = STATUS_COLORS[status];
            const openMel = melList.filter(
              (m) => m.reg === a.reg && m.status === "OPEN"
            ).length;
            return (
              <div
                key={a.id}
                className="rounded-xl p-4 space-y-3"
                style={cardStyle}
              >
                <div className="flex justify-between items-start">
                  <div>
                    <div
                      className="font-bold text-lg font-mono"
                      style={{ color: "var(--text-primary)" }}
                    >
                      {a.reg}
                    </div>
                    <div
                      className="text-sm"
                      style={{ color: "var(--text-muted)" }}
                    >
                      {a.type}
                    </div>
                  </div>
                  <span
                    className={`px-2 py-1 rounded text-xs font-bold ${sc.bg} ${sc.text}`}
                  >
                    {sc.label}
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-2 text-xs">
                  <div className="p-2 rounded" style={innerBoxStyle}>
                    <div style={{ color: "var(--text-muted)" }}>TAH</div>
                    <div
                      className="font-mono font-bold"
                      style={{ color: "var(--text-primary)" }}
                    >
                      {a.tah?.toLocaleString()}
                    </div>
                  </div>
                  <div className="p-2 rounded" style={innerBoxStyle}>
                    <div style={{ color: "var(--text-muted)" }}>TAC</div>
                    <div
                      className="font-mono font-bold"
                      style={{ color: "var(--text-primary)" }}
                    >
                      {a.tac?.toLocaleString()}
                    </div>
                  </div>
                  <div className="p-2 rounded col-span-2" style={innerBoxStyle}>
                    <div style={{ color: "var(--text-muted)" }}>Next Check</div>
                    <div
                      className="font-mono font-bold"
                      style={{ color: "var(--text-primary)" }}
                    >
                      {fmtDate(a.nextCheckDate) || "—"} (
                      {a.nextCheckType || "—"})
                    </div>
                  </div>
                </div>

                {openMel > 0 && (
                  <div className="p-2 rounded text-xs bg-amber-500/15 text-amber-500 border border-amber-500/30">
                    ⚠️ {openMel} MEL item{openMel > 1 ? "s" : ""} open
                  </div>
                )}

                <div
                  className="flex gap-2 pt-2"
                  style={{ borderTop: "1px solid var(--border-default)" }}
                >
                  {canEdit && (
                    <button
                      onClick={() => openEditAircraft(a)}
                      className="flex-1 py-2 rounded-lg bg-amber-500/15 text-amber-500 text-xs font-bold flex items-center justify-center gap-1"
                    >
                      <Edit className="w-3.5 h-3.5" /> Edit
                    </button>
                  )}
                  {canEdit && (
                    <button
                      onClick={() => removeAircraft(a.id)}
                      className="py-2 px-3 rounded-lg bg-rose-500/15 text-rose-500 text-xs"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* ═══ TAB: CHECKS ═══ */}
      {activeTab === "checks" && (
        <div className="overflow-x-auto rounded-xl" style={cardStyle}>
          <table className="w-full text-sm">
            <thead
              style={{
                backgroundColor: "var(--bg-app)",
                borderBottom: "1px solid var(--border-default)",
              }}
            >
              <tr>
                {[
                  "Reg",
                  "Type",
                  "Last Check",
                  "Type",
                  "Next Check",
                  "Type",
                  "Days Left",
                  "Status",
                ].map((h) => (
                  <th
                    key={h}
                    className="px-3 py-3 text-start font-semibold"
                    style={{ color: "var(--text-primary)" }}
                  >
                    {h}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filteredCamo.map((a) => {
                const status = getCheckStatus(a.nextCheckDate);
                const sc = STATUS_COLORS[status];
                const days = a.nextCheckDate
                  ? daysUntil(a.nextCheckDate)
                  : null;
                return (
                  <tr
                    key={a.id}
                    style={{ borderTop: "1px solid var(--border-default)" }}
                  >
                    <td
                      className="px-3 py-2 font-mono font-bold"
                      style={{ color: "var(--text-primary)" }}
                    >
                      {a.reg}
                    </td>
                    <td
                      className="px-3 py-2"
                      style={{ color: "var(--text-muted)" }}
                    >
                      {a.type}
                    </td>
                    <td
                      className="px-3 py-2 text-xs"
                      style={{ color: "var(--text-muted)" }}
                    >
                      {fmtDate(a.lastCheckDate) || "—"}
                    </td>
                    <td
                      className="px-3 py-2 text-center"
                      style={{ color: "var(--text-muted)" }}
                    >
                      {a.lastCheckType || "—"}
                    </td>
                    <td
                      className="px-3 py-2 text-xs"
                      style={{ color: "var(--text-muted)" }}
                    >
                      {fmtDate(a.nextCheckDate) || "—"}
                    </td>
                    <td
                      className="px-3 py-2 text-center"
                      style={{ color: "var(--text-muted)" }}
                    >
                      {a.nextCheckType || "—"}
                    </td>
                    <td
                      className="px-3 py-2 text-center font-mono font-bold"
                      style={{
                        color:
                          days < 0
                            ? "#ef4444"
                            : days <= 30
                            ? "#f59e0b"
                            : "#22c55e",
                      }}
                    >
                      {days !== null
                        ? days < 0
                          ? `${Math.abs(days)} overdue`
                          : `${days}d`
                        : "—"}
                    </td>
                    <td className="px-3 py-2">
                      <span
                        className={`px-2 py-1 rounded text-xs font-bold ${sc.bg} ${sc.text}`}
                      >
                        {sc.label}
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}

      {/* ═══ TAB: COMPONENTS ═══ */}
      {activeTab === "components" && (
        <div className="grid md:grid-cols-2 gap-4">
          {filteredCamo.map((a) => (
            <div
              key={a.id}
              className="rounded-xl p-4 space-y-2"
              style={cardStyle}
            >
              <div
                className="font-bold font-mono"
                style={{ color: "var(--text-primary)" }}
              >
                {a.reg} · {a.type}
              </div>
              <div className="grid grid-cols-2 gap-2 text-xs">
                <div className="p-2 rounded" style={innerBoxStyle}>
                  <div style={{ color: "var(--text-muted)" }}>Engine 1</div>
                  <div
                    className="font-mono font-bold"
                    style={{ color: "var(--text-primary)" }}
                  >
                    {a.engine1Hours?.toLocaleString()}h /{" "}
                    {a.engine1Cycles?.toLocaleString()}c
                  </div>
                </div>
                <div className="p-2 rounded" style={innerBoxStyle}>
                  <div style={{ color: "var(--text-muted)" }}>Engine 2</div>
                  <div
                    className="font-mono font-bold"
                    style={{ color: "var(--text-primary)" }}
                  >
                    {a.engine2Hours?.toLocaleString()}h /{" "}
                    {a.engine2Cycles?.toLocaleString()}c
                  </div>
                </div>
                <div className="p-2 rounded" style={innerBoxStyle}>
                  <div style={{ color: "var(--text-muted)" }}>APU</div>
                  <div
                    className="font-mono font-bold"
                    style={{ color: "var(--text-primary)" }}
                  >
                    {a.apuHours?.toLocaleString()}h /{" "}
                    {a.apuCycles?.toLocaleString()}c
                  </div>
                </div>
                <div className="p-2 rounded" style={innerBoxStyle}>
                  <div style={{ color: "var(--text-muted)" }}>LLP</div>
                  <div
                    className="font-mono font-bold"
                    style={{ color: "var(--text-primary)" }}
                  >
                    {a.llpHours?.toLocaleString()}h /{" "}
                    {a.llpCycles?.toLocaleString()}c
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* ═══ TAB: DOCUMENTS ═══ */}
      {activeTab === "documents" && (
        <div className="overflow-x-auto rounded-xl" style={cardStyle}>
          <table className="w-full text-sm">
            <thead
              style={{
                backgroundColor: "var(--bg-app)",
                borderBottom: "1px solid var(--border-default)",
              }}
            >
              <tr>
                {["Reg", "Type", "COA Expiry", "Insurance", "Noise Cert"].map(
                  (h) => (
                    <th
                      key={h}
                      className="px-3 py-3 text-start font-semibold"
                      style={{ color: "var(--text-primary)" }}
                    >
                      {h}
                    </th>
                  )
                )}
              </tr>
            </thead>
            <tbody>
              {filteredCamo.map((a) => {
                const docColor = (d) => {
                  if (!d) return "";
                  const days = daysUntil(d);
                  if (days < 0) return "text-rose-500 font-bold";
                  if (days <= 30) return "text-amber-500 font-bold";
                  return "text-emerald-500";
                };
                return (
                  <tr
                    key={a.id}
                    style={{ borderTop: "1px solid var(--border-default)" }}
                  >
                    <td
                      className="px-3 py-2 font-mono font-bold"
                      style={{ color: "var(--text-primary)" }}
                    >
                      {a.reg}
                    </td>
                    <td
                      className="px-3 py-2"
                      style={{ color: "var(--text-muted)" }}
                    >
                      {a.type}
                    </td>
                    <td
                      className={`px-3 py-2 text-xs ${docColor(a.coaExpiry)}`}
                    >
                      {fmtDate(a.coaExpiry) || "—"}
                    </td>
                    <td
                      className={`px-3 py-2 text-xs ${docColor(
                        a.insuranceExpiry
                      )}`}
                    >
                      {fmtDate(a.insuranceExpiry) || "—"}
                    </td>
                    <td
                      className={`px-3 py-2 text-xs ${docColor(
                        a.noiseCertExpiry
                      )}`}
                    >
                      {fmtDate(a.noiseCertExpiry) || "—"}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}

      {/* ═══ TAB: MEL ═══ */}
      {activeTab === "mel" && (
        <div className="space-y-3">
          {filteredMel.length === 0 ? (
            <div className="text-center py-12 rounded-xl" style={cardStyle}>
              <AlertTriangle
                className="w-12 h-12 mx-auto mb-2 opacity-40"
                style={{ color: "var(--text-muted)" }}
              />
              <div style={{ color: "var(--text-muted)" }}>
                لا توجد MEL items
              </div>
            </div>
          ) : (
            filteredMel.map((m) => {
              const sc = MEL_STATUS_COLORS[m.status] || MEL_STATUS_COLORS.OPEN;
              const days = m.dueDate ? daysUntil(m.dueDate) : null;
              const isOverdue =
                days !== null && days < 0 && m.status === "OPEN";
              return (
                <div
                  key={m.id}
                  className={`rounded-xl p-4 space-y-2 border ${
                    isOverdue ? "border-rose-500/50" : ""
                  }`}
                  style={cardStyle}
                >
                  <div className="flex justify-between items-start">
                    <div>
                      <div
                        className="font-bold text-sm"
                        style={{ color: "var(--text-primary)" }}
                      >
                        {m.reg} · MEL {m.melRef}
                      </div>
                      <div
                        className="text-sm font-mono"
                        style={{ color: "var(--text-muted)" }}
                      >
                        {m.item}
                      </div>
                    </div>
                    <div className="flex flex-col items-end gap-1">
                      <span
                        className={`px-2 py-1 rounded text-xs font-bold ${sc.bg} ${sc.text}`}
                      >
                        {sc.label}
                      </span>
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-sky-500/15 text-sky-500">
                        Cat {m.category}
                      </span>
                    </div>
                  </div>

                  <div className="grid grid-cols-3 gap-2 text-xs">
                    <div className="p-2 rounded" style={innerBoxStyle}>
                      <div style={{ color: "var(--text-muted)" }}>Opened</div>
                      <div
                        className="font-mono"
                        style={{ color: "var(--text-primary)" }}
                      >
                        {fmtDate(m.openedDate)}
                      </div>
                    </div>
                    <div className="p-2 rounded" style={innerBoxStyle}>
                      <div style={{ color: "var(--text-muted)" }}>Due</div>
                      <div
                        className={`font-mono ${
                          isOverdue ? "text-rose-500 font-bold" : ""
                        }`}
                        style={{
                          color: isOverdue ? "#ef4444" : "var(--text-primary)",
                        }}
                      >
                        {fmtDate(m.dueDate) || "—"}
                      </div>
                    </div>
                    <div className="p-2 rounded" style={innerBoxStyle}>
                      <div style={{ color: "var(--text-muted)" }}>
                        Days Left
                      </div>
                      <div
                        className={`font-mono font-bold ${
                          isOverdue
                            ? "text-rose-500"
                            : days <= 3
                            ? "text-amber-500"
                            : "text-emerald-500"
                        }`}
                      >
                        {days !== null
                          ? days < 0
                            ? `${Math.abs(days)} overdue`
                            : `${days}d`
                          : "—"}
                      </div>
                    </div>
                  </div>

                  {m.restrictions && (
                    <div className="p-2 rounded text-xs" style={innerBoxStyle}>
                      <div style={{ color: "var(--text-muted)" }}>
                        Restrictions:
                      </div>
                      <div style={{ color: "var(--text-primary)" }}>
                        {m.restrictions}
                      </div>
                    </div>
                  )}

                  {m.remarks && (
                    <div
                      className="text-xs italic"
                      style={{ color: "var(--text-muted)" }}
                    >
                      📝 {m.remarks}
                    </div>
                  )}

                  {canMelEdit && (
                    <div
                      className="flex gap-2 pt-2"
                      style={{ borderTop: "1px solid var(--border-default)" }}
                    >
                      <button
                        onClick={() => openEditMel(m)}
                        className="flex-1 py-1.5 rounded bg-amber-500/15 text-amber-500 text-xs font-bold flex items-center justify-center gap-1"
                      >
                        <Edit className="w-3.5 h-3.5" /> Edit
                      </button>
                      {m.status === "OPEN" && (
                        <button
                          onClick={() => closeMel(m.id)}
                          className="flex-1 py-1.5 rounded bg-emerald-500/15 text-emerald-500 text-xs font-bold flex items-center justify-center gap-1"
                        >
                          <CheckCircle2 className="w-3.5 h-3.5" /> Close
                        </button>
                      )}
                      <button
                        onClick={() => removeMel(m.id)}
                        className="py-1.5 px-3 rounded bg-rose-500/15 text-rose-500 text-xs"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  )}
                </div>
              );
            })
          )}
        </div>
      )}

      {/* ═══ MODAL: AIRCRAFT ═══ */}
      <Modal
        open={!!editingAircraft}
        title={editingAircraft === "new" ? "Add Aircraft" : "Edit Aircraft"}
        onClose={() => setEditingAircraft(null)}
        wide
        footer={
          <>
            <button
              onClick={() => setEditingAircraft(null)}
              className="px-4 py-2 rounded-lg text-sm font-bold border"
              style={{
                borderColor: "var(--border-default)",
                color: "var(--text-muted)",
              }}
            >
              Cancel
            </button>
            <button
              onClick={saveAircraft}
              className="px-4 py-2 rounded-lg text-sm font-bold text-white flex items-center gap-2"
              style={{ background: "var(--brand-gradient)" }}
            >
              <Save className="w-4 h-4" /> Save
            </button>
          </>
        }
      >
        <div className="space-y-4">
          <div className="grid md:grid-cols-3 gap-3">
            <Field label="Registration">
              <Input
                value={draftAircraft.reg || ""}
                onChange={(e) =>
                  setDraftAircraft({ ...draftAircraft, reg: e.target.value })
                }
              />
            </Field>
            <Field label="Type">
              <Input
                value={draftAircraft.type || ""}
                onChange={(e) =>
                  setDraftAircraft({ ...draftAircraft, type: e.target.value })
                }
              />
            </Field>
            <Field label="Status">
              <Select
                value={draftAircraft.status || "AIRWORTHY"}
                onChange={(e) =>
                  setDraftAircraft({ ...draftAircraft, status: e.target.value })
                }
              >
                <option value="AIRWORTHY">AIRWORTHY</option>
                <option value="GROUNDED">GROUNDED</option>
              </Select>
            </Field>
            <Field label="TAH">
              <Input
                type="number"
                value={draftAircraft.tah || 0}
                onChange={(e) =>
                  setDraftAircraft({ ...draftAircraft, tah: +e.target.value })
                }
              />
            </Field>
            <Field label="TAC">
              <Input
                type="number"
                value={draftAircraft.tac || 0}
                onChange={(e) =>
                  setDraftAircraft({ ...draftAircraft, tac: +e.target.value })
                }
              />
            </Field>
          </div>

          <div className="grid md:grid-cols-4 gap-3">
            <Field label="Last Check">
              <Input
                type="date"
                value={draftAircraft.lastCheckDate || ""}
                onChange={(e) =>
                  setDraftAircraft({
                    ...draftAircraft,
                    lastCheckDate: e.target.value,
                  })
                }
              />
            </Field>
            <Field label="Last Type">
              <Select
                value={draftAircraft.lastCheckType || "A"}
                onChange={(e) =>
                  setDraftAircraft({
                    ...draftAircraft,
                    lastCheckType: e.target.value,
                  })
                }
              >
                {["A", "B", "C", "D"].map((t) => (
                  <option key={t} value={t}>
                    {t}
                  </option>
                ))}
              </Select>
            </Field>
            <Field label="Next Check">
              <Input
                type="date"
                value={draftAircraft.nextCheckDate || ""}
                onChange={(e) =>
                  setDraftAircraft({
                    ...draftAircraft,
                    nextCheckDate: e.target.value,
                  })
                }
              />
            </Field>
            <Field label="Next Type">
              <Select
                value={draftAircraft.nextCheckType || "A"}
                onChange={(e) =>
                  setDraftAircraft({
                    ...draftAircraft,
                    nextCheckType: e.target.value,
                  })
                }
              >
                {["A", "B", "C", "D"].map((t) => (
                  <option key={t} value={t}>
                    {t}
                  </option>
                ))}
              </Select>
            </Field>
          </div>

          <div className="grid md:grid-cols-3 gap-3">
            <Field label="COA Expiry">
              <Input
                type="date"
                value={draftAircraft.coaExpiry || ""}
                onChange={(e) =>
                  setDraftAircraft({
                    ...draftAircraft,
                    coaExpiry: e.target.value,
                  })
                }
              />
            </Field>
            <Field label="Insurance Expiry">
              <Input
                type="date"
                value={draftAircraft.insuranceExpiry || ""}
                onChange={(e) =>
                  setDraftAircraft({
                    ...draftAircraft,
                    insuranceExpiry: e.target.value,
                  })
                }
              />
            </Field>
            <Field label="Noise Cert Expiry">
              <Input
                type="date"
                value={draftAircraft.noiseCertExpiry || ""}
                onChange={(e) =>
                  setDraftAircraft({
                    ...draftAircraft,
                    noiseCertExpiry: e.target.value,
                  })
                }
              />
            </Field>
          </div>

          <div className="grid md:grid-cols-4 gap-3">
            <Field label="Engine 1 (h)">
              <Input
                type="number"
                value={draftAircraft.engine1Hours || 0}
                onChange={(e) =>
                  setDraftAircraft({
                    ...draftAircraft,
                    engine1Hours: +e.target.value,
                  })
                }
              />
            </Field>
            <Field label="Engine 1 (c)">
              <Input
                type="number"
                value={draftAircraft.engine1Cycles || 0}
                onChange={(e) =>
                  setDraftAircraft({
                    ...draftAircraft,
                    engine1Cycles: +e.target.value,
                  })
                }
              />
            </Field>
            <Field label="Engine 2 (h)">
              <Input
                type="number"
                value={draftAircraft.engine2Hours || 0}
                onChange={(e) =>
                  setDraftAircraft({
                    ...draftAircraft,
                    engine2Hours: +e.target.value,
                  })
                }
              />
            </Field>
            <Field label="Engine 2 (c)">
              <Input
                type="number"
                value={draftAircraft.engine2Cycles || 0}
                onChange={(e) =>
                  setDraftAircraft({
                    ...draftAircraft,
                    engine2Cycles: +e.target.value,
                  })
                }
              />
            </Field>
            <Field label="APU (h)">
              <Input
                type="number"
                value={draftAircraft.apuHours || 0}
                onChange={(e) =>
                  setDraftAircraft({
                    ...draftAircraft,
                    apuHours: +e.target.value,
                  })
                }
              />
            </Field>
            <Field label="APU (c)">
              <Input
                type="number"
                value={draftAircraft.apuCycles || 0}
                onChange={(e) =>
                  setDraftAircraft({
                    ...draftAircraft,
                    apuCycles: +e.target.value,
                  })
                }
              />
            </Field>
            <Field label="LLP (h)">
              <Input
                type="number"
                value={draftAircraft.llpHours || 0}
                onChange={(e) =>
                  setDraftAircraft({
                    ...draftAircraft,
                    llpHours: +e.target.value,
                  })
                }
              />
            </Field>
            <Field label="LLP (c)">
              <Input
                type="number"
                value={draftAircraft.llpCycles || 0}
                onChange={(e) =>
                  setDraftAircraft({
                    ...draftAircraft,
                    llpCycles: +e.target.value,
                  })
                }
              />
            </Field>
          </div>

          <Field label="Notes">
            <textarea
              value={draftAircraft.notes || ""}
              onChange={(e) =>
                setDraftAircraft({ ...draftAircraft, notes: e.target.value })
              }
              rows="2"
              className="w-full px-3 py-2 rounded-lg text-sm border outline-none"
              style={{
                borderColor: "var(--border-default)",
                color: "var(--text-primary)",
                backgroundColor: "var(--bg-card)",
              }}
            />
          </Field>
        </div>
      </Modal>

      {/* ═══ MODAL: MEL ═══ */}
      <Modal
        open={!!editingMel}
        title={editingMel === "new" ? "Add MEL Item" : "Edit MEL Item"}
        onClose={() => setEditingMel(null)}
        wide
        footer={
          <>
            <button
              onClick={() => setEditingMel(null)}
              className="px-4 py-2 rounded-lg text-sm font-bold border"
              style={{
                borderColor: "var(--border-default)",
                color: "var(--text-muted)",
              }}
            >
              Cancel
            </button>
            <button
              onClick={saveMel}
              className="px-4 py-2 rounded-lg text-sm font-bold text-white flex items-center gap-2"
              style={{ background: "var(--brand-gradient)" }}
            >
              <Save className="w-4 h-4" /> Save
            </button>
          </>
        }
      >
        <div className="space-y-4">
          <div className="grid md:grid-cols-3 gap-3">
            <Field label="Aircraft Reg">
              <Select
                value={draftMel.reg || ""}
                onChange={(e) =>
                  setDraftMel({ ...draftMel, reg: e.target.value })
                }
              >
                <option value="">—</option>
                {camoList.map((a) => (
                  <option key={a.id} value={a.reg}>
                    {a.reg}
                  </option>
                ))}
              </Select>
            </Field>
            <Field label="MEL Ref">
              <Input
                value={draftMel.melRef || ""}
                onChange={(e) =>
                  setDraftMel({ ...draftMel, melRef: e.target.value })
                }
                placeholder="24-30-01"
              />
            </Field>
            <Field label="Category">
              <Select
                value={draftMel.category || "C"}
                onChange={(e) =>
                  setDraftMel({ ...draftMel, category: e.target.value })
                }
              >
                <option value="A">A (1 day)</option>
                <option value="B">B (3 days)</option>
                <option value="C">C (10 days)</option>
                <option value="D">D (120 days)</option>
              </Select>
            </Field>
          </div>

          <Field label="Item Description">
            <Input
              value={draftMel.item || ""}
              onChange={(e) =>
                setDraftMel({ ...draftMel, item: e.target.value })
              }
              placeholder="APU, Weather Radar, etc."
            />
          </Field>

          <div className="grid md:grid-cols-3 gap-3">
            <Field label="Status">
              <Select
                value={draftMel.status || "OPEN"}
                onChange={(e) =>
                  setDraftMel({ ...draftMel, status: e.target.value })
                }
              >
                <option value="OPEN">OPEN</option>
                <option value="CLOSED">CLOSED</option>
                <option value="DEFERRED">DEFERRED</option>
              </Select>
            </Field>
            <Field label="Opened Date">
              <Input
                type="date"
                value={draftMel.openedDate || ""}
                onChange={(e) =>
                  setDraftMel({ ...draftMel, openedDate: e.target.value })
                }
              />
            </Field>
            <Field label="Due Date (auto)">
              <Input
                type="date"
                value={draftMel.dueDate || ""}
                onChange={(e) =>
                  setDraftMel({ ...draftMel, dueDate: e.target.value })
                }
              />
            </Field>
          </div>

          <Field label="Restrictions">
            <textarea
              value={draftMel.restrictions || ""}
              onChange={(e) =>
                setDraftMel({ ...draftMel, restrictions: e.target.value })
              }
              rows="2"
              className="w-full px-3 py-2 rounded-lg text-sm border outline-none"
              style={{
                borderColor: "var(--border-default)",
                color: "var(--text-primary)",
                backgroundColor: "var(--bg-card)",
              }}
              placeholder="e.g., APU not available, Day VMC only"
            />
          </Field>

          <Field label="Remarks">
            <textarea
              value={draftMel.remarks || ""}
              onChange={(e) =>
                setDraftMel({ ...draftMel, remarks: e.target.value })
              }
              rows="2"
              className="w-full px-3 py-2 rounded-lg text-sm border outline-none"
              style={{
                borderColor: "var(--border-default)",
                color: "var(--text-primary)",
                backgroundColor: "var(--bg-card)",
              }}
            />
          </Field>
        </div>
      </Modal>
    </div>
  );
}

export default CAMOModule;
