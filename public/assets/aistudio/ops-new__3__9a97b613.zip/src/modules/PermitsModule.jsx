/* ═══════════════════════════════════════════════════════════
 * PERMITS MODULE — v2.4 (بدون AI — لتفادي مشاكل LSP)
 * ═══════════════════════════════════════════════════════════ */
import React, { useState, useEffect, useMemo } from "react";
import {
  Plus,
  Edit,
  Trash2,
  Search,
  Save,
  FileSignature,
  Plane,
  Globe,
  Download,
  Upload,
  Paperclip,
  X,
  BookOpen,
  ChevronRight,
  CheckCircle2,
  AlertTriangle,
  Calendar,
  MapPin,
  MousePointer2,
} from "lucide-react";
import { useT, useAuth } from "../contexts";
import { Field } from "../components/ui/Field";
import { Input } from "../components/ui/Input";
import { Select } from "../components/ui/Select";
import { Modal } from "../components/ui/Modal";
import { permitTemplatesAPI, flightPermitsAPI, uploadFile } from "../api";
import { can as checkPerm } from "../config/permissions";
import { fmtDate, daysUntil } from "../utils/helpers";
import {
  getCountryFromAirport,
  getAvailableCountries,
} from "../config/airportCountries";

/* ⭐ Modals — بدون AI */
import { PermitPrintModal } from "../components/PermitPrintModal";
import { PermitEditModal } from "../components/PermitEditModal";
import { PermitGenerateModal } from "../components/PermitGenerateModal";
import { PDFFieldMapper } from "../components/PDFFieldMapper";

/* ═══ Styles ═══ */
const cardStyle = {
  backgroundColor: "var(--bg-card)",
  border: "1px solid var(--border-default)",
  boxShadow: "var(--shadow-sm)",
};
const innerBoxStyle = {
  backgroundColor: "var(--bg-app)",
  border: "1px solid var(--border-default)",
};

const PERMIT_TYPES = [
  "OVERFLIGHT",
  "LANDING",
  "DIPLOMATIC",
  "TECHNICAL",
  "CHARTER",
  "CARGO",
];

const STATUS_COLORS = {
  ACTIVE: "bg-emerald-500/15 text-emerald-500",
  EXPIRED: "bg-rose-500/15 text-rose-500",
  PENDING: "bg-amber-500/15 text-amber-500",
  SUSPENDED: "bg-slate-500/15 text-slate-400",
  DRAFT: "bg-sky-500/15 text-sky-500",
  FINAL: "bg-emerald-500/15 text-emerald-500",
};

/* ═══ MAIN COMPONENT ═══ */
export function PermitsModule({
  flights,
  fleet,
  crew,
  settings,
  user,
  setSyncStatus,
}) {
  const [view, setView] = useState("home");

  if (view === "library") {
    return (
      <PermitsLibrary
        user={user}
        setSyncStatus={setSyncStatus}
        onBack={() => setView("home")}
      />
    );
  }
  if (view === "flight-permits") {
    return (
      <FlightPermits
        flights={flights}
        crew={crew || []}
        settings={settings || {}}
        user={user}
        setSyncStatus={setSyncStatus}
        onBack={() => setView("home")}
      />
    );
  }

  return (
    <div className="p-6 max-w-5xl mx-auto fade-in">
      <div className="text-center mb-8">
        <h1
          className="text-3xl font-bold"
          style={{ color: "var(--text-primary)" }}
        >
          📜 Permits Management
        </h1>
        <p className="text-sm mt-2" style={{ color: "var(--text-muted)" }}>
          Choose what you want to do
        </p>
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        <button
          onClick={() => setView("library")}
          className="group p-6 rounded-2xl text-start transition hover:-translate-y-1 hover:shadow-xl"
          style={{
            backgroundColor: "var(--bg-card)",
            border: "2px solid var(--border-default)",
          }}
        >
          <div className="flex items-start gap-4 mb-4">
            <div
              className="w-14 h-14 rounded-xl flex items-center justify-center flex-shrink-0"
              style={{ background: "var(--brand-gradient)" }}
            >
              <BookOpen className="w-8 h-8 text-white" />
            </div>
            <div className="flex-1">
              <h2
                className="text-xl font-bold mb-1"
                style={{ color: "var(--text-primary)" }}
              >
                Permits Library
              </h2>
              <p className="text-xs" style={{ color: "var(--text-muted)" }}>
                مكتبة التصاريح لكل دولة
              </p>
            </div>
          </div>
          <ul
            className="space-y-1.5 text-sm"
            style={{ color: "var(--text-muted)" }}
          >
            <li className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-500" /> Templates
              for each country
            </li>
            <li className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-500" /> Upload CAA
              attachments
            </li>
            <li className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-500" /> Edit /
              Download / Use
            </li>
          </ul>
          <div
            className="mt-4 text-sm font-bold flex items-center gap-1"
            style={{ color: "var(--brand-primary)" }}
          >
            Open Library <ChevronRight className="w-4 h-4" />
          </div>
        </button>

        <button
          onClick={() => setView("flight-permits")}
          className="group p-6 rounded-2xl text-start transition hover:-translate-y-1 hover:shadow-xl"
          style={{
            backgroundColor: "var(--bg-card)",
            border: "2px solid var(--border-default)",
          }}
        >
          <div className="flex items-start gap-4 mb-4">
            <div
              className="w-14 h-14 rounded-xl flex items-center justify-center flex-shrink-0"
              style={{
                background: "linear-gradient(135deg, #3b82f6, #8b5cf6)",
              }}
            >
              <Plane className="w-8 h-8 text-white" />
            </div>
            <div className="flex-1">
              <h2
                className="text-xl font-bold mb-1"
                style={{ color: "var(--text-primary)" }}
              >
                Flight Permits
              </h2>
              <p className="text-xs" style={{ color: "var(--text-muted)" }}>
                تصاريح الرحلات الحالية
              </p>
            </div>
          </div>
          <ul
            className="space-y-1.5 text-sm"
            style={{ color: "var(--text-muted)" }}
          >
            <li className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-sky-500" /> Auto-detect
              countries from route
            </li>
            <li className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-sky-500" /> Auto-fill from
              flight data
            </li>
            <li className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-sky-500" /> Generate &
              download PDFs
            </li>
          </ul>
          <div
            className="mt-4 text-sm font-bold flex items-center gap-1"
            style={{ color: "var(--brand-primary)" }}
          >
            Open Flight Permits <ChevronRight className="w-4 h-4" />
          </div>
        </button>
      </div>
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════
 * PERMITS LIBRARY
 * ═══════════════════════════════════════════════════════════ */
function PermitsLibrary({ user, setSyncStatus, onBack }) {
  const [templates, setTemplates] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [editing, setEditing] = useState(null);
  const [draft, setDraft] = useState({});
  const [airportHint, setAirportHint] = useState("");
  const [mappingPdf, setMappingPdf] = useState(null);

  const canEdit = checkPerm(user, "permits.edit");
  const canCreate = checkPerm(user, "permits.create");
  const canDelete = checkPerm(user, "permits.delete");

  const AVAILABLE_COUNTRIES = useMemo(() => getAvailableCountries(), []);

  const loadData = async () => {
    setLoading(true);
    try {
      const list = await permitTemplatesAPI.list().catch(() => []);
      setTemplates(list);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const openNew = () => {
    if (!canCreate) return alert("⚠️ ليس لديك صلاحية");
    setDraft({
      country: "",
      name: "",
      permitType: "OVERFLIGHT",
      fields: [],
      flightFields: [],
      attachments: [],
      notes: "",
    });
    setAirportHint("");
    setEditing("new");
  };

  const openEdit = (tpl) => {
    if (!canEdit) return alert("⚠️ ليس لديك صلاحية");
    setDraft({ ...tpl });
    setAirportHint("");
    setEditing(tpl.id);
  };

  const handleAirportHint = (icao) => {
    setAirportHint(icao);
    if (icao.length >= 2) {
      const detected = getCountryFromAirport(icao);
      if (detected && detected !== icao)
        setDraft({ ...draft, country: detected });
    }
  };

  const save = async () => {
    if (!draft.country || !draft.name)
      return alert("⚠️ الدولة + الاسم مطلوبان");
    setSyncStatus?.("syncing");
    try {
      if (editing === "new") {
        const created = await permitTemplatesAPI.create(draft);
        setTemplates([...templates, { ...draft, id: created.id }]);
      } else {
        await permitTemplatesAPI.update(editing, draft);
        setTemplates(
          templates.map((x) =>
            x.id === editing ? { ...draft, id: editing } : x
          )
        );
      }
      setEditing(null);
      setSyncStatus?.("synced");
    } catch (e) {
      alert("فشل: " + e.message);
    }
  };

  const remove = async (id) => {
    if (!canDelete) return alert("⚠️ ليس لديك صلاحية");
    if (!confirm("حذف هذا القالب؟")) return;
    try {
      await permitTemplatesAPI.remove(id);
      setTemplates(templates.filter((x) => x.id !== id));
    } catch (e) {
      alert("فشل: " + e.message);
    }
  };

  const uploadPdf = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 10 * 1024 * 1024) return alert("⚠️ الحد الأقصى 10 MB");
    try {
      const result = await uploadFile(file, "permits-templates");
      setDraft({
        ...draft,
        attachments: [
          ...(draft.attachments || []),
          {
            name: file.name,
            url: result.fileUrl,
            size: result.size,
            type: file.type,
          },
        ],
      });
    } catch (e) {
      alert("فشل الرفع: " + e.message);
    }
    e.target.value = "";
  };

  const grouped = useMemo(() => {
    const map = {};
    templates
      .filter(
        (t) =>
          !search ||
          (t.country + t.name).toLowerCase().includes(search.toLowerCase())
      )
      .forEach((t) => {
        if (!map[t.country]) map[t.country] = [];
        map[t.country].push(t);
      });
    return Object.entries(map).sort(([a], [b]) => a.localeCompare(b));
  }, [templates, search]);

  return (
    <div className="space-y-4 fade-in">
      <div className="rounded-xl p-3" style={cardStyle}>
        <div className="flex flex-wrap gap-2 items-center justify-between mb-3">
          <div className="flex items-center gap-3">
            <button
              onClick={onBack}
              className="p-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-700"
            >
              <ChevronRight
                className="w-5 h-5 rotate-180"
                style={{ color: "var(--text-muted)" }}
              />
            </button>
            <div
              className="w-10 h-10 rounded-lg flex items-center justify-center shadow-md"
              style={{ background: "var(--brand-gradient)" }}
            >
              <BookOpen className="w-6 h-6 text-white" />
            </div>
            <div>
              <h2
                className="text-lg font-bold"
                style={{ color: "var(--text-primary)" }}
              >
                Permits Library
              </h2>
              <p className="text-xs" style={{ color: "var(--text-muted)" }}>
                {grouped.length} countries · {templates.length} templates
              </p>
            </div>
          </div>
          {canCreate && (
            <button
              onClick={openNew}
              className="flex items-center gap-1.5 px-4 py-2 rounded-lg text-sm font-bold text-white"
              style={{ background: "var(--brand-gradient)" }}
            >
              <Plus className="w-4 h-4" /> Add Template
            </button>
          )}
        </div>
        <div className="relative">
          <Search
            className="w-4 h-4 absolute top-1/2 -translate-y-1/2 start-3"
            style={{ color: "var(--text-muted)" }}
          />
          <Input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search country, template..."
            className="ps-9"
          />
        </div>
      </div>

      {loading ? (
        <div
          className="text-center py-12"
          style={{ color: "var(--text-muted)" }}
        >
          Loading...
        </div>
      ) : grouped.length === 0 ? (
        <div className="text-center py-12 rounded-xl" style={cardStyle}>
          <BookOpen
            className="w-12 h-12 mx-auto mb-2 opacity-30"
            style={{ color: "var(--text-muted)" }}
          />
          <div style={{ color: "var(--text-muted)" }}>No templates yet</div>
        </div>
      ) : (
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
          {grouped.map(([country, list]) => (
            <div
              key={country}
              className="rounded-xl overflow-hidden"
              style={cardStyle}
            >
              <div
                className="p-3 border-b flex items-center gap-2"
                style={{
                  backgroundColor: "var(--bg-app)",
                  borderColor: "var(--border-default)",
                }}
              >
                <Globe
                  className="w-5 h-5"
                  style={{ color: "var(--brand-primary)" }}
                />
                <div>
                  <div
                    className="font-bold"
                    style={{ color: "var(--text-primary)" }}
                  >
                    {country}
                  </div>
                  <div
                    className="text-[10px]"
                    style={{ color: "var(--text-muted)" }}
                  >
                    {list.length} templates
                  </div>
                </div>
              </div>
              <div className="p-3 space-y-2">
                {list.map((tpl) => {
                  const pdfAtt = (tpl.attachments || []).find(
                    (a) => a.type === "application/pdf"
                  );
                  const hasMappedFields =
                    Array.isArray(tpl.fields) && tpl.fields.length > 0;
                  return (
                    <div
                      key={tpl.id}
                      className="p-2 rounded-lg border text-xs"
                      style={innerBoxStyle}
                    >
                      <div
                        className="font-bold"
                        style={{ color: "var(--text-primary)" }}
                      >
                        {tpl.name}
                      </div>
                      <div
                        className="text-[10px] mb-1"
                        style={{ color: "var(--text-muted)" }}
                      >
                        {tpl.permitType} · {(tpl.fields || []).length} fields
                      </div>
                      {(tpl.attachments || []).length > 0 && (
                        <div className="text-[10px] text-purple-500">
                          📎 {tpl.attachments.length} attachments
                        </div>
                      )}
                      {pdfAtt && hasMappedFields && (
                        <div className="text-[10px] text-emerald-500">
                          ✅ PDF mapped ({tpl.fields.length} fields)
                        </div>
                      )}
                      <div className="flex gap-1 mt-2">
                        {(tpl.attachments || []).length > 0 && (
                          <button
                            onClick={() =>
                              window.open(tpl.attachments[0].url, "_blank")
                            }
                            className="flex-1 py-1 rounded bg-sky-500/15 text-sky-500 text-[10px] font-bold"
                          >
                            <Download className="w-3 h-3 inline" /> PDF
                          </button>
                        )}
                        {canEdit && (
                          <button
                            onClick={() => openEdit(tpl)}
                            className="p-1 rounded bg-amber-500/15 text-amber-500"
                          >
                            <Edit className="w-3 h-3" />
                          </button>
                        )}
                        {canDelete && (
                          <button
                            onClick={() => remove(tpl.id)}
                            className="p-1 rounded bg-rose-500/15 text-rose-500"
                          >
                            <Trash2 className="w-3 h-3" />
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          ))}
        </div>
      )}

      <Modal
        open={!!editing}
        title={editing === "new" ? "Add Template" : "Edit Template"}
        onClose={() => setEditing(null)}
        wide
        footer={
          <>
            <button
              onClick={() => setEditing(null)}
              className="px-4 py-2 rounded-lg text-sm font-bold border"
              style={{
                borderColor: "var(--border-default)",
                color: "var(--text-muted)",
              }}
            >
              Cancel
            </button>
            <button
              onClick={save}
              className="px-4 py-2 rounded-lg text-sm font-bold text-white flex items-center gap-2"
              style={{ background: "var(--brand-gradient)" }}
            >
              <Save className="w-4 h-4" /> Save
            </button>
          </>
        }
      >
        <div className="space-y-4">
          <div className="p-3 rounded-lg bg-sky-500/10 border border-sky-500/30">
            <h4
              className="text-sm font-bold mb-2 flex items-center gap-2"
              style={{ color: "var(--text-primary)" }}
            >
              <MapPin
                className="w-4 h-4"
                style={{ color: "var(--brand-primary)" }}
              />{" "}
              Country Detection
            </h4>
            <p
              className="text-[11px] mb-3"
              style={{ color: "var(--text-muted)" }}
            >
              اكتب كود مطار ICAO ليتم اكتشاف الدولة تلقائياً، أو اخترها من
              القائمة
            </p>
            <div className="grid md:grid-cols-2 gap-3">
              <Field label="Airport ICAO (optional)">
                <Input
                  value={airportHint}
                  onChange={(e) =>
                    handleAirportHint(e.target.value.toUpperCase())
                  }
                  placeholder="HLLT, LIRF, HECA..."
                  maxLength={4}
                  className="font-mono"
                />
              </Field>
              <Field label="Country *">
                <Select
                  value={draft.country || ""}
                  onChange={(e) =>
                    setDraft({ ...draft, country: e.target.value })
                  }
                >
                  <option value="">— Select Country —</option>
                  {AVAILABLE_COUNTRIES.map((c) => (
                    <option key={c} value={c}>
                      {c}
                    </option>
                  ))}
                </Select>
              </Field>
            </div>
            {airportHint && airportHint.length >= 2 && (
              <div
                className="mt-2 text-[11px] flex items-center gap-2"
                style={{ color: "var(--brand-primary)" }}
              >
                <CheckCircle2 className="w-3.5 h-3.5" />
                {draft.country
                  ? `Detected: ${airportHint} → ${draft.country}`
                  : `Airport ${airportHint} → Not in database`}
              </div>
            )}
          </div>

          <div className="grid md:grid-cols-2 gap-3">
            <Field label="Template Name *">
              <Input
                value={draft.name || ""}
                onChange={(e) => setDraft({ ...draft, name: e.target.value })}
                placeholder="Libyan Overflight"
              />
            </Field>
            <Field label="Permit Type">
              <Select
                value={draft.permitType || "OVERFLIGHT"}
                onChange={(e) =>
                  setDraft({ ...draft, permitType: e.target.value })
                }
              >
                {PERMIT_TYPES.map((pt) => (
                  <option key={pt} value={pt}>
                    {pt}
                  </option>
                ))}
              </Select>
            </Field>
          </div>

          <Field label="Notes">
            <textarea
              value={draft.notes || ""}
              onChange={(e) => setDraft({ ...draft, notes: e.target.value })}
              rows="2"
              className="w-full px-3 py-2 rounded-lg text-sm border outline-none"
              style={{
                borderColor: "var(--border-default)",
                color: "var(--text-primary)",
                backgroundColor: "var(--bg-app)",
              }}
            />
          </Field>

          <div>
            <h4 className="text-sm font-bold mb-2">📎 Attachments</h4>
            {(draft.attachments || []).map((att, i) => {
              const isPdf = att.type === "application/pdf";
              return (
                <div
                  key={i}
                  className="flex items-center gap-2 p-2 mb-1 rounded text-xs"
                  style={innerBoxStyle}
                >
                  <Paperclip className="w-3.5 h-3.5" />
                  <span
                    className="flex-1 truncate"
                    style={{ color: "var(--text-primary)" }}
                  >
                    {att.name}
                  </span>
                  {isPdf && (
                    <button
                      type="button"
                      onClick={() => setMappingPdf(att)}
                      className="px-2 py-1 rounded bg-purple-500/15 text-purple-500 text-[10px] font-bold flex items-center gap-1"
                      title="تحديد مواضع الحقول على PDF"
                    >
                      <MousePointer2 className="w-3 h-3" /> Map{" "}
                      {Array.isArray(draft.fields) &&
                        draft.fields.length > 0 && (
                          <span className="px-1 rounded bg-purple-500/30 text-[9px]">
                            {draft.fields.length}
                          </span>
                        )}
                    </button>
                  )}
                  <button
                    type="button"
                    onClick={() => window.open(att.url, "_blank")}
                    className="text-sky-500"
                  >
                    <Download className="w-3 h-3" />
                  </button>
                  <button
                    type="button"
                    onClick={() =>
                      setDraft({
                        ...draft,
                        attachments: draft.attachments.filter(
                          (_, idx) => idx !== i
                        ),
                      })
                    }
                    className="text-rose-500"
                  >
                    <X className="w-3 h-3" />
                  </button>
                </div>
              );
            })}
            <label
              className="flex items-center justify-center gap-2 p-2 rounded cursor-pointer border-2 border-dashed text-xs font-bold"
              style={{
                borderColor: "var(--border-default)",
                color: "var(--brand-primary)",
              }}
            >
              <Upload className="w-4 h-4" /> Upload PDF / Image
              <input
                type="file"
                accept="application/pdf,image/*"
                onChange={uploadPdf}
                className="hidden"
              />
            </label>
            {Array.isArray(draft.fields) && draft.fields.length > 0 && (
              <div className="mt-2 p-2 rounded bg-emerald-500/10 border border-emerald-500/30">
                <div className="text-[11px] font-bold text-emerald-500 mb-1">
                  ✅ {draft.fields.length} حقل محفوظ — جاهز للتعبئة التلقائية
                </div>
                <div className="flex flex-wrap gap-1">
                  {draft.fields.map((f) => (
                    <span
                      key={f.key}
                      className="px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-600 text-[9px] font-mono"
                    >
                      {f.key}
                    </span>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </Modal>

      {mappingPdf && (
        <PDFFieldMapper
          pdfUrl={mappingPdf.url}
          initialFields={Array.isArray(draft.fields) ? draft.fields : []}
          onSave={(fields) => {
            setDraft({ ...draft, fields });
            setMappingPdf(null);
            alert(`✅ تم حفظ ${fields.length} حقل — جاهز للتعبئة التلقائية`);
          }}
          onClose={() => setMappingPdf(null)}
        />
      )}
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════
 * FLIGHT PERMITS
 * ═══════════════════════════════════════════════════════════ */
function FlightPermits({
  flights,
  crew = [],
  settings = {},
  user,
  setSyncStatus,
  onBack,
}) {
  const [selectedFlight, setSelectedFlight] = useState(null);
  const [permits, setPermits] = useState([]);
  const [templates, setTemplates] = useState([]);
  const [loading, setLoading] = useState(false);
  const [editingPermit, setEditingPermit] = useState(null);
  const [printPermit, setPrintPermit] = useState(null);
  const [generatingPermit, setGeneratingPermit] = useState(null);

  useEffect(() => {
    (async () => {
      const tpls = await permitTemplatesAPI.list().catch(() => []);
      setTemplates(tpls);
    })();
  }, []);

  useEffect(() => {
    if (!selectedFlight) return;
    (async () => {
      setLoading(true);
      try {
        const list = await flightPermitsAPI
          .listByFlight(selectedFlight.id)
          .catch(() => []);
        setPermits(list);
      } finally {
        setLoading(false);
      }
    })();
  }, [selectedFlight]);

  const detectedCountries = useMemo(() => {
    if (!selectedFlight) return [];
    const airports = [
      { code: selectedFlight.dep, label: "Departure" },
      { code: selectedFlight.arr, label: "Arrival" },
    ].filter((x) => x.code);
    const countries = [];
    airports.forEach(({ code }) => {
      const country = getCountryFromAirport(code);
      if (country && !countries.find((c) => c.name === country))
        countries.push({ name: country, airport: code });
    });
    return countries;
  }, [selectedFlight]);

  const openGenerator = (country, template) => {
    setGeneratingPermit({ country, template });
  };

  const saveGeneratedPermit = async (data) => {
    try {
      await flightPermitsAPI.create({
        flightId: selectedFlight.id,
        country: data.country,
        permitType: data.permitType,
        permitNo: data.permitNo,
        issuedDate: data.issuedDate,
        expiryDate: data.expiryDate,
        issuedBy: data.issuedBy,
        customFields: data.customFields,
        attachments: [],
        status: data.status,
        notes: data.notes,
        updatedBy: user.fullName || "",
      });
      const list = await flightPermitsAPI.listByFlight(selectedFlight.id);
      setPermits(list);
      setGeneratingPermit(null);
    } catch (e) {
      alert("فشل: " + e.message);
      throw e;
    }
  };

  return (
    <div className="space-y-4 fade-in">
      <div className="rounded-xl p-3" style={cardStyle}>
        <div className="flex flex-wrap gap-2 items-center justify-between mb-3">
          <div className="flex items-center gap-3">
            <button
              onClick={onBack}
              className="p-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-700"
            >
              <ChevronRight
                className="w-5 h-5 rotate-180"
                style={{ color: "var(--text-muted)" }}
              />
            </button>
            <div
              className="w-10 h-10 rounded-lg flex items-center justify-center shadow-md"
              style={{
                background: "linear-gradient(135deg, #3b82f6, #8b5cf6)",
              }}
            >
              <Plane className="w-6 h-6 text-white" />
            </div>
            <div>
              <h2
                className="text-lg font-bold"
                style={{ color: "var(--text-primary)" }}
              >
                Flight Permits
              </h2>
              <p className="text-xs" style={{ color: "var(--text-muted)" }}>
                Select a flight to generate permits
              </p>
            </div>
          </div>
        </div>
        <Field label="Select Flight">
          <Select
            value={selectedFlight?.id || ""}
            onChange={(e) => {
              const f = flights.find((x) => x.id === e.target.value);
              setSelectedFlight(f || null);
            }}
          >
            <option value="">— Select Flight —</option>
            {flights.map((f) => (
              <option key={f.id} value={f.id}>
                {f.flightNo} — {f.dep} → {f.arr} (
                {f.std ? String(f.std).slice(0, 10) : "—"})
              </option>
            ))}
          </Select>
        </Field>
      </div>

      {selectedFlight && (
        <>
          <div className="rounded-xl p-3" style={cardStyle}>
            <div className="grid md:grid-cols-4 gap-3 text-sm">
              <div>
                <div
                  className="text-[10px]"
                  style={{ color: "var(--text-muted)" }}
                >
                  Flight
                </div>
                <div
                  className="font-bold font-mono"
                  style={{ color: "var(--text-primary)" }}
                >
                  {selectedFlight.flightNo}
                </div>
              </div>
              <div>
                <div
                  className="text-[10px]"
                  style={{ color: "var(--text-muted)" }}
                >
                  Route
                </div>
                <div
                  className="font-bold font-mono"
                  style={{ color: "var(--text-primary)" }}
                >
                  {selectedFlight.dep} → {selectedFlight.arr}
                </div>
              </div>
              <div>
                <div
                  className="text-[10px]"
                  style={{ color: "var(--text-muted)" }}
                >
                  Date
                </div>
                <div
                  className="font-bold"
                  style={{ color: "var(--text-primary)" }}
                >
                  {fmtDate(selectedFlight.std)}
                </div>
              </div>
              <div>
                <div
                  className="text-[10px]"
                  style={{ color: "var(--text-muted)" }}
                >
                  Aircraft
                </div>
                <div
                  className="font-bold font-mono"
                  style={{ color: "var(--text-primary)" }}
                >
                  {selectedFlight.acft || "—"}
                </div>
              </div>
            </div>
          </div>

          <div className="rounded-xl p-3" style={cardStyle}>
            <h3
              className="text-sm font-bold mb-2 flex items-center gap-2"
              style={{ color: "var(--text-primary)" }}
            >
              <MapPin
                className="w-4 h-4"
                style={{ color: "var(--brand-primary)" }}
              />{" "}
              Detected Countries (from airports)
            </h3>
            <div className="flex flex-wrap gap-2">
              {detectedCountries.map(({ name: country, airport }) => {
                const hasPermit = permits.some((p) => p.country === country);
                const tpls = templates.filter((t) => t.country === country);
                return (
                  <div
                    key={country}
                    className="flex-1 min-w-[220px] p-3 rounded-lg border"
                    style={innerBoxStyle}
                  >
                    <div className="flex items-center gap-2 mb-2">
                      <Globe
                        className="w-4 h-4"
                        style={{ color: "var(--brand-primary)" }}
                      />
                      <div className="flex-1">
                        <div
                          className="font-bold"
                          style={{ color: "var(--text-primary)" }}
                        >
                          {country}
                        </div>
                        <div
                          className="text-[10px] font-mono"
                          style={{ color: "var(--text-muted)" }}
                        >
                          via {airport}
                        </div>
                      </div>
                      {hasPermit ? (
                        <span className="px-2 py-0.5 rounded text-[10px] bg-emerald-500/15 text-emerald-500 font-bold">
                          ✓ Has permit
                        </span>
                      ) : (
                        <span className="px-2 py-0.5 rounded text-[10px] bg-amber-500/15 text-amber-500 font-bold">
                          ⚠ No permit
                        </span>
                      )}
                    </div>
                    {!hasPermit &&
                      (tpls.length > 0 ? (
                        <div className="space-y-1">
                          {tpls.map((tpl) => (
                            <button
                              key={tpl.id}
                              onClick={() => openGenerator(country, tpl)}
                              className="w-full text-start px-2 py-1.5 rounded text-xs font-bold bg-sky-500/15 text-sky-500 hover:bg-sky-500/25"
                            >
                              <Plus className="w-3 h-3 inline" /> Generate:{" "}
                              {tpl.name}
                            </button>
                          ))}
                        </div>
                      ) : (
                        <div
                          className="text-[10px]"
                          style={{ color: "var(--text-muted)" }}
                        >
                          ⚠ No template for {country}. Add one in Library.
                        </div>
                      ))}
                  </div>
                );
              })}
            </div>
          </div>

          {loading ? (
            <div
              className="text-center py-8"
              style={{ color: "var(--text-muted)" }}
            >
              Loading permits...
            </div>
          ) : permits.length > 0 ? (
            <div className="space-y-2">
              <h3
                className="text-sm font-bold"
                style={{ color: "var(--text-primary)" }}
              >
                Generated Permits ({permits.length})
              </h3>
              {permits.map((p) => {
                const statusColor =
                  STATUS_COLORS[p.status] || STATUS_COLORS.DRAFT;
                return (
                  <div
                    key={p.id}
                    className="p-3 rounded-lg border"
                    style={cardStyle}
                  >
                    <div className="flex justify-between items-start">
                      <div>
                        <div className="flex items-center gap-2">
                          <Globe
                            className="w-4 h-4"
                            style={{ color: "var(--brand-primary)" }}
                          />
                          <span
                            className="font-bold"
                            style={{ color: "var(--text-primary)" }}
                          >
                            {p.country}
                          </span>
                          <span
                            className={`px-2 py-0.5 rounded text-[10px] font-bold ${statusColor}`}
                          >
                            {p.status}
                          </span>
                          <span className="px-2 py-0.5 rounded text-[10px] bg-slate-500/15 text-slate-400">
                            {p.permitType}
                          </span>
                        </div>
                        <div
                          className="text-xs mt-1"
                          style={{ color: "var(--text-muted)" }}
                        >
                          {p.permitNo || "No permit no."} ·{" "}
                          {p.issuedBy || "No issuer"}
                        </div>
                      </div>
                      <div
                        className="text-xs"
                        style={{ color: "var(--text-muted)" }}
                      >
                        {p.expiryDate
                          ? `Expires: ${fmtDate(p.expiryDate)}`
                          : "No expiry"}
                      </div>
                    </div>
                    <div
                      className="flex gap-2 mt-3 pt-2 border-t"
                      style={{ borderColor: "var(--border-default)" }}
                    >
                      <button
                        onClick={() => setEditingPermit(p)}
                        className="flex-1 py-1.5 rounded bg-amber-500/15 text-amber-500 text-[11px] font-bold flex items-center justify-center gap-1"
                      >
                        <Edit className="w-3.5 h-3.5" /> Edit
                      </button>
                      <button
                        onClick={() => setPrintPermit(p)}
                        className="flex-1 py-1.5 rounded bg-sky-500/15 text-sky-500 text-[11px] font-bold flex items-center justify-center gap-1"
                      >
                        <FileSignature className="w-3.5 h-3.5" /> Print
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          ) : null}
        </>
      )}

      {generatingPermit && (
        <PermitGenerateModal
          template={generatingPermit.template}
          flight={selectedFlight}
          crew={crew}
          settings={settings}
          user={user}
          onClose={() => setGeneratingPermit(null)}
          onSave={saveGeneratedPermit}
        />
      )}

      {editingPermit && (
        <PermitEditModal
          permit={editingPermit}
          flight={selectedFlight}
          user={user}
          onClose={() => setEditingPermit(null)}
          onSave={async (updated) => {
            try {
              await flightPermitsAPI.update(updated.id, updated);
              const list = await flightPermitsAPI.listByFlight(
                selectedFlight.id
              );
              setPermits(list);
              setEditingPermit(null);
            } catch (e) {
              alert("فشل: " + e.message);
            }
          }}
        />
      )}

      {printPermit && (
        <PermitPrintModal
          permit={printPermit}
          flight={selectedFlight}
          crew={crew}
          settings={settings}
          user={user}
          onClose={() => setPrintPermit(null)}
        />
      )}
    </div>
  );
}

export default PermitsModule;
