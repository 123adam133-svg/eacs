/* ═══════════════════════════════════════════════════════════
 * PDF FILLER — v3.1
 * تعبئة PDF المرفق — مع تجاوز CORS عبر Apps Script
 * ═══════════════════════════════════════════════════════════ */

const API_URL =
  "https://script.google.com/macros/s/AKfycbyWvE4E4dCzWIpm4t6Vul_27CqqYQJ1MsKIUVDZVxAdGogXf76MlR0_Bzs1WHtqYvEXQQ/exec";

/**
 * استخراج fileId من أي رابط Google Drive
 */
export function extractFileId(url) {
  if (!url) return null;
  const str = String(url).trim();

  const patterns = [
    /\/d\/([^/]+)/,
    /[?&]id=([^&]+)/,
    /lh3\.googleusercontent\.com\/d\/([^/?]+)/,
  ];

  for (const pattern of patterns) {
    const match = str.match(pattern);
    if (match) return match[1];
  }
  return null;
}

/**
 * تحميل PDF bytes — عبر 3 طرق:
 *   1. Apps Script getPDFBase64 (الأفضل — لا CORS)
 *   2. الرابط المباشر
 *   3. CORS proxy
 */
export async function fetchPDFBytes(pdfUrl) {
  console.log("═══════════════════════════════════════════");
  console.log("📄 fetchPDFBytes:");
  console.log("  URL:", pdfUrl);

  const fileId = extractFileId(pdfUrl);
  console.log("  fileId:", fileId);

  if (!fileId) {
    throw new Error("لا يمكن استخراج fileId من الرابط");
  }

  /* ═══ الطريقة 1: Apps Script getPDFBase64 ═══ */
  try {
    console.log("  🌐 Method 1: Apps Script getPDFBase64...");
    const apiUrl = `${API_URL}?action=getPDF&fileId=${fileId}`;

    const response = await fetch(apiUrl, {
      method: "GET",
      redirect: "follow",
    });

    if (!response.ok) {
      throw new Error(`HTTP ${response.status}`);
    }

    const text = await response.text();
    console.log("  Response length:", text.length);

    // تحقق أنه JSON
    if (!text.trim().startsWith("{")) {
      throw new Error("Response is not JSON");
    }

    const result = JSON.parse(text);

    if (!result.ok) {
      throw new Error(result.error || "Apps Script error");
    }

    if (!result.base64) {
      throw new Error("No base64 in response");
    }

    console.log("  Base64 length:", result.base64.length);
    console.log("  Size:", result.size);

    // تحويل base64 → Uint8Array
    const binaryString = atob(result.base64);
    const bytes = new Uint8Array(binaryString.length);
    for (let i = 0; i < binaryString.length; i++) {
      bytes[i] = binaryString.charCodeAt(i);
    }

    // تحقق من PDF header
    const header = new TextDecoder().decode(bytes.slice(0, 8));
    console.log("  First 8 bytes:", JSON.stringify(header));

    if (!header.startsWith("%PDF-")) {
      throw new Error(`Not a PDF. Header: "${header}"`);
    }

    console.log("  ✅ Method 1 SUCCESS");
    console.log("═══════════════════════════════════════════");
    return bytes.buffer;
  } catch (err) {
    console.warn("  ❌ Method 1 failed:", err.message);
  }

  /* ═══ الطريقة 2: fetch مباشر ═══ */
  try {
    console.log("  🌐 Method 2: Direct fetch...");
    const directUrl = `https://drive.google.com/uc?export=download&confirm=t&id=${fileId}`;

    const response = await fetch(directUrl, {
      method: "GET",
      redirect: "follow",
    });

    if (!response.ok) {
      throw new Error(`HTTP ${response.status}`);
    }

    const arrayBuffer = await response.arrayBuffer();
    const header = new TextDecoder().decode(arrayBuffer.slice(0, 8));

    if (!header.startsWith("%PDF-")) {
      throw new Error(`Not a PDF. Header: "${header}"`);
    }

    console.log("  ✅ Method 2 SUCCESS");
    return arrayBuffer;
  } catch (err) {
    console.warn("  ❌ Method 2 failed:", err.message);
  }

  /* ═══ الطريقة 3: CORS proxy ═══ */
  try {
    console.log("  🌐 Method 3: CORS proxy...");
    const directUrl = `https://drive.google.com/uc?export=download&confirm=t&id=${fileId}`;
    const proxyUrl = `https://corsproxy.io/?${encodeURIComponent(directUrl)}`;

    const response = await fetch(proxyUrl);
    if (!response.ok) throw new Error(`HTTP ${response.status}`);

    const arrayBuffer = await response.arrayBuffer();
    const header = new TextDecoder().decode(arrayBuffer.slice(0, 8));

    if (!header.startsWith("%PDF-")) {
      throw new Error(`Not a PDF. Header: "${header}"`);
    }

    console.log("  ✅ Method 3 SUCCESS");
    return arrayBuffer;
  } catch (err) {
    console.warn("  ❌ Method 3 failed:", err.message);
  }

  console.error("═══════════════════════════════════════════");
  throw new Error(
    "فشل تحميل PDF من كل الطرق. تحقق:\n" +
      "1. Apps Script deployed (New version)\n" +
      "2. الملف مشارك على Google Drive\n" +
      "3. الشبكة تعمل"
  );
}

/**
 * تعبئة PDF المرفق
 */
export async function fillPermitPDF(pdfUrl, fields, data) {
  const { PDFDocument, StandardFonts, rgb } = await import("pdf-lib");

  const pdfBytes = await fetchPDFBytes(pdfUrl);
  const pdfDoc = await PDFDocument.load(pdfBytes);
  const pages = pdfDoc.getPages();

  const font = await pdfDoc.embedFont(StandardFonts.Helvetica);
  const fontBold = await pdfDoc.embedFont(StandardFonts.HelveticaBold);

  fields.forEach((field) => {
    const value = data[field.key];
    if (value === undefined || value === null || value === "") return;

    const pageIndex = field.page || 0;
    const page = pages[pageIndex];
    if (!page) return;

    const pageHeight = page.getHeight();
    const y = pageHeight - (field.y || 0);

    try {
      page.drawText(String(value), {
        x: field.x || 0,
        y,
        size: field.fontSize || 12,
        font: field.bold ? fontBold : font,
        color: rgb(0, 0, 0),
        maxWidth: field.maxWidth,
      });
    } catch (err) {
      console.warn(`⚠️ فشل كتابة ${field.key}:`, err);
    }
  });

  return await pdfDoc.save();
}

/**
 * تحميل PDF المعبأ
 */
export function downloadPDF(pdfBytes, fileName = "permit.pdf") {
  const blob = new Blob([pdfBytes], { type: "application/pdf" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = fileName;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

/**
 * فتح PDF في نافذة جديدة
 */
export function openPDF(pdfBytes) {
  const blob = new Blob([pdfBytes], { type: "application/pdf" });
  const url = URL.createObjectURL(blob);
  window.open(url, "_blank");
  setTimeout(() => URL.revokeObjectURL(url), 60000);
}

/**
 * استخراج أسماء الحقول (AcroForm)
 */
export async function extractPDFFormFields(pdfUrl) {
  const { PDFDocument } = await import("pdf-lib");
  const pdfBytes = await fetchPDFBytes(pdfUrl);
  const pdfDoc = await PDFDocument.load(pdfBytes);

  const form = pdfDoc.getForm();
  const fields = form.getFields();

  return fields.map((f) => ({
    name: f.getName(),
    type: f.constructor.name.replace("PDF", "").replace("Field", ""),
  }));
}

/**
 * تعبئة AcroForm
 */
export async function fillPDFAcroForm(pdfUrl, data) {
  const { PDFDocument } = await import("pdf-lib");
  const pdfBytes = await fetchPDFBytes(pdfUrl);
  const pdfDoc = await PDFDocument.load(pdfBytes);

  const form = pdfDoc.getForm();

  Object.entries(data).forEach(([name, value]) => {
    try {
      const field = form.getField(name);
      if (!field) return;
      const type = field.constructor.name;

      if (type.includes("Text")) {
        field.setText(String(value));
      } else if (type.includes("CheckBox")) {
        field.check();
      } else if (type.includes("Dropdown") || type.includes("Radio")) {
        field.select(String(value));
      }
    } catch (err) {
      console.warn(`⚠️ فشل ${name}:`, err);
    }
  });

  return await pdfDoc.save();
}

/**
 * تحويل روابط Google Drive (احتياطي)
 */
export function toDirectDriveUrl(url) {
  const fileId = extractFileId(url);
  if (!fileId) return url;
  return `https://drive.google.com/uc?export=download&confirm=t&id=${fileId}`;
}
