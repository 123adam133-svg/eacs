/* ═══════════════════════════════════════════════════════════
 * CATERING MODULE — Orders + Templates Library
 * v1.0 — بدون أسعار + طباعة PDF مع لغة متعددة
 * ═══════════════════════════════════════════════════════════ */
import React, { useState, useEffect, useMemo } from "react";
import {
  Plus,
  Edit,
  Trash2,
  Search,
  Save,
  UtensilsCrossed,
  Plane,
  CheckCircle2,
  Clock,
  AlertTriangle,
  Printer,
  Paperclip,
  Upload,
  Users,
  Calendar,
  FileText,
  Globe,
} from "lucide-react";
import { useT, useAuth } from "../contexts";
import { Field } from "../components/ui/Field";
import { Input } from "../components/ui/Input";
import { Select } from "../components/ui/Select";
import { Modal } from "../components/ui/Modal";
import { cateringTemplatesAPI, cateringOrdersAPI, uploadFile } from "../api";
import { can as checkPerm } from "../config/permissions";
import { fmtDate } from "../utils/helpers";
import { CateringPrintModal } from "../components/CateringPrintModal";

/* ═══ Styles ═══ */
const cardStyle = {
  backgroundColor: "var(--bg-card)",
  border: "1px solid var(--border-default)",
  boxShadow: "var(--shadow-sm)",
};
const innerBoxStyle = {
  backgroundColor: "var(--bg-app)",
  border: "1px solid var(--border-default)",
};

const STATUS_COLORS = {
  PENDING: { bg: "bg-amber-500/15", text: "text-amber-500", label: "PENDING" },
  CONFIRMED: { bg: "bg-sky-500/15", text: "text-sky-500", label: "CONFIRMED" },
  DELIVERED: {
    bg: "bg-emerald-500/15",
    text: "text-emerald-500",
    label: "DELIVERED",
  },
  CANCELLED: {
    bg: "bg-rose-500/15",
    text: "text-rose-500",
    label: "CANCELLED",
  },
};

const MEAL_TYPES = [
  "BREAKFAST",
  "LUNCH",
  "DINNER",
  "SNACK",
  "BEVERAGE",
  "SPECIAL",
];

export function CateringModule({ flights, settings, user, setSyncStatus }) {
  const t = useT();
  const [activeTab, setActiveTab] = useState("orders"); // "orders" | "templates"
  const [orders, setOrders] = useState([]);
  const [templates, setTemplates] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("");
  const [dateFilter, setDateFilter] = useState("");

  /* ═══ Order State ═══ */
  const [editingOrder, setEditingOrder] = useState(null);
  const [orderDraft, setOrderDraft] = useState({});
  const [orderItems, setOrderItems] = useState([]);

  /* ═══ Template State ═══ */
  const [editingTemplate, setEditingTemplate] = useState(null);
  const [templateDraft, setTemplateDraft] = useState({});
  const [templateItems, setTemplateItems] = useState([]);

  /* ═══ Print State ═══ */
  const [printingOrder, setPrintingOrder] = useState(null);

  const canEdit = checkPerm(user, "catering.edit");
  const canCreate = checkPerm(user, "catering.create");
  const canDelete = checkPerm(user, "catering.delete");

  /* ═══ Load ═══ */
  const loadData = async () => {
    setLoading(true);
    setSyncStatus?.("syncing");
    try {
      const [o, t] = await Promise.all([
        cateringOrdersAPI.list().catch(() => []),
        cateringTemplatesAPI.list().catch(() => []),
      ]);
      setOrders(o);
      setTemplates(t);
      setSyncStatus?.("synced");
    } catch (e) {
      setSyncStatus?.("error");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  /* ═══ ORDERS — CRUD ═══ */
  const openNewOrder = () => {
    if (!canCreate) return alert("⚠️ ليس لديك صلاحية");
    setOrderDraft({
      flightId: "",
      flightNo: "",
      date: new Date().toISOString().slice(0, 10),
      templateId: "",
      templateName: "",
      mealType: "LUNCH",
      paxCount: 0,
      crewCount: 0,
      specialMeals: "",
      status: "PENDING",
      notes: "",
      attachments: [],
    });
    setOrderItems([{ item: "", qty: "1 per pax" }]);
    setEditingOrder("new");
  };

  const openEditOrder = (o) => {
    if (!canEdit) return alert("⚠️ ليس لديك صلاحية");
    setOrderDraft({ ...o });
    setOrderItems(
      o.items && o.items.length > 0
        ? [...o.items]
        : [{ item: "", qty: "1 per pax" }]
    );
    setEditingOrder(o.id);
  };

  const applyTemplate = (templateId) => {
    const tpl = templates.find((x) => x.id === templateId);
    if (!tpl) return;
    setOrderDraft({
      ...orderDraft,
      templateId: tpl.id,
      templateName: tpl.name,
      mealType: tpl.mealType || orderDraft.mealType,
    });
    setOrderItems(
      tpl.items && tpl.items.length > 0
        ? [...tpl.items]
        : [{ item: "", qty: "1 per pax" }]
    );
  };

  const saveOrder = async () => {
    if (!orderDraft.flightNo) return alert("⚠️ اختر الرحلة");
    if (!orderItems.some((i) => i.item))
      return alert("⚠️ أضف عنصراً واحداً على الأقل");
    setSyncStatus?.("syncing");
    try {
      const finalDraft = {
        ...orderDraft,
        items: orderItems.filter((i) => i.item),
        updatedBy: user.fullName || "",
      };
      if (editingOrder === "new") {
        const created = await cateringOrdersAPI.create(finalDraft);
        setOrders([...orders, { ...finalDraft, id: created.id }]);
      } else {
        await cateringOrdersAPI.update(editingOrder, finalDraft);
        setOrders(
          orders.map((o) =>
            o.id === editingOrder ? { ...finalDraft, id: editingOrder } : o
          )
        );
      }
      setEditingOrder(null);
      setSyncStatus?.("synced");
    } catch (e) {
      alert("فشل: " + e.message);
      setSyncStatus?.("error");
    }
  };

  const removeOrder = async (id) => {
    if (!canDelete) return alert("⚠️ ليس لديك صلاحية");
    if (!confirm("حذف طلب التموين؟")) return;
    try {
      await cateringOrdersAPI.remove(id);
      setOrders(orders.filter((o) => o.id !== id));
    } catch (e) {
      alert("فشل: " + e.message);
    }
  };

  const updateOrderStatus = async (id, newStatus) => {
    if (!canEdit) return;
    const order = orders.find((o) => o.id === id);
    if (!order) return;
    try {
      await cateringOrdersAPI.update(id, { ...order, status: newStatus });
      setOrders(
        orders.map((o) => (o.id === id ? { ...o, status: newStatus } : o))
      );
    } catch (e) {
      alert("فشل: " + e.message);
    }
  };

  /* ═══ TEMPLATES — CRUD ═══ */
  const openNewTemplate = () => {
    if (!canEdit) return alert("⚠️ ليس لديك صلاحية");
    setTemplateDraft({
      name: "",
      mealType: "LUNCH",
      notes: "",
    });
    setTemplateItems([{ item: "", qty: "1 per pax" }]);
    setEditingTemplate("new");
  };

  const openEditTemplate = (tpl) => {
    if (!canEdit) return alert("⚠️ ليس لديك صلاحية");
    setTemplateDraft({ ...tpl });
    setTemplateItems(
      tpl.items && tpl.items.length > 0
        ? [...tpl.items]
        : [{ item: "", qty: "1 per pax" }]
    );
    setEditingTemplate(tpl.id);
  };

  const saveTemplate = async () => {
    if (!templateDraft.name) return alert("⚠️ أدخل اسم القالب");
    if (!templateItems.some((i) => i.item))
      return alert("⚠️ أضف عنصراً واحداً");
    setSyncStatus?.("syncing");
    try {
      const finalDraft = {
        ...templateDraft,
        items: templateItems.filter((i) => i.item),
      };
      if (editingTemplate === "new") {
        const created = await cateringTemplatesAPI.create(finalDraft);
        setTemplates([...templates, { ...finalDraft, id: created.id }]);
      } else {
        await cateringTemplatesAPI.update(editingTemplate, finalDraft);
        setTemplates(
          templates.map((x) =>
            x.id === editingTemplate
              ? { ...finalDraft, id: editingTemplate }
              : x
          )
        );
      }
      setEditingTemplate(null);
      setSyncStatus?.("synced");
    } catch (e) {
      alert("فشل: " + e.message);
      setSyncStatus?.("error");
    }
  };

  const removeTemplate = async (id) => {
    if (!canDelete) return alert("⚠️ ليس لديك صلاحية");
    if (!confirm("حذف هذا القالب؟")) return;
    try {
      await cateringTemplatesAPI.remove(id);
      setTemplates(templates.filter((x) => x.id !== id));
    } catch (e) {
      alert("فشل: " + e.message);
    }
  };

  /* ═══ Menu Items (مشترك) ═══ */
  const addMenuItem = (setItems) => {
    setItems((prev) => [...prev, { item: "", qty: "1 per pax" }]);
  };
  const updateMenuItem = (setItems, idx, patch) => {
    setItems((prev) => {
      const n = [...prev];
      n[idx] = { ...n[idx], ...patch };
      return n;
    });
  };
  const removeMenuItem = (setItems, idx) => {
    setItems((prev) => prev.filter((_, i) => i !== idx));
  };

  /* ═══ Upload PDF ═══ */
  const uploadPdf = async (e, setDraft) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 5 * 1024 * 1024) return alert("⚠️ الحد الأقصى 5 MB");
    try {
      const result = await uploadFile(file, "catering");
      setDraft((prev) => ({
        ...prev,
        attachments: [
          ...(prev.attachments || []),
          {
            name: file.name,
            url: result.fileUrl,
            size: result.size,
            type: file.type,
          },
        ],
      }));
    } catch (e) {
      alert("فشل الرفع: " + e.message);
    }
    e.target.value = "";
  };

  /* ═══ Filtered Orders ═══ */
  const filteredOrders = useMemo(() => {
    return orders
      .filter((o) => {
        const q = search.toLowerCase();
        const matchSearch =
          !q || (o.flightNo + o.templateName).toLowerCase().includes(q);
        const matchStatus = !statusFilter || o.status === statusFilter;
        const matchDate = !dateFilter || o.date === dateFilter;
        return matchSearch && matchStatus && matchDate;
      })
      .sort((a, b) => (b.date || "").localeCompare(a.date || ""));
  }, [orders, search, statusFilter, dateFilter]);

  /* ═══ Counters ═══ */
  const counters = {
    total: orders.length,
    pending: orders.filter((o) => o.status === "PENDING").length,
    confirmed: orders.filter((o) => o.status === "CONFIRMED").length,
    delivered: orders.filter((o) => o.status === "DELIVERED").length,
  };

  return (
    <div className="space-y-4 fade-in">
      {/* ═══ Header ═══ */}
      <div className="rounded-xl p-3" style={cardStyle}>
        <div className="flex flex-wrap gap-2 items-center justify-between mb-3">
          <div className="flex items-center gap-3">
            <div
              className="w-10 h-10 rounded-lg flex items-center justify-center shadow-md"
              style={{ background: "var(--brand-gradient)" }}
            >
              <UtensilsCrossed className="w-6 h-6 text-white" />
            </div>
            <div>
              <h2
                className="text-lg font-bold"
                style={{ color: "var(--text-primary)" }}
              >
                {t.catering || "Catering / التموين"}
              </h2>
              <p className="text-xs" style={{ color: "var(--text-muted)" }}>
                {counters.total} orders · {counters.pending} pending
              </p>
            </div>
          </div>
          <div className="flex gap-2">
            {activeTab === "orders" && canCreate && (
              <button
                onClick={openNewOrder}
                className="flex items-center gap-1.5 px-4 py-2 rounded-lg text-sm font-bold text-white"
                style={{ background: "var(--brand-gradient)" }}
              >
                <Plus className="w-4 h-4" /> New Order
              </button>
            )}
            {activeTab === "templates" && canEdit && (
              <button
                onClick={openNewTemplate}
                className="flex items-center gap-1.5 px-4 py-2 rounded-lg text-sm font-bold text-white"
                style={{ background: "var(--brand-gradient)" }}
              >
                <Plus className="w-4 h-4" /> New Template
              </button>
            )}
          </div>
        </div>

        {/* Tabs */}
        <div
          className="flex gap-1 border-b mb-3"
          style={{ borderColor: "var(--border-default)" }}
        >
          {[
            { id: "orders", label: "Orders / الطلبات", icon: Plane },
            {
              id: "templates",
              label: "Templates Library / مكتبة القوالب",
              icon: FileText,
            },
          ].map((tab) => {
            const Icon = tab.icon;
            const active = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className="flex items-center gap-1.5 px-3 py-2 text-xs font-bold border-b-2 transition"
                style={{
                  borderColor: active ? "var(--brand-primary)" : "transparent",
                  color: active ? "var(--brand-primary)" : "var(--text-muted)",
                  backgroundColor: active ? "var(--bg-app)" : "transparent",
                }}
              >
                <Icon className="w-4 h-4" />
                {tab.label}
              </button>
            );
          })}
        </div>

        {/* Filters (Orders only) */}
        {activeTab === "orders" && (
          <>
            <div className="flex flex-wrap gap-2">
              <div className="relative flex-1 min-w-[200px]">
                <Search
                  className="w-4 h-4 absolute top-1/2 -translate-y-1/2 start-3"
                  style={{ color: "var(--text-muted)" }}
                />
                <Input
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  placeholder="Search flight, template..."
                  className="ps-9"
                />
              </div>
              <Input
                type="date"
                value={dateFilter}
                onChange={(e) => setDateFilter(e.target.value)}
                className="w-auto"
              />
              <Select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                className="w-auto"
              >
                <option value="">All Statuses</option>
                <option value="PENDING">Pending</option>
                <option value="CONFIRMED">Confirmed</option>
                <option value="DELIVERED">Delivered</option>
                <option value="CANCELLED">Cancelled</option>
              </Select>
            </div>

            <div
              className="flex flex-wrap gap-3 mt-3 pt-3 border-t text-[11px]"
              style={{ borderColor: "var(--border-default)" }}
            >
              <span>
                🟡 Pending: <b>{counters.pending}</b>
              </span>
              <span>
                🔵 Confirmed: <b>{counters.confirmed}</b>
              </span>
              <span>
                ✅ Delivered: <b>{counters.delivered}</b>
              </span>
              <span className="ml-auto">
                Showing {filteredOrders.length} / {counters.total}
              </span>
            </div>
          </>
        )}
      </div>

      {/* ═══ ORDERS TAB ═══ */}
      {activeTab === "orders" && (
        <>
          {loading ? (
            <div
              className="text-center py-12"
              style={{ color: "var(--text-muted)" }}
            >
              Loading...
            </div>
          ) : filteredOrders.length === 0 ? (
            <div className="text-center py-12 rounded-xl" style={cardStyle}>
              <UtensilsCrossed
                className="w-12 h-12 mx-auto mb-2 opacity-30"
                style={{ color: "var(--text-muted)" }}
              />
              <div style={{ color: "var(--text-muted)" }}>
                No catering orders yet
              </div>
            </div>
          ) : (
            <div className="grid md:grid-cols-2 gap-4">
              {filteredOrders.map((o) => {
                const sc = STATUS_COLORS[o.status] || STATUS_COLORS.PENDING;
                const flight = flights.find(
                  (f) => f.id === o.flightId || f.flightNo === o.flightNo
                );
                return (
                  <div key={o.id} className="rounded-xl p-4" style={cardStyle}>
                    <div className="flex justify-between items-start mb-3">
                      <div>
                        <div className="flex items-center gap-2 mb-1">
                          <Plane
                            className="w-4 h-4"
                            style={{ color: "var(--brand-primary)" }}
                          />
                          <span
                            className="font-bold"
                            style={{ color: "var(--text-primary)" }}
                          >
                            {o.flightNo}
                          </span>
                          <span
                            className={`px-2 py-0.5 rounded text-[10px] font-bold ${sc.bg} ${sc.text}`}
                          >
                            {sc.label}
                          </span>
                        </div>
                        <div
                          className="text-xs flex flex-wrap gap-2"
                          style={{ color: "var(--text-muted)" }}
                        >
                          <span>📅 {fmtDate(o.date)}</span>
                          <span>
                            👥 {o.paxCount} PAX + {o.crewCount} Crew
                          </span>
                          <span>🍽️ {o.mealType}</span>
                        </div>
                        {o.templateName && (
                          <div
                            className="text-[10px] mt-1"
                            style={{ color: "var(--text-muted)" }}
                          >
                            📋 {o.templateName}
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Menu items */}
                    <div className="mt-2 space-y-1">
                      {(o.items || []).map((m, i) => (
                        <div
                          key={i}
                          className="p-1.5 rounded text-xs flex justify-between"
                          style={innerBoxStyle}
                        >
                          <span style={{ color: "var(--text-primary)" }}>
                            • {m.item}
                          </span>
                          <span
                            className="font-mono text-[10px]"
                            style={{ color: "var(--text-muted)" }}
                          >
                            {m.qty}
                          </span>
                        </div>
                      ))}
                    </div>

                    {o.specialMeals && (
                      <div className="mt-2 p-2 rounded text-xs bg-amber-500/10 text-amber-500 border border-amber-500/30">
                        ⚠️ {o.specialMeals}
                      </div>
                    )}

                    {o.notes && (
                      <div
                        className="mt-1 text-xs italic"
                        style={{ color: "var(--text-muted)" }}
                      >
                        📝 {o.notes}
                      </div>
                    )}

                    {/* Actions */}
                    <div
                      className="flex flex-wrap gap-1 mt-3 pt-2 border-t"
                      style={{ borderColor: "var(--border-default)" }}
                    >
                      {o.status === "PENDING" && canEdit && (
                        <button
                          onClick={() => updateOrderStatus(o.id, "CONFIRMED")}
                          className="flex-1 py-1.5 rounded bg-sky-500/15 text-sky-500 text-[11px] font-bold flex items-center justify-center gap-1"
                        >
                          <CheckCircle2 className="w-3.5 h-3.5" /> Confirm
                        </button>
                      )}
                      {o.status === "CONFIRMED" && canEdit && (
                        <button
                          onClick={() => updateOrderStatus(o.id, "DELIVERED")}
                          className="flex-1 py-1.5 rounded bg-emerald-500/15 text-emerald-500 text-[11px] font-bold flex items-center justify-center gap-1"
                        >
                          <CheckCircle2 className="w-3.5 h-3.5" /> Delivered
                        </button>
                      )}
                      <button
                        onClick={() => setPrintingOrder(o)}
                        className="py-1.5 px-2 rounded bg-purple-500/15 text-purple-500 text-[11px]"
                        title="Print"
                      >
                        <Printer className="w-3.5 h-3.5" />
                      </button>
                      {canEdit && (
                        <button
                          onClick={() => openEditOrder(o)}
                          className="py-1.5 px-2 rounded bg-amber-500/15 text-amber-500 text-[11px]"
                          title="Edit"
                        >
                          <Edit className="w-3.5 h-3.5" />
                        </button>
                      )}
                      {canDelete && (
                        <button
                          onClick={() => removeOrder(o.id)}
                          className="py-1.5 px-2 rounded bg-rose-500/15 text-rose-500 text-[11px]"
                          title="Delete"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </>
      )}

      {/* ═══ TEMPLATES TAB ═══ */}
      {activeTab === "templates" && (
        <>
          {loading ? (
            <div
              className="text-center py-12"
              style={{ color: "var(--text-muted)" }}
            >
              Loading...
            </div>
          ) : templates.length === 0 ? (
            <div className="text-center py-12 rounded-xl" style={cardStyle}>
              <FileText
                className="w-12 h-12 mx-auto mb-2 opacity-30"
                style={{ color: "var(--text-muted)" }}
              />
              <div style={{ color: "var(--text-muted)" }}>No templates yet</div>
            </div>
          ) : (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
              {templates.map((tpl) => (
                <div key={tpl.id} className="rounded-xl p-4" style={cardStyle}>
                  <div className="flex justify-between items-start mb-2">
                    <div>
                      <div
                        className="font-bold"
                        style={{ color: "var(--text-primary)" }}
                      >
                        🍽️ {tpl.name}
                      </div>
                      <div
                        className="text-xs"
                        style={{ color: "var(--text-muted)" }}
                      >
                        {tpl.mealType} · {(tpl.items || []).length} items
                      </div>
                    </div>
                  </div>

                  <div className="space-y-1 mt-3">
                    {(tpl.items || []).map((m, i) => (
                      <div
                        key={i}
                        className="p-1.5 rounded text-xs flex justify-between"
                        style={innerBoxStyle}
                      >
                        <span style={{ color: "var(--text-primary)" }}>
                          • {m.item}
                        </span>
                        <span
                          className="font-mono text-[10px]"
                          style={{ color: "var(--text-muted)" }}
                        >
                          {m.qty}
                        </span>
                      </div>
                    ))}
                  </div>

                  {tpl.notes && (
                    <div
                      className="mt-2 text-xs italic"
                      style={{ color: "var(--text-muted)" }}
                    >
                      📝 {tpl.notes}
                    </div>
                  )}

                  <div
                    className="flex gap-1 mt-3 pt-2 border-t"
                    style={{ borderColor: "var(--border-default)" }}
                  >
                    {canEdit && (
                      <button
                        onClick={() => openEditTemplate(tpl)}
                        className="flex-1 py-1.5 rounded bg-amber-500/15 text-amber-500 text-[11px] font-bold flex items-center justify-center gap-1"
                      >
                        <Edit className="w-3.5 h-3.5" /> Edit
                      </button>
                    )}
                    {canDelete && (
                      <button
                        onClick={() => removeTemplate(tpl.id)}
                        className="py-1.5 px-2 rounded bg-rose-500/15 text-rose-500 text-[11px]"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </>
      )}

      {/* ═══ ORDER MODAL ═══ */}
      <Modal
        open={!!editingOrder}
        title={
          editingOrder === "new" ? "New Catering Order" : "Edit Catering Order"
        }
        onClose={() => setEditingOrder(null)}
        wide
        footer={
          <>
            <button
              onClick={() => setEditingOrder(null)}
              className="px-4 py-2 rounded-lg text-sm font-bold border"
              style={{
                borderColor: "var(--border-default)",
                color: "var(--text-muted)",
              }}
            >
              Cancel
            </button>
            <button
              onClick={saveOrder}
              className="px-4 py-2 rounded-lg text-sm font-bold text-white flex items-center gap-2"
              style={{ background: "var(--brand-gradient)" }}
            >
              <Save className="w-4 h-4" /> Save Order
            </button>
          </>
        }
      >
        <div className="space-y-4">
          {/* Flight + Date + Template */}
          <div className="grid md:grid-cols-3 gap-3">
            <Field label="Flight *">
              <Select
                value={orderDraft.flightNo || ""}
                onChange={(e) => {
                  const flight = flights.find(
                    (f) => f.flightNo === e.target.value
                  );
                  setOrderDraft({
                    ...orderDraft,
                    flightNo: e.target.value,
                    flightId: flight?.id || "",
                    date: flight?.std
                      ? String(flight.std).slice(0, 10)
                      : orderDraft.date,
                    paxCount: flight?.pax || orderDraft.paxCount,
                    crewCount:
                      (flight?.crewSlots || []).length || orderDraft.crewCount,
                  });
                }}
              >
                <option value="">— Select Flight —</option>
                {flights.map((f) => (
                  <option key={f.id} value={f.flightNo}>
                    {f.flightNo} — {f.dep} → {f.arr}
                  </option>
                ))}
              </Select>
            </Field>
            <Field label="Date">
              <Input
                type="date"
                value={orderDraft.date || ""}
                onChange={(e) =>
                  setOrderDraft({ ...orderDraft, date: e.target.value })
                }
              />
            </Field>
            <Field label="Apply Template">
              <Select
                value={orderDraft.templateId || ""}
                onChange={(e) => applyTemplate(e.target.value)}
              >
                <option value="">— Manual / None —</option>
                {templates.map((tpl) => (
                  <option key={tpl.id} value={tpl.id}>
                    {tpl.name} ({tpl.mealType})
                  </option>
                ))}
              </Select>
            </Field>
          </div>

          {/* Meal + PAX + Crew + Status */}
          <div className="grid md:grid-cols-4 gap-3">
            <Field label="Meal Type">
              <Select
                value={orderDraft.mealType || "LUNCH"}
                onChange={(e) =>
                  setOrderDraft({ ...orderDraft, mealType: e.target.value })
                }
              >
                {MEAL_TYPES.map((m) => (
                  <option key={m} value={m}>
                    {m}
                  </option>
                ))}
              </Select>
            </Field>
            <Field label="PAX">
              <Input
                type="number"
                value={orderDraft.paxCount || 0}
                onChange={(e) =>
                  setOrderDraft({ ...orderDraft, paxCount: +e.target.value })
                }
              />
            </Field>
            <Field label="Crew">
              <Input
                type="number"
                value={orderDraft.crewCount || 0}
                onChange={(e) =>
                  setOrderDraft({ ...orderDraft, crewCount: +e.target.value })
                }
              />
            </Field>
            <Field label="Status">
              <Select
                value={orderDraft.status || "PENDING"}
                onChange={(e) =>
                  setOrderDraft({ ...orderDraft, status: e.target.value })
                }
              >
                <option value="PENDING">PENDING</option>
                <option value="CONFIRMED">CONFIRMED</option>
                <option value="DELIVERED">DELIVERED</option>
                <option value="CANCELLED">CANCELLED</option>
              </Select>
            </Field>
          </div>

          {/* Menu Items */}
          <div>
            <div className="flex justify-between items-center mb-2">
              <h4
                className="text-sm font-bold"
                style={{ color: "var(--text-primary)" }}
              >
                🍽️ Menu Items ({orderItems.length})
              </h4>
              <button
                onClick={() => addMenuItem(setOrderItems)}
                className="px-2 py-1 rounded text-xs font-bold text-white"
                style={{ background: "var(--brand-primary)" }}
              >
                <Plus className="w-3.5 h-3.5 inline" /> Add Item
              </button>
            </div>
            <div className="space-y-2">
              {orderItems.map((it, i) => (
                <div key={i} className="grid grid-cols-12 gap-2 items-center">
                  <div className="col-span-7">
                    <Input
                      value={it.item || ""}
                      onChange={(e) =>
                        updateMenuItem(setOrderItems, i, {
                          item: e.target.value,
                        })
                      }
                      placeholder="e.g., Chicken Biryani"
                    />
                  </div>
                  <div className="col-span-4">
                    <Input
                      value={it.qty || ""}
                      onChange={(e) =>
                        updateMenuItem(setOrderItems, i, {
                          qty: e.target.value,
                        })
                      }
                      placeholder="e.g., 1 per pax"
                    />
                  </div>
                  <div className="col-span-1">
                    <button
                      onClick={() => removeMenuItem(setOrderItems, i)}
                      className="p-1.5 rounded bg-rose-500/15 text-rose-500"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Special + Notes */}
          <div className="grid md:grid-cols-2 gap-3">
            <Field label="Special Meals">
              <Input
                value={orderDraft.specialMeals || ""}
                onChange={(e) =>
                  setOrderDraft({ ...orderDraft, specialMeals: e.target.value })
                }
                placeholder="2 vegetarian, 1 halal"
              />
            </Field>
            <Field label="Notes">
              <Input
                value={orderDraft.notes || ""}
                onChange={(e) =>
                  setOrderDraft({ ...orderDraft, notes: e.target.value })
                }
              />
            </Field>
          </div>

          {/* Attachments */}
          <div>
            <h4 className="text-sm font-bold mb-2">📎 Attachments</h4>
            {(orderDraft.attachments || []).map((att, i) => (
              <div
                key={i}
                className="flex items-center gap-2 p-2 mb-1 rounded text-xs"
                style={innerBoxStyle}
              >
                <Paperclip className="w-3.5 h-3.5" />
                <span
                  className="flex-1 truncate"
                  style={{ color: "var(--text-primary)" }}
                >
                  {att.name}
                </span>
                <button
                  onClick={() => window.open(att.url, "_blank")}
                  className="text-sky-500"
                >
                  ⬇
                </button>
                <button
                  onClick={() =>
                    setOrderDraft({
                      ...orderDraft,
                      attachments: orderDraft.attachments.filter(
                        (_, idx) => idx !== i
                      ),
                    })
                  }
                  className="text-rose-500"
                >
                  ✕
                </button>
              </div>
            ))}
            <label
              className="flex items-center justify-center gap-2 p-2 rounded cursor-pointer border-2 border-dashed text-xs font-bold"
              style={{
                borderColor: "var(--border-default)",
                color: "var(--brand-primary)",
              }}
            >
              <Upload className="w-4 h-4" /> Upload PDF / Image
              <input
                type="file"
                accept="application/pdf,image/*"
                onChange={(e) => uploadPdf(e, setOrderDraft)}
                className="hidden"
              />
            </label>
          </div>
        </div>
      </Modal>

      {/* ═══ TEMPLATE MODAL ═══ */}
      <Modal
        open={!!editingTemplate}
        title={editingTemplate === "new" ? "New Template" : "Edit Template"}
        onClose={() => setEditingTemplate(null)}
        wide
        footer={
          <>
            <button
              onClick={() => setEditingTemplate(null)}
              className="px-4 py-2 rounded-lg text-sm font-bold border"
              style={{
                borderColor: "var(--border-default)",
                color: "var(--text-muted)",
              }}
            >
              Cancel
            </button>
            <button
              onClick={saveTemplate}
              className="px-4 py-2 rounded-lg text-sm font-bold text-white flex items-center gap-2"
              style={{ background: "var(--brand-gradient)" }}
            >
              <Save className="w-4 h-4" /> Save Template
            </button>
          </>
        }
      >
        <div className="space-y-4">
          <div className="grid md:grid-cols-2 gap-3">
            <Field label="Template Name *">
              <Input
                value={templateDraft.name || ""}
                onChange={(e) =>
                  setTemplateDraft({ ...templateDraft, name: e.target.value })
                }
                placeholder="e.g., Standard Economy Lunch"
              />
            </Field>
            <Field label="Meal Type">
              <Select
                value={templateDraft.mealType || "LUNCH"}
                onChange={(e) =>
                  setTemplateDraft({
                    ...templateDraft,
                    mealType: e.target.value,
                  })
                }
              >
                {MEAL_TYPES.map((m) => (
                  <option key={m} value={m}>
                    {m}
                  </option>
                ))}
              </Select>
            </Field>
          </div>

          <div>
            <div className="flex justify-between items-center mb-2">
              <h4
                className="text-sm font-bold"
                style={{ color: "var(--text-primary)" }}
              >
                🍽️ Items ({templateItems.length})
              </h4>
              <button
                onClick={() => addMenuItem(setTemplateItems)}
                className="px-2 py-1 rounded text-xs font-bold text-white"
                style={{ background: "var(--brand-primary)" }}
              >
                <Plus className="w-3.5 h-3.5 inline" /> Add Item
              </button>
            </div>
            <div className="space-y-2">
              {templateItems.map((it, i) => (
                <div key={i} className="grid grid-cols-12 gap-2 items-center">
                  <div className="col-span-7">
                    <Input
                      value={it.item || ""}
                      onChange={(e) =>
                        updateMenuItem(setTemplateItems, i, {
                          item: e.target.value,
                        })
                      }
                      placeholder="e.g., Chicken Biryani"
                    />
                  </div>
                  <div className="col-span-4">
                    <Input
                      value={it.qty || ""}
                      onChange={(e) =>
                        updateMenuItem(setTemplateItems, i, {
                          qty: e.target.value,
                        })
                      }
                      placeholder="e.g., 1 per pax"
                    />
                  </div>
                  <div className="col-span-1">
                    <button
                      onClick={() => removeMenuItem(setTemplateItems, i)}
                      className="p-1.5 rounded bg-rose-500/15 text-rose-500"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <Field label="Notes">
            <Input
              value={templateDraft.notes || ""}
              onChange={(e) =>
                setTemplateDraft({ ...templateDraft, notes: e.target.value })
              }
            />
          </Field>
        </div>
      </Modal>

      {/* ═══ PRINT MODAL ═══ */}
      {printingOrder && (
        <CateringPrintModal
          order={printingOrder}
          flight={flights.find(
            (f) =>
              f.id === printingOrder.flightId ||
              f.flightNo === printingOrder.flightNo
          )}
          settings={settings}
          user={user}
          onClose={() => setPrintingOrder(null)}
        />
      )}
    </div>
  );
}

export default CateringModule;
