/* ═══════════════════════════════════════════════════════════
 * PERMIT PRINT MODAL — نموذج تصريح قابل للطباعة
 * v1.0 — يعرض بيانات الرحلة + التصريح + Crew
 * ═══════════════════════════════════════════════════════════ */
import React, { useState, useRef } from "react";
import { X, Printer, Globe } from "lucide-react";

export function PermitPrintModal({
  permit,
  flight,
  crew = [],
  settings = {},
  user,
  onClose,
}) {
  const [langMode, setLangMode] = useState("both");
  const printRef = useRef(null);

  const logoUrl = settings?.logo || "";
  const companyName = settings?.companyName || "EACS";
  const companyNameAr = settings?.companyNameAr || "الجهاز التنفيذي";
  const operatorCode = (settings?.operatorCode || "EACS").toUpperCase();
  const userName = user?.fullName || user?.username || "User";

  const fmtDate = (iso) => {
    if (!iso) return "—";
    const d = new Date(iso);
    if (isNaN(d.getTime())) return "—";
    const months = [
      "Jan",
      "Feb",
      "Mar",
      "Apr",
      "May",
      "Jun",
      "Jul",
      "Aug",
      "Sep",
      "Oct",
      "Nov",
      "Dec",
    ];
    return `${String(d.getUTCDate()).padStart(2, "0")}-${
      months[d.getUTCMonth()]
    }-${d.getUTCFullYear()}`;
  };

  const fmtTime = (iso) => {
    if (!iso) return "—";
    const d = new Date(iso);
    if (isNaN(d.getTime())) return "—";
    return `${String(d.getUTCHours()).padStart(2, "0")}:${String(
      d.getUTCMinutes()
    ).padStart(2, "0")} UTC`;
  };

  /* Crew for this flight */
  const crewList = (flight?.crewSlots || [])
    .map((slot) => {
      const m = crew.find((c) => String(c.id) === String(slot.crewId));
      return m
        ? {
            position: slot.position,
            name: m.fullName,
            license: m.licenseNo,
            passport: m.passportNo,
          }
        : null;
    })
    .filter(Boolean);

  const handlePrint = () => {
    const content = printRef.current?.innerHTML;
    if (!content) return;
    const win = window.open("", "_blank");
    win.document.write(`
      <!DOCTYPE html>
      <html dir="${langMode === "ar" ? "rtl" : "ltr"}">
      <head>
        <meta charset="utf-8">
        <title>${permit?.permitType} Permit — ${flight?.flightNo || ""}</title>
        <style>
          @page { size: A4; margin: 15mm; }
          body { font-family: ${
            langMode === "ar"
              ? "'Cairo', Arial, sans-serif"
              : "Arial, sans-serif"
          }; color: #000; background: white; }
          * { box-sizing: border-box; }
          table { width: 100%; border-collapse: collapse; margin: 10px 0; }
          td, th { padding: 6px 8px; border: 1px solid #ccc; font-size: 12px; }
          th { background: #f0f0f0; font-weight: bold; }
        </style>
      </head>
      <body>${content}</body>
      </html>
    `);
    win.document.close();
    setTimeout(() => {
      win.focus();
      win.print();
    }, 500);
  };

  return (
    <div
      className="fixed inset-0 z-[90] flex items-center justify-center p-4"
      style={{ backgroundColor: "rgba(0,0,0,0.75)" }}
      onClick={onClose}
    >
      <div
        className="bg-white dark:bg-slate-800 rounded-2xl w-full max-w-4xl max-h-[95vh] flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div
          className="flex justify-between items-center p-4 border-b"
          style={{ borderColor: "var(--border-default)" }}
        >
          <div>
            <h2
              className="text-lg font-bold"
              style={{ color: "var(--text-primary)" }}
            >
              🖨️ Print Permit — {permit?.country}
            </h2>
            <p className="text-xs" style={{ color: "var(--text-muted)" }}>
              {permit?.permitType} · {flight?.flightNo}
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-700"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Language Selector */}
        <div
          className="px-4 py-3 border-b flex items-center gap-3 flex-wrap"
          style={{
            borderColor: "var(--border-default)",
            backgroundColor: "var(--bg-app)",
          }}
        >
          <Globe
            className="w-4 h-4"
            style={{ color: "var(--brand-primary)" }}
          />
          <span
            className="text-xs font-bold"
            style={{ color: "var(--text-primary)" }}
          >
            Language:
          </span>
          <div
            className="flex rounded-lg overflow-hidden border"
            style={{ borderColor: "var(--border-default)" }}
          >
            {[
              { id: "both", label: "🌐 عربي + EN" },
              { id: "en", label: "🇬🇧 English" },
              { id: "ar", label: "🇸🇦 عربي" },
            ].map((opt) => (
              <button
                key={opt.id}
                onClick={() => setLangMode(opt.id)}
                className="px-3 py-1.5 text-xs font-bold transition"
                style={{
                  backgroundColor:
                    langMode === opt.id
                      ? "var(--brand-primary)"
                      : "var(--bg-card)",
                  color: langMode === opt.id ? "white" : "var(--text-muted)",
                }}
              >
                {opt.label}
              </button>
            ))}
          </div>
        </div>

        {/* Preview */}
        <div
          className="flex-1 overflow-y-auto p-6"
          style={{ backgroundColor: "#f5f5f5" }}
        >
          <div
            ref={printRef}
            className="bg-white p-8 mx-auto shadow-lg"
            style={{ maxWidth: "700px" }}
          >
            {/* ═══ HEADER ═══ */}
            <div style={{ textAlign: "center", marginBottom: "20px" }}>
              {logoUrl && (
                <img
                  src={logoUrl}
                  alt="logo"
                  style={{
                    maxWidth: "100px",
                    maxHeight: "100px",
                    margin: "0 auto 10px",
                    display: "block",
                  }}
                />
              )}
              <div style={{ fontSize: "20px", fontWeight: "bold" }}>
                {operatorCode}
              </div>
              {langMode !== "en" && (
                <div style={{ fontSize: "16px", color: "#444" }}>
                  {companyNameAr}
                </div>
              )}
              {langMode !== "ar" && (
                <div style={{ fontSize: "14px", color: "#666" }}>
                  {companyName}
                </div>
              )}
            </div>

            {/* ═══ TITLE ═══ */}
            <div
              style={{
                fontSize: "18px",
                fontWeight: "bold",
                margin: "20px 0",
                textAlign: "center",
                borderTop: "2px solid #000",
                borderBottom: "2px solid #000",
                padding: "10px",
              }}
            >
              {langMode === "both" &&
                `${permit?.permitType} PERMIT / تصريح ${permit?.country || ""}`}
              {langMode === "en" &&
                `${permit?.permitType} PERMIT — ${permit?.country || ""}`}
              {langMode === "ar" &&
                `تصريح ${permit?.country || ""} — ${permit?.permitType || ""}`}
            </div>

            {/* ═══ PERMIT INFO ═══ */}
            <table style={{ width: "100%", borderCollapse: "collapse" }}>
              <tbody>
                <tr>
                  <td
                    style={{
                      padding: "6px 8px",
                      fontWeight: "bold",
                      width: "150px",
                      border: "1px solid #ccc",
                    }}
                  >
                    {langMode === "both"
                      ? "Permit No / رقم التصريح:"
                      : langMode === "en"
                      ? "Permit No:"
                      : "رقم التصريح:"}
                  </td>
                  <td
                    style={{
                      padding: "6px 8px",
                      border: "1px solid #ccc",
                      fontFamily: "monospace",
                      fontWeight: "bold",
                    }}
                  >
                    {permit?.permitNo || "—"}
                  </td>
                  <td
                    style={{
                      padding: "6px 8px",
                      fontWeight: "bold",
                      width: "150px",
                      border: "1px solid #ccc",
                    }}
                  >
                    {langMode === "both"
                      ? "Status / الحالة:"
                      : langMode === "en"
                      ? "Status:"
                      : "الحالة:"}
                  </td>
                  <td style={{ padding: "6px 8px", border: "1px solid #ccc" }}>
                    {permit?.status || "—"}
                  </td>
                </tr>
                <tr>
                  <td
                    style={{
                      padding: "6px 8px",
                      fontWeight: "bold",
                      border: "1px solid #ccc",
                    }}
                  >
                    {langMode === "both"
                      ? "Issued Date / تاريخ الإصدار:"
                      : langMode === "en"
                      ? "Issued Date:"
                      : "تاريخ الإصدار:"}
                  </td>
                  <td style={{ padding: "6px 8px", border: "1px solid #ccc" }}>
                    {fmtDate(permit?.issuedDate)}
                  </td>
                  <td
                    style={{
                      padding: "6px 8px",
                      fontWeight: "bold",
                      border: "1px solid #ccc",
                    }}
                  >
                    {langMode === "both"
                      ? "Expiry Date / تاريخ الانتهاء:"
                      : langMode === "en"
                      ? "Expiry Date:"
                      : "تاريخ الانتهاء:"}
                  </td>
                  <td style={{ padding: "6px 8px", border: "1px solid #ccc" }}>
                    {fmtDate(permit?.expiryDate)}
                  </td>
                </tr>
                <tr>
                  <td
                    style={{
                      padding: "6px 8px",
                      fontWeight: "bold",
                      border: "1px solid #ccc",
                    }}
                  >
                    {langMode === "both"
                      ? "Issued By / الجهة المُصدرة:"
                      : langMode === "en"
                      ? "Issued By:"
                      : "الجهة المُصدرة:"}
                  </td>
                  <td
                    style={{ padding: "6px 8px", border: "1px solid #ccc" }}
                    colSpan={3}
                  >
                    {permit?.issuedBy || "—"}
                  </td>
                </tr>
              </tbody>
            </table>

            {/* ═══ FLIGHT DATA (auto-filled) ═══ */}
            <div
              style={{
                marginTop: "20px",
                fontSize: "14px",
                fontWeight: "bold",
                color: "#000",
              }}
            >
              ✈️{" "}
              {langMode === "both"
                ? "FLIGHT DATA / بيانات الرحلة"
                : langMode === "en"
                ? "FLIGHT DATA"
                : "بيانات الرحلة"}
            </div>
            <table style={{ width: "100%", borderCollapse: "collapse" }}>
              <tbody>
                <tr>
                  <td
                    style={{
                      padding: "6px 8px",
                      fontWeight: "bold",
                      width: "150px",
                      border: "1px solid #ccc",
                    }}
                  >
                    {langMode === "both"
                      ? "Flight No / الرحلة:"
                      : langMode === "en"
                      ? "Flight No:"
                      : "الرحلة:"}
                  </td>
                  <td
                    style={{
                      padding: "6px 8px",
                      border: "1px solid #ccc",
                      fontFamily: "monospace",
                      fontWeight: "bold",
                    }}
                  >
                    {flight?.flightNo || "—"}
                  </td>
                  <td
                    style={{
                      padding: "6px 8px",
                      fontWeight: "bold",
                      width: "150px",
                      border: "1px solid #ccc",
                    }}
                  >
                    {langMode === "both"
                      ? "Aircraft / الطائرة:"
                      : langMode === "en"
                      ? "Aircraft:"
                      : "الطائرة:"}
                  </td>
                  <td
                    style={{
                      padding: "6px 8px",
                      border: "1px solid #ccc",
                      fontFamily: "monospace",
                      fontWeight: "bold",
                    }}
                  >
                    {flight?.acft || "—"}
                  </td>
                </tr>
                <tr>
                  <td
                    style={{
                      padding: "6px 8px",
                      fontWeight: "bold",
                      border: "1px solid #ccc",
                    }}
                  >
                    {langMode === "both"
                      ? "Departure / المغادرة:"
                      : langMode === "en"
                      ? "Departure:"
                      : "المغادرة:"}
                  </td>
                  <td
                    style={{
                      padding: "6px 8px",
                      border: "1px solid #ccc",
                      fontFamily: "monospace",
                    }}
                  >
                    {flight?.dep || "—"}
                  </td>
                  <td
                    style={{
                      padding: "6px 8px",
                      fontWeight: "bold",
                      border: "1px solid #ccc",
                    }}
                  >
                    {langMode === "both"
                      ? "Arrival / الوصول:"
                      : langMode === "en"
                      ? "Arrival:"
                      : "الوصول:"}
                  </td>
                  <td
                    style={{
                      padding: "6px 8px",
                      border: "1px solid #ccc",
                      fontFamily: "monospace",
                    }}
                  >
                    {flight?.arr || "—"}
                  </td>
                </tr>
                <tr>
                  <td
                    style={{
                      padding: "6px 8px",
                      fontWeight: "bold",
                      border: "1px solid #ccc",
                    }}
                  >
                    {langMode === "both"
                      ? "Date / التاريخ:"
                      : langMode === "en"
                      ? "Date:"
                      : "التاريخ:"}
                  </td>
                  <td style={{ padding: "6px 8px", border: "1px solid #ccc" }}>
                    {fmtDate(flight?.std)}
                  </td>
                  <td
                    style={{
                      padding: "6px 8px",
                      fontWeight: "bold",
                      border: "1px solid #ccc",
                    }}
                  >
                    {langMode === "both"
                      ? "STD / STA:"
                      : langMode === "en"
                      ? "STD / STA:"
                      : "الإقلاع / الهبوط:"}
                  </td>
                  <td
                    style={{
                      padding: "6px 8px",
                      border: "1px solid #ccc",
                      fontFamily: "monospace",
                    }}
                  >
                    {fmtTime(flight?.std)} / {fmtTime(flight?.sta)}
                  </td>
                </tr>
              </tbody>
            </table>

            {/* ═══ CREW ═══ */}
            {crewList.length > 0 && (
              <>
                <div
                  style={{
                    marginTop: "20px",
                    fontSize: "14px",
                    fontWeight: "bold",
                    color: "#000",
                  }}
                >
                  👥{" "}
                  {langMode === "both"
                    ? "CREW / الطاقم"
                    : langMode === "en"
                    ? "CREW"
                    : "الطاقم"}{" "}
                  ({crewList.length})
                </div>
                <table style={{ width: "100%", borderCollapse: "collapse" }}>
                  <thead>
                    <tr style={{ backgroundColor: "#f0f0f0" }}>
                      <th
                        style={{
                          padding: "6px 8px",
                          border: "1px solid #ccc",
                          fontSize: "12px",
                          width: "40px",
                        }}
                      >
                        #
                      </th>
                      <th
                        style={{
                          padding: "6px 8px",
                          border: "1px solid #ccc",
                          fontSize: "12px",
                        }}
                      >
                        {langMode === "both"
                          ? "Position / الوظيفة"
                          : langMode === "en"
                          ? "Position"
                          : "الوظيفة"}
                      </th>
                      <th
                        style={{
                          padding: "6px 8px",
                          border: "1px solid #ccc",
                          fontSize: "12px",
                        }}
                      >
                        {langMode === "both"
                          ? "Name / الاسم"
                          : langMode === "en"
                          ? "Name"
                          : "الاسم"}
                      </th>
                      <th
                        style={{
                          padding: "6px 8px",
                          border: "1px solid #ccc",
                          fontSize: "12px",
                        }}
                      >
                        {langMode === "both"
                          ? "License / الرخصة"
                          : langMode === "en"
                          ? "License"
                          : "الرخصة"}
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    {crewList.map((c, i) => (
                      <tr key={i}>
                        <td
                          style={{
                            padding: "6px 8px",
                            border: "1px solid #ccc",
                            textAlign: "center",
                          }}
                        >
                          {i + 1}
                        </td>
                        <td
                          style={{
                            padding: "6px 8px",
                            border: "1px solid #ccc",
                            fontWeight: "bold",
                          }}
                        >
                          {c.position}
                        </td>
                        <td
                          style={{
                            padding: "6px 8px",
                            border: "1px solid #ccc",
                          }}
                        >
                          {c.name}
                        </td>
                        <td
                          style={{
                            padding: "6px 8px",
                            border: "1px solid #ccc",
                            fontFamily: "monospace",
                            fontSize: "11px",
                          }}
                        >
                          {c.license || "—"}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </>
            )}

            {/* ═══ NOTES ═══ */}
            {permit?.notes && (
              <>
                <div
                  style={{
                    marginTop: "20px",
                    fontSize: "14px",
                    fontWeight: "bold",
                    color: "#000",
                  }}
                >
                  {langMode === "both"
                    ? "NOTES / ملاحظات"
                    : langMode === "en"
                    ? "NOTES"
                    : "ملاحظات"}
                </div>
                <div
                  style={{
                    padding: "8px",
                    border: "1px solid #ccc",
                    marginTop: "4px",
                    fontSize: "12px",
                  }}
                >
                  {permit.notes}
                </div>
              </>
            )}

            {/* ═══ FOOTER ═══ */}
            <div
              style={{
                marginTop: "30px",
                paddingTop: "20px",
                borderTop: "1px solid #999",
                fontSize: "12px",
                color: "#333",
              }}
            >
              <table style={{ width: "100%", border: "none" }}>
                <tbody>
                  <tr>
                    <td style={{ padding: "4px 0", border: "none" }}>
                      <b>
                        {langMode === "both"
                          ? "Issued by / صادر من:"
                          : langMode === "en"
                          ? "Issued by:"
                          : "صادر من:"}
                      </b>{" "}
                      {userName}
                    </td>
                    <td
                      style={{
                        padding: "4px 0",
                        textAlign: "end",
                        border: "none",
                      }}
                    >
                      <b>
                        {langMode === "both"
                          ? "Date / التاريخ:"
                          : langMode === "en"
                          ? "Date:"
                          : "التاريخ:"}
                      </b>{" "}
                      {new Date().toISOString().slice(0, 10)}
                    </td>
                  </tr>
                </tbody>
              </table>
              <div style={{ marginTop: "40px" }}>
                <b>
                  {langMode === "both"
                    ? "Signature / التوقيع:"
                    : langMode === "en"
                    ? "Signature:"
                    : "التوقيع:"}
                </b>
                <div
                  style={{
                    marginTop: "10px",
                    borderBottom: "1px solid #000",
                    width: "200px",
                    height: "30px",
                  }}
                />
              </div>
            </div>
          </div>
        </div>

        {/* Footer Actions */}
        <div
          className="p-4 border-t flex justify-end gap-2"
          style={{ borderColor: "var(--border-default)" }}
        >
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-lg text-sm font-bold border"
            style={{
              borderColor: "var(--border-default)",
              color: "var(--text-muted)",
            }}
          >
            Close
          </button>
          <button
            onClick={handlePrint}
            className="px-6 py-2 rounded-lg text-sm font-bold text-white flex items-center gap-2"
            style={{ background: "var(--brand-gradient)" }}
          >
            <Printer className="w-4 h-4" /> Print / طباعة
          </button>
        </div>
      </div>
    </div>
  );
}

export default PermitPrintModal;
