/* ═══════════════════════════════════════════════════════════
 * LOGIN Component
 * v4.4 — FINAL: Added sounds (success/error)
 * ═══════════════════════════════════════════════════════════ */
import React, { useState } from "react";
import { User, Lock, Eye, EyeOff, AlertCircle, RefreshCw } from "lucide-react";
import { useT } from "../contexts";
import { Field } from "./ui/Field";
import { Input } from "./ui/Input";
import { logLoginSafe, logSafe } from "../utils/audit";
import { alertSuccess, alertError } from "../utils/sounds";

/* ⭐ Drive logo URL helper */
function logoToDisplayUrl(url) {
  if (!url) return "";
  if (url.startsWith("data:")) return url;
  const match = url.match(/[?&]id=([^&]+)/);
  if (match) return `https://lh3.googleusercontent.com/d/${match[1]}`;
  const pathMatch = url.match(/\/d\/([^/]+)/);
  if (pathMatch) return `https://lh3.googleusercontent.com/d/${pathMatch[1]}`;
  return url;
}

/* ⭐ فحص active بشكل مرن */
const isActiveValue = (v) => {
  if (v === true) return true;
  if (v === 1) return true;
  if (v === undefined || v === null || v === "") return true;
  const s = String(v).toLowerCase().trim();
  return s === "true" || s === "1" || s === "yes" || s === "active";
};

/* ⭐ تجاهل القيم الافتراضية */
const IGNORED_NAMES = [
  "AeroOps",
  "AEROOPS",
  "aeroops",
  "إيرو أوبس",
  "ايرو أوبس",
];
const isValidName = (name) => {
  if (!name) return false;
  const trimmed = String(name).trim();
  if (!trimmed) return false;
  return !IGNORED_NAMES.includes(trimmed);
};

export function Login({ users, onLogin, settings, loading }) {
  const t = useT();
  const [u, setU] = useState("admin");
  const [p, setP] = useState("admin123");
  const [showP, setShowP] = useState(false);
  const [err, setErr] = useState("");

  /* 🔍 تشخيص */
  console.log("🔍 Login settings:", settings);
  console.log("🔍 Login companyName:", settings?.companyName);
  console.log("🔍 Login companyNameAr:", settings?.companyNameAr);
  console.log("🔍 Login logo:", settings?.logo);
  console.log(
    "🔍 isValidName(companyName):",
    isValidName(settings?.companyName)
  );
  console.log(
    "🔍 isValidName(companyNameAr):",
    isValidName(settings?.companyNameAr)
  );

  /* ⭐ تجاهل "AeroOps" الافتراضي */
  const logoUrl = settings?.logo ? logoToDisplayUrl(settings.logo) : "";
  const companyNameEn = isValidName(settings?.companyName)
    ? settings.companyName
    : "";
  const companyNameAr = isValidName(settings?.companyNameAr)
    ? settings.companyNameAr
    : "";

  console.log(
    "🔍 Final displayed — nameEn:",
    companyNameEn,
    "nameAr:",
    companyNameAr
  );

  const submit = (e) => {
    e.preventDefault();

    const foundRaw = users.find(
      (x) =>
        String(x.username || "")
          .trim()
          .toLowerCase() === String(u).trim().toLowerCase() &&
        String(x.password || "") === String(p)
    );

    if (!foundRaw) {
      setErr(t.invalidLogin || "Invalid credentials");
      alertError(); // ⭐ صوت الخطأ
      logLoginSafe(
        { id: "unknown", fullName: u, username: u, role: "unknown" },
        "LOGIN_FAILED",
        false,
        "Invalid credentials"
      );
      return;
    }

    if (!isActiveValue(foundRaw.active)) {
      const msg =
        "هذا المستخدم غير مفعّل (active = " +
        String(foundRaw.active) +
        "). فعّله من Google Sheets.";
      setErr(msg);
      alertError(); // ⭐ صوت الخطأ
      logLoginSafe(foundRaw, "LOGIN_FAILED", false, "User inactive");
      return;
    }

    setErr("");
    logLoginSafe(foundRaw, "LOGIN", true);
    logSafe(foundRaw, "LOGIN", "Auth", foundRaw.id, foundRaw.fullName, {
      username: foundRaw.username,
      role: foundRaw.role,
    });

    alertSuccess(); // ⭐ صوت النجاح
    onLogin(foundRaw);
  };

  return (
    <div
      className="min-h-screen flex items-center justify-center p-4 relative overflow-hidden transition-colors duration-300"
      style={{ backgroundColor: "var(--bg-app)" }}
    >
      <div
        className="absolute inset-0 opacity-90 pointer-events-none"
        style={{
          background: `radial-gradient(circle at 20% 20%, var(--brand-primary), transparent 50%),
                       radial-gradient(circle at 80% 80%, var(--brand-secondary), transparent 50%),
                       var(--bg-app)`,
        }}
      />

      <div
        className="absolute w-[500px] h-[500px] rounded-full blur-3xl opacity-30 pointer-events-none -top-40 -left-40"
        style={{ backgroundColor: "var(--brand-accent)" }}
      />
      <div
        className="absolute w-[400px] h-[400px] rounded-full blur-3xl opacity-20 pointer-events-none -bottom-32 -right-32"
        style={{ backgroundColor: "var(--brand-primary)" }}
      />

      <form
        onSubmit={submit}
        className="relative w-full max-w-md rounded-3xl p-8 shadow-2xl fade-in"
        style={{
          backgroundColor: "var(--bg-card)",
          border: "1px solid var(--border-default)",
          boxShadow: "var(--shadow-lg)",
        }}
      >
        {/* Header — الشعار والاسم من الإعدادات فقط */}
        {(logoUrl || companyNameEn || companyNameAr) && (
          <div className="text-center mb-6">
            {logoUrl && (
              <div
                className="mx-auto mb-4 w-20 h-20 rounded-2xl flex items-center justify-center overflow-hidden"
                style={{
                  background: "white",
                  boxShadow: "var(--shadow-md)",
                }}
              >
                <img
                  src={logoUrl}
                  alt="logo"
                  className="w-full h-full object-contain p-1"
                  onError={(e) => {
                    e.currentTarget.style.display = "none";
                  }}
                />
              </div>
            )}

            {(companyNameEn || companyNameAr) && (
              <div className="space-y-1">
                {companyNameEn && (
                  <h1
                    className="font-black text-2xl"
                    style={{ color: "var(--text-primary)" }}
                  >
                    {companyNameEn}
                  </h1>
                )}
                {companyNameAr && (
                  <p
                    className="text-sm font-sans"
                    style={{ color: "var(--text-muted)" }}
                    dir="rtl"
                  >
                    {companyNameAr}
                  </p>
                )}
              </div>
            )}
          </div>
        )}

        {loading && (
          <div
            className="mb-4 p-3 rounded-lg text-sm flex items-center gap-2"
            style={{
              backgroundColor: "var(--bg-app)",
              border: "1px solid var(--border-default)",
              color: "var(--brand-primary)",
            }}
          >
            <RefreshCw className="w-4 h-4 animate-spin" />
            {t.loadingData}
          </div>
        )}

        {err && (
          <div className="mb-4 p-3 rounded-lg text-sm flex items-start gap-2 bg-rose-500/10 border border-rose-500/40 text-rose-500">
            <AlertCircle className="w-4 h-4 flex-shrink-0 mt-0.5" />
            <span className="flex-1">{err}</span>
          </div>
        )}

        <div className="space-y-4">
          <Field label={t.username}>
            <div className="relative">
              <User
                className="w-4 h-4 absolute top-1/2 -translate-y-1/2 start-3 pointer-events-none"
                style={{ color: "var(--text-muted)" }}
              />
              <Input
                value={u}
                onChange={(e) => setU(e.target.value)}
                className="ps-9"
                autoComplete="username"
              />
            </div>
          </Field>

          <Field label={t.password}>
            <div className="relative">
              <Lock
                className="w-4 h-4 absolute top-1/2 -translate-y-1/2 start-3 pointer-events-none"
                style={{ color: "var(--text-muted)" }}
              />
              <Input
                type={showP ? "text" : "password"}
                value={p}
                onChange={(e) => setP(e.target.value)}
                className="ps-9 pe-9"
                autoComplete="current-password"
              />
              <button
                type="button"
                onClick={() => setShowP((s) => !s)}
                className="absolute top-1/2 -translate-y-1/2 end-3 transition"
                style={{ color: "var(--text-muted)" }}
              >
                {showP ? (
                  <EyeOff className="w-4 h-4" />
                ) : (
                  <Eye className="w-4 h-4" />
                )}
              </button>
            </div>
          </Field>
        </div>

        <button
          type="submit"
          disabled={loading || users.length === 0}
          className="w-full mt-6 py-3 rounded-xl font-bold text-white transition-all disabled:opacity-50 disabled:cursor-not-allowed hover:-translate-y-0.5 active:translate-y-0"
          style={{
            background: "var(--brand-gradient)",
            boxShadow: "var(--shadow-md)",
          }}
        >
          {t.signIn}
        </button>
      </form>
    </div>
  );
}

export default Login;
