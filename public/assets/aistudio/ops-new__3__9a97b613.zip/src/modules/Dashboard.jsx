/* ═══════════════════════════════════════════════════════════
 * DASHBOARD — Main overview screen
 * v4.1 — FINAL: import useAuth from AuthContext directly
 * ═══════════════════════════════════════════════════════════ */
import React from "react";
import {
  Calendar,
  Plane,
  Shield,
  Clock,
  Users,
  TrendingUp,
  ArrowRight,
  Activity,
} from "lucide-react";
/* ⭐⭐⭐ استيراد مباشر من المصادر الصحيحة ⭐⭐⭐ */
import { useT } from "../contexts/LangContext";
import { useAuth } from "../contexts/AuthContext";
import { LiveClock, Badge } from "../components/ui";
import { CrewTableIcon } from "../crewIcons";
import { AlertsSummary } from "./AlertsSummary";
import { todayISO } from "../utils/helpers";
import { can as checkPerm } from "../config/permissions";

/* ⭐ parse perms — يدعم array أو JSON string */
const parsePerms = (raw) => {
  if (!raw) return [];
  if (Array.isArray(raw)) return raw;
  if (typeof raw === "string") {
    try {
      const parsed = JSON.parse(raw);
      return Array.isArray(parsed) ? parsed : [];
    } catch {
      return [];
    }
  }
  return [];
};

const normRole = (s) =>
  String(s || "")
    .trim()
    .toLowerCase();

const ADMIN_ALIASES = [
  "superadmin",
  "super_admin",
  "super-admin",
  "admin",
  "administrator",
  "owner",
  "root",
];

export function Dashboard({
  flights = [],
  crew = [],
  fleet = [],
  users = [],
  roles = [],
  leave = [],
  roster = [],
  standby = [],
  training = [],
  setTab,
  loading = false,
}) {
  const t = useT();
  const { user } = useAuth();

  /* 🔍 تشخيص — احذفه بعد التأكد */
  console.log("🔍 Dashboard — user:", user);
  console.log("🔍 Dashboard — user.role:", user?.role);
  console.log("🔍 Dashboard — user.perms:", user?.perms);
  console.log("🔍 Dashboard — loading:", loading);

  /* ⭐⭐⭐ دالة can الجذرية v4.1 ⭐⭐⭐ */
  const can = (perm) => {
    if (!user || !perm) return false;

    const roleLower = normRole(user.role);

    /* 1) صلاحيات مخصصة صريحة على المستخدم */
    const userPerms = parsePerms(user.perms);
    if (userPerms.length > 0) {
      if (userPerms.includes("*")) return true;
      if (userPerms.includes(perm)) return true;
      return false;
    }

    /* 2) الأدوار الإدارية العليا */
    if (ADMIN_ALIASES.includes(roleLower)) return true;

    /* 3) FALLBACK للموظفين */
    const BASIC_PERMS = [
      "schedule.view",
      "fleet.view",
      "crew.view",
      "ftl.view",
      "reports.view",
      "roster.view",
      "leave.view",
      "training.view",
      "standby.view",
      "manuals.view",
      "charts.view",
      "tracking.view",
      "settings.view",
      "alerts.view",
      "users.view",
      "crew.portal",
    ];
    if (BASIC_PERMS.includes(perm)) return true;

    /* 4) التحقق النهائي عبر النظام المركزي */
    try {
      return checkPerm(user, perm);
    } catch {
      return false;
    }
  };

  const today = todayISO();
  const todayFlights = (flights || []).filter((f) => f.std?.startsWith(today));
  const activeFlights = (flights || []).filter(
    (f) => f.status === "DEPARTED" || f.status === "IN_FLIGHT"
  );
  const activeCrew = (crew || []).filter((c) => c.status === "active");
  const pendingLeave = (leave || []).filter((l) => l.status === "pending");

  /* ⭐ البطاقات */
  const allStats = [
    {
      id: "schedule",
      icon: Calendar,
      label: t.scheduleBoard || "Schedule",
      value: flights?.length || 0,
      sub: `${todayFlights.length} ${t.today || "Today"}`,
      tab: "schedule",
      show: can("schedule.view"),
    },
    {
      id: "fleet",
      icon: Plane,
      label: t.fleet || "Fleet",
      value: fleet?.length || 0,
      sub: `${fleet?.filter((a) => a.status === "AIRWORTHY").length || 0} ${
        t.active || "Active"
      }`,
      tab: "fleet",
      show: can("fleet.view"),
    },
    {
      id: "crew",
      icon: CrewTableIcon,
      label: t.crew || "Crew",
      value: activeCrew?.length || 0,
      sub: `${crew?.length || 0} ${t.showing || "Total"}`,
      tab: "crew",
      show: can("crew.view"),
    },
    {
      id: "users",
      icon: Shield,
      label: t.userMgmt || "Users",
      value: users?.length || 0,
      sub: `${roles?.length || 0} ${t.roles || "Roles"}`,
      tab: "users",
      show: can("users.view"),
    },
  ];

  const stats = allStats.filter((s) => s.show);

  /* ⭐ إجراءات سريعة */
  const allQuickActions = [
    {
      id: "schedule",
      icon: Calendar,
      label: t.scheduleBoard || "Schedule",
      show: can("schedule.view"),
    },
    {
      id: "roster",
      icon: Users,
      label: t.roster || "Roster",
      show: can("roster.view"),
    },
    {
      id: "ftl",
      icon: Clock,
      label: t.ftl || "FTL",
      show: can("ftl.view"),
    },
    {
      id: "reports",
      icon: TrendingUp,
      label: t.reports || "Reports",
      show: can("reports.view"),
    },
  ];

  const quickActions = allQuickActions.filter((qa) => qa.show);

  return (
    <div className="space-y-6 fade-in">
      {/* ⭐ Welcome Banner */}
      <div
        className="rounded-2xl p-6 text-white shadow-lg overflow-hidden relative"
        style={{
          background: "var(--brand-gradient)",
          boxShadow: "var(--shadow-lg)",
        }}
      >
        <div className="absolute -top-10 -right-10 w-40 h-40 rounded-full bg-white/10 blur-3xl pointer-events-none" />
        <div className="absolute -bottom-10 -left-10 w-40 h-40 rounded-full bg-white/10 blur-3xl pointer-events-none" />

        <div className="flex items-center justify-between flex-wrap gap-4 relative z-10">
          <div>
            <h2 className="text-2xl font-bold mb-1">
              {t.dashboard || "Dashboard"}
            </h2>
            <p className="text-white/80 text-sm">
              {t.loggedInAs || "Logged in as"}:{" "}
              <b>{user?.fullName || "User"}</b> ·{" "}
              {t[user?.role] || user?.role || "—"}
            </p>
          </div>
          <div className="hidden md:block">
            <LiveClock />
          </div>
        </div>
      </div>

      {/* ⭐ Stats Grid */}
      {loading ? (
        <div
          className="rounded-xl p-6 text-center"
          style={{
            backgroundColor: "var(--bg-card)",
            border: "1px solid var(--border-default)",
          }}
        >
          <div
            className="w-10 h-10 border-4 border-t-transparent rounded-full animate-spin mx-auto mb-3"
            style={{
              borderColor: "var(--brand-primary)",
              borderTopColor: "transparent",
            }}
          />
          <div className="font-bold" style={{ color: "var(--text-primary)" }}>
            جاري تحميل البطاقات...
          </div>
        </div>
      ) : stats.length > 0 ? (
        <div
          className={`grid grid-cols-2 gap-4 ${
            stats.length === 1
              ? "md:grid-cols-1"
              : stats.length === 2
              ? "md:grid-cols-2"
              : stats.length === 3
              ? "md:grid-cols-3"
              : "md:grid-cols-4"
          }`}
        >
          {stats.map((s) => {
            const Icon = s.icon;
            return (
              <button
                key={s.id}
                onClick={() => setTab(s.tab)}
                className="rounded-xl p-4 text-start hover:shadow-lg transition group theme-transition relative overflow-hidden"
                style={{
                  backgroundColor: "var(--bg-card)",
                  border: "1px solid var(--border-default)",
                  boxShadow: "var(--shadow-sm)",
                }}
              >
                <div
                  className="w-10 h-10 rounded-lg flex items-center justify-center mb-3 group-hover:scale-110 transition"
                  style={{
                    background: "var(--brand-gradient)",
                    boxShadow: "var(--shadow-md)",
                  }}
                >
                  <Icon className="w-5 h-5 text-white" />
                </div>

                <div
                  className="text-2xl font-bold"
                  style={{ color: "var(--text-primary)" }}
                >
                  {s.value}
                </div>

                <div className="text-xs" style={{ color: "var(--text-muted)" }}>
                  {s.label}
                </div>

                <div
                  className="text-[10px] mt-1"
                  style={{ color: "var(--text-muted)", opacity: 0.7 }}
                >
                  {s.sub}
                </div>

                <div
                  className="absolute bottom-0 start-0 h-0.5 w-full opacity-0 group-hover:opacity-100 transition"
                  style={{ background: "var(--brand-gradient)" }}
                />
              </button>
            );
          })}
        </div>
      ) : (
        <div
          className="rounded-xl p-6 text-center"
          style={{
            backgroundColor: "var(--bg-card)",
            border: "1px solid var(--border-default)",
          }}
        >
          <Shield
            className="w-12 h-12 mx-auto mb-2"
            style={{ color: "var(--brand-primary)" }}
          />
          <div className="font-bold" style={{ color: "var(--text-primary)" }}>
            لا توجد بطاقات متاحة — تحقق من صلاحياتك
          </div>
          <div
            className="text-xs mt-2 font-mono"
            style={{ color: "var(--text-muted)" }}
          >
            Role: {user?.role || "—"} · Perms:{" "}
            {Array.isArray(user?.perms)
              ? user.perms.length
              : parsePerms(user?.perms).length}
          </div>
          <div
            className="text-[10px] mt-1 font-mono"
            style={{ color: "var(--text-muted)", opacity: 0.6 }}
          >
            user: {user ? "✅ موجود" : "❌ null/undefined"}
          </div>
        </div>
      )}

      {/* ⭐ Active Flights + Quick Actions */}
      <div className="grid md:grid-cols-3 gap-4">
        {can("schedule.view") && (
          <div
            className={`rounded-xl ${
              quickActions.length === 0 ? "md:col-span-3" : "md:col-span-2"
            }`}
            style={{
              backgroundColor: "var(--bg-card)",
              border: "1px solid var(--border-default)",
              boxShadow: "var(--shadow-sm)",
            }}
          >
            <div
              className="px-4 py-3 flex items-center justify-between"
              style={{ borderBottom: "1px solid var(--border-default)" }}
            >
              <h3
                className="font-bold flex items-center gap-2"
                style={{ color: "var(--text-primary)" }}
              >
                <Activity
                  className="w-4 h-4"
                  style={{ color: "var(--brand-primary)" }}
                />
                {t.recentFlights || "Recent Flights"}
              </h3>
              <button
                onClick={() => setTab("schedule")}
                className="text-xs hover:underline flex items-center gap-1"
                style={{ color: "var(--brand-primary)" }}
              >
                {t.tableView || "TABLE"} <ArrowRight className="w-3 h-3" />
              </button>
            </div>

            {activeFlights.length === 0 && todayFlights.length === 0 ? (
              <div
                className="p-8 text-center text-sm"
                style={{ color: "var(--text-muted)" }}
              >
                <Plane className="w-10 h-10 mx-auto mb-2 opacity-30" />
                {t.noData || "لا توجد بيانات"}
              </div>
            ) : (
              <div>
                {(activeFlights.length > 0 ? activeFlights : todayFlights)
                  .slice(0, 5)
                  .map((f, idx) => (
                    <div
                      key={f.id}
                      className="p-3 flex items-center gap-3 transition hover:opacity-80"
                      style={{
                        borderTop:
                          idx > 0 ? "1px solid var(--border-default)" : "none",
                      }}
                    >
                      <div
                        className="w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0"
                        style={{
                          backgroundColor: "var(--bg-app)",
                          border: "1px solid var(--border-default)",
                        }}
                      >
                        <Plane
                          className="w-5 h-5"
                          style={{ color: "var(--brand-primary)" }}
                        />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div
                          className="font-semibold text-sm"
                          style={{ color: "var(--text-primary)" }}
                        >
                          {f.flightNo || "—"}
                        </div>
                        <div
                          className="text-xs"
                          style={{ color: "var(--text-muted)" }}
                        >
                          {f.dep || "—"} → {f.arr || "—"} · {f.acft || "—"}
                        </div>
                      </div>
                      <div className="text-end">
                        <Badge kind={f.status}>{f.status}</Badge>
                        <div
                          className="text-[10px] mt-1 font-mono"
                          style={{ color: "var(--text-muted)" }}
                        >
                          {f.std?.slice(11, 16) || "—"} UTC
                        </div>
                      </div>
                    </div>
                  ))}
              </div>
            )}
          </div>
        )}

        {quickActions.length > 0 && (
          <div
            className={`rounded-xl ${
              !can("schedule.view") ? "md:col-span-3" : ""
            }`}
            style={{
              backgroundColor: "var(--bg-card)",
              border: "1px solid var(--border-default)",
              boxShadow: "var(--shadow-sm)",
            }}
          >
            <div
              className="px-4 py-3"
              style={{ borderBottom: "1px solid var(--border-default)" }}
            >
              <h3
                className="font-bold"
                style={{ color: "var(--text-primary)" }}
              >
                {t.quickActions || "Quick Actions"}
              </h3>
            </div>

            <div className="p-3 grid grid-cols-2 gap-2">
              {quickActions.map((qa) => {
                const Icon = qa.icon;
                return (
                  <button
                    key={qa.id}
                    onClick={() => setTab(qa.id)}
                    className="p-3 rounded-lg text-center transition hover:opacity-80 group"
                    style={{
                      backgroundColor: "var(--bg-app)",
                      border: "1px solid var(--border-default)",
                    }}
                  >
                    <Icon
                      className="w-5 h-5 mx-auto mb-1 transition group-hover:scale-110"
                      style={{ color: "var(--brand-primary)" }}
                    />
                    <div
                      className="text-[10px] font-bold truncate"
                      style={{ color: "var(--text-primary)" }}
                    >
                      {qa.label}
                    </div>
                  </button>
                );
              })}
            </div>

            {(can("leave.view") ||
              can("roster.view") ||
              can("standby.view") ||
              can("training.view")) && (
              <div className="px-3 pb-3 space-y-1.5">
                {can("leave.view") && (
                  <div
                    className="flex justify-between text-xs"
                    style={{ color: "var(--text-muted)" }}
                  >
                    <span>{t.pendingLeaveChart || "Pending Leave"}:</span>
                    <span className="font-bold text-amber-500">
                      {pendingLeave.length}
                    </span>
                  </div>
                )}
                {can("roster.view") && (
                  <div
                    className="flex justify-between text-xs"
                    style={{ color: "var(--text-muted)" }}
                  >
                    <span>{t.rosterEntries || "Roster Entries"}:</span>
                    <span
                      className="font-bold"
                      style={{ color: "var(--brand-primary)" }}
                    >
                      {roster.length}
                    </span>
                  </div>
                )}
                {can("standby.view") && (
                  <div
                    className="flex justify-between text-xs"
                    style={{ color: "var(--text-muted)" }}
                  >
                    <span>{t.onStandby || "On Standby"}:</span>
                    <span className="font-bold text-emerald-500">
                      {standby.length}
                    </span>
                  </div>
                )}
                {can("training.view") && (
                  <div
                    className="flex justify-between text-xs"
                    style={{ color: "var(--text-muted)" }}
                  >
                    <span>{t.trainingTitle || "Training"}:</span>
                    <span className="font-bold text-purple-500">
                      {training.length}
                    </span>
                  </div>
                )}
              </div>
            )}
          </div>
        )}
      </div>

      {/* ⭐ Alerts */}
      {(can("crew.view") || can("fleet.view") || can("users.view")) && (
        <AlertsSummary crew={crew} users={users} fleet={fleet} />
      )}
    </div>
  );
}

export default Dashboard;
